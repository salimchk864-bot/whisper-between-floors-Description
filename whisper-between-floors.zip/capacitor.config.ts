export default {
  appId: 'com.whisperbetweenfloors.horror',
  appName: 'Шёпот между этажами',
  webDir: 'dist',
  android: {
    backgroundColor: '#07080a',
    allowMixedContent: false,
    webContentsDebuggingEnabled: false,
  },
  server: {
    androidScheme: 'https',
  },
};
