# Сборка отдельного Android-приложения «Шёпот между этажами» (`Whisper_Between_Floors.apk`)

> **Честное примечание:** в облачной среде предпросмотра нет установленных Java JDK и Android SDK, поэтому скомпилировать бинарный файл `.apk` прямо внутри браузерного контейнера технически невозможно. Вместо этого в проекте уже подготовлен **полноценный автономный Android-проект (`android/`)** со всеми 3D-ассетами игры внутри (`android/app/src/main/assets/public/`), полноэкранным `MainActivity.java` и Gradle-сборкой — игра работает полностью локально без интернета и без открытия сайта.

---

## Способ 1: Собрать `Whisper_Between_Floors.apk` без установки программ на ПК (через GitHub Actions)
1. Скачайте архив **`whisper-between-floors.zip`** (в меню игры **«Скачать APK» → «Скачать Android-проект (.zip)»**).
2. Распакуйте архив и загрузите файлы в новый репозиторий на **GitHub**.
3. Откройте вкладку **Actions** → выберите **Build Android APK** → нажмите **Run workflow** (или просто сделайте push в `main`).
4. Через ~2 минуты скачайте готовый установочный файл **`Whisper_Between_Floors.apk`** из раздела **Artifacts** — его можно установить на телефон и отправлять друзьям в Telegram как обычный `.apk` файл.

---

## Способ 2: Открыть в Android Studio и собрать APK на компьютере
1. Установите **Android Studio** (с Android SDK и JDK).
2. Распакуйте `whisper-between-floors.zip` и откройте папку **`android/`** в Android Studio (**Open → `android`**).
3. Нажмите в верхнем меню: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Готовый файл **`Whisper_Between_Floors.apk`** появится в:
   `android/app/build/outputs/apk/debug/Whisper_Between_Floors.apk`

---

## Способ 3: Консольная сборка одной командой (Linux / macOS / Git Bash)
При наличии **Node.js 20+**, **Java 21** и **Android SDK**:
```bash
bash scripts/build-android-apk.sh
```
Готовый файл:
`android/app/build/outputs/apk/debug/Whisper_Between_Floors.apk`
