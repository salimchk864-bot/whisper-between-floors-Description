#!/usr/bin/env bash
set -euo pipefail

echo "=== Сборка Android APK: Шёпот между этажами ==="
npm install
npm run build
rm -f dist/whisper-between-floors.zip

if [ ! -d "android" ]; then
  npx cap add android
fi

npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon

APK_PATH="app/build/outputs/apk/debug/Whisper_Between_Floors.apk"
if [ ! -f "$APK_PATH" ] && [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
  cp app/build/outputs/apk/debug/app-debug.apk "$APK_PATH"
fi

echo ""
echo "Готово! Автономный APK собран:"
echo "android/$APK_PATH"
