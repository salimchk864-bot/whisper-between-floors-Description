import { useCallback, useEffect, useRef, useState } from 'react';
import { HorrorEngine } from './game/engine/HorrorEngine';
import { SaveManager } from './game/save/SaveManager';
import { createRandomNightSeed } from './game/world/NightConfig';
import { GameSettings, GameState, HUDState, NightSeedData } from './game/types';
import { MainMenu } from './game/ui/MainMenu';
import { TouchControls } from './game/ui/TouchControls';
import { GameHUD } from './game/ui/GameHUD';
import { PauseSettingsModal } from './game/ui/PauseSettingsModal';
import { InventoryJournalModal } from './game/ui/InventoryJournalModal';
import { CutsceneOverlay } from './game/ui/CutsceneOverlay';
import { EndingScreen } from './game/ui/EndingScreen';
import { CCTVModal } from './game/ui/CCTVModal';
import { PhoneModal } from './game/ui/PhoneModal';
import { KeypadModal } from './game/ui/KeypadModal';
import { useOnlineStatus } from './game/ui/usePWAInstall';

const SETTINGS_STORAGE_KEY = 'whisper_floors_settings_v1';

const DEFAULT_SETTINGS: GameSettings = {
  sensitivity: 1.0,
  volume: 0.8,
  quality: 'medium',
  invertY: false,
  difficulty: 'normal',
  touchScale: 'standard',
  controlsSwapHands: false,
};

function loadSavedSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

const INITIAL_HUD: HUDState = {
  gameState: GameState.MENU,
  currentFloor: 1,
  locationName: '1 этаж',
  elevatorFloor: 1,
  elevatorState: 'idle',
  elevatorPowered: true,
  flashlightOn: true,
  battery: 100,
  health: 100,
  stamina: 100,
  exhausted: false,
  noiseLevel: 0,
  crouching: false,
  sprinting: false,
  hidingSpotName: null,
  peepholeActive: false,
  peepholeLabel: null,
  activePrompt: null,
  activeNote: null,
  activeCutscene: null,
  activeEnding: null,
  activeKeypad: null,
  subtitle: null,
  phoneMessage: null,
  phoneHistory: [],
  phoneUnreadCount: 0,
  achievementToast: null,
  inventory: [],
  maxInventorySlots: 8,
  notesFound: [],
  restoredFloors: [1, 4],
  generatorRunning: false,
  generatorFuelAdded: false,
  generatorFusesInserted: 0,
  monsterState: 'PATROL',
  monsterDistance: 20,
  monsterWindingUp: false,
  dangerLevel: 0,
  fearLevel: 0,
  tension: 0.15,
  damageFlash: 0,
  nightNumber: 1,
  difficulty: 'normal',
  weather: 'rain',
  isNewGamePlus: false,
  isTouchDevice: false,
  cctvFeeds: [],
  activeCameraIndex: 0,
  discoveredCreatures: [],
};

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<HorrorEngine | null>(null);
  const autoStartModeRef = useRef<'menu' | 'new' | 'continue'>('menu');
  const pendingNightSeedRef = useRef<NightSeedData | undefined>(undefined);

  const [sessionId, setSessionId] = useState(0);
  const [hud, setHud] = useState<HUDState>(INITIAL_HUD);
  const [settings, setSettings] = useState<GameSettings>(loadSavedSettings);
  const [hasSave, setHasSave] = useState(() => SaveManager.hasSave());
  const [isNewGamePlus, setIsNewGamePlus] = useState(false);
  const [contextLost, setContextLost] = useState(false);
  const isOnline = useOnlineStatus();

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const initialNightSeed = pendingNightSeedRef.current;
    pendingNightSeedRef.current = undefined;

    const engine = new HorrorEngine(
      container,
      (nextHud) => setHud(nextHud),
      {
        onContextLost: () => setContextLost(true),
        onContextRestored: () => setContextLost(false),
        initialNightSeed,
      },
    );
    engine.updateSettings(settings);
    engineRef.current = engine;

    const mode = autoStartModeRef.current;
    autoStartModeRef.current = 'menu';
    if (mode === 'new') {
      engine.startNewGame();
      setHasSave(true);
    } else if (mode === 'continue') {
      engine.continueSavedGame();
    }

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId]);

  const handleUpdateSettings = useCallback((next: GameSettings) => {
    setSettings(next);
    engineRef.current?.updateSettings(next);
    try {
      localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(next));
    } catch {
      // Ignore storage quota errors
    }
  }, []);

  const handleStartNew = useCallback(() => {
    SaveManager.clearSave();
    setHasSave(false);
    pendingNightSeedRef.current = createRandomNightSeed(undefined, isNewGamePlus);
    autoStartModeRef.current = 'new';
    setSessionId((n) => n + 1);
  }, [isNewGamePlus]);

  const handleContinue = useCallback(() => {
    const save = SaveManager.loadSave();
    if (!save) {
      handleStartNew();
      return;
    }
    pendingNightSeedRef.current = save.nightSeed;
    autoStartModeRef.current = 'continue';
    setSessionId((n) => n + 1);
  }, [handleStartNew]);

  const handlePause = useCallback(() => {
    engineRef.current?.setPaused(true);
  }, []);

  const handleResume = useCallback(() => {
    engineRef.current?.setPaused(false);
  }, []);

  const handleSaveProgress = useCallback(() => {
    engineRef.current?.saveProgress();
    setHasSave(SaveManager.hasSave());
  }, []);

  const handleRestart = useCallback(() => {
    SaveManager.clearSave();
    setHasSave(false);
    pendingNightSeedRef.current = createRandomNightSeed(undefined, isNewGamePlus);
    autoStartModeRef.current = 'new';
    setSessionId((n) => n + 1);
  }, [isNewGamePlus]);

  const handleExitToMenu = useCallback(() => {
    engineRef.current?.saveProgress();
    setHasSave(SaveManager.hasSave());
    autoStartModeRef.current = 'menu';
    setSessionId((n) => n + 1);
  }, []);

  const handleToggleInventory = useCallback(() => {
    engineRef.current?.toggleInventory();
  }, []);

  const handleUseInventoryItem = useCallback((id: string) => {
    engineRef.current?.useInventoryItem(id);
  }, []);

  const handleDropInventoryItem = useCallback((id: string) => {
    engineRef.current?.dropInventoryItem(id);
  }, []);

  const handleCloseNote = useCallback(() => {
    engineRef.current?.closeNote();
  }, []);

  const handleOpenPhone = useCallback(() => {
    engineRef.current?.openPhone();
  }, []);

  const handleClosePhone = useCallback(() => {
    engineRef.current?.closePhone();
  }, []);

  const handleSelectCamera = useCallback((index: number) => {
    engineRef.current?.selectCamera(index);
  }, []);

  const handleCloseCCTV = useCallback(() => {
    engineRef.current?.closeCCTV();
  }, []);

  const handleSubmitKeypad = useCallback((code: string) => {
    return engineRef.current?.submitKeypadCode(code) ?? false;
  }, []);

  const handleCloseKeypad = useCallback(() => {
    engineRef.current?.closeKeypad();
  }, []);

  const handleSkipCutscene = useCallback(() => {
    engineRef.current?.skipCutscene();
  }, []);

  const handleJoystickMove = useCallback((x: number, y: number) => {
    engineRef.current?.setJoystickInput(x, y);
  }, []);

  const handleSprintChange = useCallback((active: boolean) => {
    engineRef.current?.setSprint(active);
  }, []);

  const handleLookDelta = useCallback((dx: number, dy: number) => {
    engineRef.current?.addLookDelta(dx, dy);
  }, []);

  const handleToggleCrouch = useCallback(() => {
    engineRef.current?.toggleCrouch();
  }, []);

  const handleToggleFlashlight = useCallback(() => {
    engineRef.current?.toggleFlashlight();
  }, []);

  const handleInteract = useCallback(() => {
    engineRef.current?.triggerInteract();
  }, []);

  const handleSecondaryInteract = useCallback(() => {
    engineRef.current?.triggerSecondaryInteract();
  }, []);

  const showTouchControls =
    hud.gameState === GameState.PLAYING ||
    hud.gameState === GameState.HIDING ||
    hud.gameState === GameState.PEEPHOLE;

  return (
    <div className="relative w-full h-full overflow-hidden bg-[#07080a]">
      {/* Isolated WebGL mount container */}
      <div ref={mountRef} className="fixed inset-0 w-full h-full" />

      {/* Subtle atmospheric vignette */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at center, transparent 52%, rgba(4, 5, 7, 0.72) 100%)',
        }}
      />

      {contextLost && (
        <div className="fixed inset-0 z-50 bg-[#07080a]/95 flex items-center justify-center p-6 text-center">
          <div className="max-w-sm space-y-3">
            <h2 className="font-display text-2xl text-[#f3efe6]">
              Контекст WebGL приостановлен
            </h2>
            <p className="text-sm text-[#a5a39c]">
              Графический драйвер освободил ресурсы. Нажмите кнопку ниже, чтобы перезапустить сцену.
            </p>
            <button
              type="button"
              onClick={handleRestart}
              className="h-11 px-5 rounded-lg bg-[#c25e28] text-white text-sm font-semibold"
            >
              Перезагрузить сцену
            </button>
          </div>
        </div>
      )}

      {hud.gameState === GameState.MENU && (
        <MainMenu
          settings={settings}
          hasSave={hasSave}
          isNewGamePlus={isNewGamePlus}
          onToggleNewGamePlus={setIsNewGamePlus}
          onUpdateSettings={handleUpdateSettings}
          onContinue={handleContinue}
          onStartNew={handleStartNew}
          onSaveImported={() => setHasSave(SaveManager.hasSave())}
        />
      )}

      {!isOnline && hud.gameState === GameState.MENU && (
        <div className="fixed bottom-4 left-4 z-40 rounded-lg bg-[#141820] border border-amber-500/40 px-3 py-1.5 text-xs font-medium text-amber-200 pointer-events-none">
          Автономный режим (офлайн)
        </div>
      )}

      {showTouchControls && (
        <TouchControls
          gameState={hud.gameState}
          crouching={hud.crouching}
          sprinting={hud.sprinting}
          exhausted={hud.exhausted}
          flashlightOn={hud.flashlightOn}
          activePrompt={hud.activePrompt}
          touchScale={settings.touchScale}
          controlsSwapHands={settings.controlsSwapHands}
          onJoystickMove={handleJoystickMove}
          onSprintChange={handleSprintChange}
          onLookDelta={handleLookDelta}
          onToggleCrouch={handleToggleCrouch}
          onToggleFlashlight={handleToggleFlashlight}
          onInteract={handleInteract}
          onSecondaryInteract={handleSecondaryInteract}
        />
      )}

      <GameHUD
        hud={hud}
        onPause={handlePause}
        onOpenInventory={handleToggleInventory}
        onOpenPhone={handleOpenPhone}
        onCloseNote={handleCloseNote}
      />

      {hud.gameState === GameState.INVENTORY && (
        <InventoryJournalModal
          items={hud.inventory}
          maxSlots={hud.maxInventorySlots}
          notesFound={hud.notesFound}
          health={hud.health}
          battery={hud.battery}
          onUseItem={handleUseInventoryItem}
          onDropItem={handleDropInventoryItem}
          onClose={handleToggleInventory}
        />
      )}

      {hud.gameState === GameState.CCTV && (
        <CCTVModal
          feeds={hud.cctvFeeds}
          activeCameraIndex={hud.activeCameraIndex}
          onSelectCamera={handleSelectCamera}
          onClose={handleCloseCCTV}
        />
      )}

      {hud.gameState === GameState.PHONE && (
        <PhoneModal
          history={hud.phoneHistory}
          nightNumber={hud.nightNumber}
          weather={hud.weather}
          difficulty={hud.difficulty}
          isNewGamePlus={hud.isNewGamePlus}
          restoredFloorsCount={hud.restoredFloors.length}
          generatorRunning={hud.generatorRunning}
          notesFoundCount={hud.notesFound.length}
          onClose={handleClosePhone}
        />
      )}

      {hud.gameState === GameState.KEYPAD && hud.activeKeypad && (
        <KeypadModal
          keypad={hud.activeKeypad}
          onSubmitCode={handleSubmitKeypad}
          onClose={handleCloseKeypad}
        />
      )}

      {hud.gameState === GameState.CUTSCENE && hud.activeCutscene && (
        <CutsceneOverlay
          cutscene={hud.activeCutscene}
          onSkip={handleSkipCutscene}
        />
      )}

      {hud.gameState === GameState.PAUSED && (
        <PauseSettingsModal
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onResume={handleResume}
          onSave={handleSaveProgress}
          onRestart={handleRestart}
          onExitToMenu={handleExitToMenu}
        />
      )}

      {hud.gameState === GameState.ENDING && hud.activeEnding && (
        <EndingScreen
          ending={hud.activeEnding}
          notesFoundCount={hud.notesFound.length}
          onRestart={handleRestart}
          onExitToMenu={handleExitToMenu}
        />
      )}
    </div>
  );
}
