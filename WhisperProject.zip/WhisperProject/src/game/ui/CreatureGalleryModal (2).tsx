import React from 'react';
import { Eye, Lock, X } from 'lucide-react';
import { CREATURE_CATALOG } from '../story/CreatureGalleryData';
import { CreatureId } from '../types';

interface CreatureGalleryModalProps {
  discoveredIds: CreatureId[];
  onClose: () => void;
}

const UNLOCK_HINTS: Record<CreatureId, string> = {
  stalker: 'Встретьте преследователя в коридоре или заметьте его на мониторе CCTV в кв. 5.',
  whisper_phenomenon: 'Исследуйте подвал и чердак или прислушайтесь к ночным аномалиям в доме.',
  shadow_phantom: 'Просмотрите камеры наблюдения в кв. 5 или исследуйте тёмные пролёты.',
  signal_zero: 'Откройте потайную панель в кв. 10 или секретный архив в кв. 11.',
};

export const CreatureGalleryModal: React.FC<CreatureGalleryModalProps> = ({
  discoveredIds,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 bg-[#050608]/92 flex items-center justify-center p-4 sm:p-6 pointer-events-auto">
      <div className="w-full max-w-2xl rounded-xl bg-[#0e1116] border border-white/15 p-5 sm:p-6 shadow-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-xs font-mono-num tracking-wider text-[#c97e4a]">
              АРХИВ НАБЛЮДЕНИЙ · {discoveredIds.length}/{CREATURE_CATALOG.length}
            </div>
            <h2 className="font-display text-3xl font-semibold text-[#f3efe6] mt-1">
              Галерея существ и аномалий
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть галерею"
            className="w-10 h-10 rounded-lg bg-white/8 hover:bg-white/15 flex items-center justify-center text-[#b8b5ad]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 flex-1 overflow-y-auto space-y-3 pr-1">
          {CREATURE_CATALOG.map((entry) => {
            const unlocked = discoveredIds.includes(entry.id);
            return (
              <div
                key={entry.id}
                className={`p-4 rounded-xl border ${
                  unlocked
                    ? 'bg-[#131820] border-[#c25e28]/35'
                    : 'bg-[#0b0e12] border-white/10'
                }`}
              >
                {unlocked ? (
                  <>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <h3 className="font-display text-xl font-semibold text-[#f3efe6]">
                          {entry.name}
                        </h3>
                        <div className="text-xs text-[#9b9a94]">{entry.subtitle}</div>
                      </div>
                      <span className="px-2.5 py-1 rounded bg-[#c25e28]/18 border border-[#c25e28]/35 text-[11px] font-mono-num text-[#e6c48a] inline-flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5" />
                        {entry.threat}
                      </span>
                    </div>

                    <p className="mt-3 text-sm text-[#d8d5ce] leading-relaxed">
                      {entry.summary}
                    </p>

                    <div className="mt-3 grid sm:grid-cols-2 gap-3 text-xs">
                      <div className="p-3 rounded-lg bg-black/25 border border-white/8">
                        <div className="font-semibold text-[#e6c48a] mb-1.5">
                          Повадки
                        </div>
                        <ul className="space-y-1 text-[#b8b5ad]">
                          {entry.behaviors.map((b, i) => (
                            <li key={i}>• {b}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-3 rounded-lg bg-black/25 border border-white/8">
                        <div className="font-semibold text-[#9ec4b0] mb-1.5">
                          Как выжить
                        </div>
                        <ul className="space-y-1 text-[#b8b5ad]">
                          {entry.counterTips.map((tip, i) => (
                            <li key={i}>• {tip}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-white/6 border border-white/10 flex items-center justify-center text-[#7c7a74] shrink-0">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#9b9a94]">
                        Не обнаружено
                      </div>
                      <div className="text-xs text-[#73726c] mt-0.5">
                        {UNLOCK_HINTS[entry.id]}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-4 w-full h-11 rounded-lg bg-white/8 hover:bg-white/14 border border-white/14 text-[#f3efe6] text-sm font-medium transition-colors"
        >
          Закрыть
        </button>
      </div>
    </div>
  );
};
