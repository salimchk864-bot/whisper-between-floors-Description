import React, { useState } from 'react';
import { Award, CheckCircle2, Download, Eye, Lock, X } from 'lucide-react';
import { DifficultyLevel, GameSettings } from '../types';
import { PauseSettingsModal } from './PauseSettingsModal';
import { DownloadModal } from './DownloadModal';
import { CreatureGalleryModal } from './CreatureGalleryModal';
import { SaveManager } from '../save/SaveManager';
import {
  ACHIEVEMENTS_CATALOG,
  AchievementManager,
} from '../achievements/AchievementManager';
import {
  CREATURE_CATALOG,
  CreatureGalleryManager,
} from '../story/CreatureGalleryData';

interface MainMenuProps {
  settings: GameSettings;
  hasSave: boolean;
  isNewGamePlus: boolean;
  onToggleNewGamePlus: (enabled: boolean) => void;
  onUpdateSettings: (next: GameSettings) => void;
  onContinue: () => void;
  onStartNew: () => void;
  onSaveImported: () => void;
}

const DIFFICULTY_OPTIONS: { value: DifficultyLevel; label: string }[] = [
  { value: 'easy', label: 'Лёгкий' },
  { value: 'normal', label: 'Нормальный' },
  { value: 'hard', label: 'Сложный' },
  { value: 'nightmare', label: 'Кошмар' },
];

export const MainMenu: React.FC<MainMenuProps> = ({
  settings,
  hasSave,
  isNewGamePlus,
  onToggleNewGamePlus,
  onUpdateSettings,
  onContinue,
  onStartNew,
  onSaveImported,
}) => {
  const [showSettings, setShowSettings] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [showAchievements, setShowAchievements] = useState(false);
  const [showGallery, setShowGallery] = useState(false);

  const discoveredEndings = SaveManager.getDiscoveredEndings();
  const ngPlusUnlocked = discoveredEndings.length > 0;

  const achievementMgr = new AchievementManager();
  const unlockedAchIds = achievementMgr.getUnlockedIds();

  const creatureMgr = new CreatureGalleryManager();
  const discoveredCreatures = creatureMgr.getDiscoveredIds();

  return (
    <div className="fixed inset-0 z-30 flex items-center bg-gradient-to-r from-[#060709]/95 via-[#060709]/78 to-transparent p-5 sm:p-12 pointer-events-auto overflow-y-auto">
      <div className="max-w-xl my-auto">
        <div className="text-xs font-mono-num tracking-wider text-[#c97e4a]">
          COLD SILENCE STUDIO · WHISPER BETWEEN FLOORS 0.5
        </div>

        <h1 className="font-display text-4xl sm:text-6xl font-bold text-[#f3efe6] leading-[1.06] mt-3 text-balance">
          Шёпот между этажами
        </h1>

        <p className="mt-3 text-sm sm:text-base text-[#b8b5ad] leading-relaxed max-w-md">
          Обесточенный подъезд, случайные ночные сценарии, камеры охраны в кв. 5, живые
          квартиры и умный преследователь. Успейте запустить генератор и раскройте тайну
          «Холодной тишины».
        </p>

        {/* Difficulty + New Game+ bar */}
        <div className="mt-5 p-3 rounded-xl bg-[#0e1218]/92 border border-white/12 max-w-md space-y-2.5">
          <div>
            <div className="text-[11px] font-mono-num text-[#9b9a94] mb-1.5">
              Сложность новой игры
            </div>
            <div className="grid grid-cols-4 gap-1 p-1 rounded-lg bg-[#07090c] border border-white/10">
              {DIFFICULTY_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, difficulty: opt.value })
                  }
                  className={`h-8 rounded-md text-[11px] sm:text-xs font-medium transition-colors ${
                    settings.difficulty === opt.value
                      ? 'bg-[#c25e28] text-white'
                      : 'text-[#a5a39c] hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/8">
            <div>
              <div className="text-xs font-medium text-[#e6e4df]">
                Режим «Новая игра+»
              </div>
              <div className="text-[10px] text-[#8f8d85]">
                {ngPlusUnlocked
                  ? 'Выше риск, скрытые записи и кодовый шкаф в кв. 5'
                  : 'Откроется после прохождения любой концовки'}
              </div>
            </div>
            <button
              type="button"
              disabled={!ngPlusUnlocked}
              onClick={() => onToggleNewGamePlus(!isNewGamePlus)}
              className={`h-8 px-3 rounded-lg border text-xs font-semibold transition-colors ${
                !ngPlusUnlocked
                  ? 'bg-white/5 border-white/10 text-[#6e6c66] cursor-not-allowed'
                  : isNewGamePlus
                    ? 'bg-[#c25e28] border-[#f59e0b]/70 text-white'
                    : 'bg-white/8 border-white/15 text-[#d8d5ce] hover:bg-white/14'
              }`}
            >
              {ngPlusUnlocked ? (isNewGamePlus ? 'ВКЛ' : 'ВЫКЛ') : 'Закрыто'}
            </button>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-2.5">
          {hasSave && (
            <button
              type="button"
              onClick={onContinue}
              className="h-12 px-6 rounded-lg bg-[#c25e28] hover:bg-[#d46a31] text-white text-sm font-semibold transition-colors whitespace-nowrap"
            >
              Продолжить
            </button>
          )}

          <button
            type="button"
            onClick={onStartNew}
            className={`h-12 px-6 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap ${
              hasSave
                ? 'bg-[#151920]/95 hover:bg-[#1e242e] border border-white/18 text-[#f3efe6]'
                : 'bg-[#c25e28] hover:bg-[#d46a31] text-white'
            }`}
          >
            Новая игра
          </button>

          <button
            type="button"
            onClick={() => setShowDownload(true)}
            className="h-12 px-4 rounded-lg bg-[#151920]/95 hover:bg-[#1e242e] border border-[#c25e28]/45 text-[#e6c48a] text-sm font-semibold transition-colors whitespace-nowrap inline-flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Скачать APK
          </button>

          <button
            type="button"
            onClick={() => setShowAchievements(true)}
            className="h-12 px-4 rounded-lg bg-[#111419]/90 hover:bg-[#191e26] border border-white/15 text-[#e6e4df] text-sm font-medium transition-colors whitespace-nowrap inline-flex items-center gap-1.5"
          >
            <Award className="w-4 h-4 text-[#e6c48a]" />
            <span>
              {unlockedAchIds.length}/{ACHIEVEMENTS_CATALOG.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowGallery(true)}
            className="h-12 px-4 rounded-lg bg-[#111419]/90 hover:bg-[#191e26] border border-white/15 text-[#e6e4df] text-sm font-medium transition-colors whitespace-nowrap inline-flex items-center gap-1.5"
          >
            <Eye className="w-4 h-4 text-[#9ec4b0]" />
            <span>
              Галерея {discoveredCreatures.length}/{CREATURE_CATALOG.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowSettings(true)}
            className="h-12 px-4 rounded-lg bg-[#111419]/90 hover:bg-[#191e26] border border-white/15 text-[#e6e4df] text-sm font-medium transition-colors whitespace-nowrap"
          >
            Настройки
          </button>

          <button
            type="button"
            onClick={() => setShowControls((v) => !v)}
            className="h-12 px-4 rounded-lg bg-[#111419]/90 hover:bg-[#191e26] border border-white/15 text-[#b8b5ad] text-sm font-medium transition-colors whitespace-nowrap"
          >
            Управление
          </button>
        </div>

        <div className="mt-4 text-xs font-mono-num text-[#8f8d85]">
          Открыто концовок: {discoveredEndings.length}/4 · Подвал, 5 этажей, чердак, CCTV и
          секретный архив
        </div>

        {showControls && (
          <div className="mt-4 p-4 rounded-xl bg-[#0d1014]/95 border border-white/12 text-xs sm:text-sm text-[#c8c5bc] space-y-2 max-w-md">
            <div>
              <strong className="text-[#f3efe6]">Сенсор (Android):</strong> левый джойстик —
              ходьба, «Бег» — переключение спринта, свайп — обзор, справа — присед, фонарик,
              «Глазок» и «Действие». Сверху кнопка «Телефон».
            </div>
            <div>
              <strong className="text-[#f3efe6]">Клавиатура / ПК:</strong> W A S D — движение,
              Shift — бег, мышь — обзор, E — действие / укрытие / CCTV, V — глазок, C —
              присед, F — фонарик, P — телефон, Tab / I — инвентарь.
            </div>
          </div>
        )}
      </div>

      {showSettings && (
        <PauseSettingsModal
          settings={settings}
          onUpdateSettings={onUpdateSettings}
          onResume={() => setShowSettings(false)}
          onRestart={() => setShowSettings(false)}
          isMainMenuSettings
        />
      )}

      {showDownload && (
        <DownloadModal
          onClose={() => setShowDownload(false)}
          onSaveImported={onSaveImported}
        />
      )}

      {showGallery && (
        <CreatureGalleryModal
          discoveredIds={discoveredCreatures}
          onClose={() => setShowGallery(false)}
        />
      )}

      {showAchievements && (
        <div className="fixed inset-0 z-40 bg-[#050608]/90 flex items-center justify-center p-4 sm:p-6 pointer-events-auto">
          <div className="w-full max-w-md rounded-xl bg-[#0e1116] border border-white/15 p-5 sm:p-6 shadow-2xl max-h-[88vh] flex flex-col">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-mono-num text-[#c97e4a]">
                  ОТКРЫТО {unlockedAchIds.length}/{ACHIEVEMENTS_CATALOG.length}
                </div>
                <h2 className="font-display text-2xl font-semibold text-[#f3efe6] mt-0.5">
                  Достижения
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowAchievements(false)}
                aria-label="Закрыть достижения"
                className="w-9 h-9 rounded-lg bg-white/8 hover:bg-white/15 flex items-center justify-center text-[#b8b5ad]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto space-y-2.5">
              {ACHIEVEMENTS_CATALOG.map((ach) => {
                const done = unlockedAchIds.includes(ach.id);
                return (
                  <div
                    key={ach.id}
                    className={`p-3.5 rounded-xl border flex items-start gap-3 ${
                      done
                        ? 'bg-[#121916] border-emerald-500/35'
                        : 'bg-[#0b0e12] border-white/10'
                    }`}
                  >
                    {done ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <Lock className="w-5 h-5 text-[#6b6a65] shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div
                        className={`text-sm font-semibold ${
                          done ? 'text-[#f3efe6]' : 'text-[#8f8d85]'
                        }`}
                      >
                        {ach.title}
                      </div>
                      <div className="text-xs text-[#9b9a94] mt-0.5">
                        {ach.description}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setShowAchievements(false)}
              className="mt-4 w-full h-11 rounded-lg bg-white/8 hover:bg-white/14 border border-white/14 text-[#f3efe6] text-sm font-medium"
            >
              Закрыть
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
