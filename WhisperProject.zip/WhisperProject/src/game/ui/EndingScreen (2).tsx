import React from 'react';
import { EndingInfo } from '../types';
import { SaveManager } from '../save/SaveManager';
import { TOTAL_NOTES_COUNT } from '../story/NotesData';

interface EndingScreenProps {
  ending: EndingInfo;
  notesFoundCount: number;
  onRestart: () => void;
  onExitToMenu: () => void;
}

export const EndingScreen: React.FC<EndingScreenProps> = ({
  ending,
  notesFoundCount,
  onRestart,
  onExitToMenu,
}) => {
  const discovered = SaveManager.getDiscoveredEndings();

  return (
    <div className="fixed inset-0 z-50 bg-[#050608]/96 flex items-center justify-center p-6 pointer-events-auto">
      <div className="w-full max-w-lg rounded-xl bg-[#0e1116] border border-white/15 p-7 sm:p-8 shadow-2xl">
        <div className="text-xs font-mono-num text-[#c97e4a]">
          {ending.subtitle} · Cold Silence Studio
        </div>
        <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#f3efe6] mt-2 text-balance">
          {ending.title}
        </h2>
        <p className="mt-4 text-sm sm:text-base text-[#c8c5bc] leading-relaxed">
          {ending.description}
        </p>

        <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap gap-4 text-xs font-mono-num text-[#9b9a94]">
          <span>
            Записок найдено: {notesFoundCount}/{TOTAL_NOTES_COUNT}
          </span>
          <span aria-hidden="true">·</span>
          <span>Открыто концовок: {discovered.length}/4</span>
        </div>

        <div className="mt-7 flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={onRestart}
            className="flex-1 h-11 rounded-lg bg-[#c25e28] hover:bg-[#d46a31] text-white text-sm font-semibold transition-colors"
          >
            Играть снова
          </button>
          <button
            type="button"
            onClick={onExitToMenu}
            className="flex-1 h-11 rounded-lg bg-white/8 hover:bg-white/14 border border-white/12 text-[#e6e4df] text-sm font-medium transition-colors"
          >
            В главное меню
          </button>
        </div>
      </div>
    </div>
  );
};
