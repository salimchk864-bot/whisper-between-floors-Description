import React, { useState } from 'react';
import { Backpack, BookOpen, X, Trash2 } from 'lucide-react';
import { InventoryItem } from '../types';
import { STORY_NOTES, TOTAL_NOTES_COUNT } from '../story/NotesData';

interface InventoryJournalModalProps {
  items: InventoryItem[];
  maxSlots: number;
  notesFound: string[];
  health: number;
  battery: number;
  onUseItem: (id: string) => void;
  onDropItem: (id: string) => void;
  onClose: () => void;
}

export const InventoryJournalModal: React.FC<InventoryJournalModalProps> = ({
  items,
  maxSlots,
  notesFound,
  health,
  battery,
  onUseItem,
  onDropItem,
  onClose,
}) => {
  const [tab, setTab] = useState<'inventory' | 'journal'>('inventory');
  const [selectedId, setSelectedId] = useState<string | null>(
    items[0]?.id ?? null,
  );

  const selectedItem = items.find((i) => i.id === selectedId) ?? items[0] ?? null;
  const collectedNotes = notesFound
    .map((id) => STORY_NOTES[id])
    .filter(Boolean);

  return (
    <div className="fixed inset-0 z-40 bg-[#050608]/88 flex items-center justify-center p-4 sm:p-6 pointer-events-auto">
      <div className="w-full max-w-2xl rounded-xl bg-[#0e1116] border border-white/15 p-5 sm:p-6 shadow-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-2 p-1 bg-[#07090c] rounded-lg border border-white/10">
            <button
              type="button"
              onClick={() => setTab('inventory')}
              className={`h-9 px-3.5 rounded-md text-xs sm:text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap ${
                tab === 'inventory'
                  ? 'bg-[#c25e28] text-white'
                  : 'text-[#a5a39c] hover:text-white'
              }`}
            >
              <Backpack className="w-4 h-4" />
              <span>Инвентарь ({items.length}/{maxSlots})</span>
            </button>
            <button
              type="button"
              onClick={() => setTab('journal')}
              className={`h-9 px-3.5 rounded-md text-xs sm:text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap ${
                tab === 'journal'
                  ? 'bg-[#c25e28] text-white'
                  : 'text-[#a5a39c] hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Записки ({collectedNotes.length}/{TOTAL_NOTES_COUNT})</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-lg bg-white/8 hover:bg-white/14 flex items-center justify-center text-[#d8d5ce]"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        {tab === 'inventory' ? (
          <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-5 overflow-y-auto">
            <div className="grid grid-cols-2 gap-2.5 content-start">
              {Array.from({ length: maxSlots }).map((_, idx) => {
                const item = items[idx];
                if (!item) {
                  return (
                    <div
                      key={`empty_${idx}`}
                      className="h-20 rounded-lg border border-white/8 bg-[#080a0d] flex items-center justify-center text-[11px] text-white/20"
                    >
                      Пусто
                    </div>
                  );
                }
                const active = selectedItem?.id === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSelectedId(item.id)}
                    className={`h-20 rounded-lg border p-3 text-left flex flex-col justify-between transition-colors ${
                      active
                        ? 'bg-[#1b2028] border-[#e6c48a]/70'
                        : 'bg-[#12151b] border-white/12 hover:border-white/25'
                    }`}
                  >
                    <div className="text-xs font-semibold text-[#f3efe6] line-clamp-2">
                      {item.name}
                    </div>
                    <div className="text-[11px] font-mono-num text-[#c97e4a]">
                      x{item.quantity}
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="rounded-lg bg-[#090b0f] border border-white/10 p-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs font-mono-num text-[#9b9a94] pb-3 border-b border-white/8">
                  <span>Здоровье: {health}%</span>
                  <span>Заряд фонарика: {battery}%</span>
                </div>

                {selectedItem ? (
                  <div className="mt-4">
                    <h3 className="font-display text-2xl font-semibold text-[#f3efe6]">
                      {selectedItem.name}
                    </h3>
                    <p className="mt-2 text-sm text-[#c8c5bc] leading-relaxed">
                      {selectedItem.description}
                    </p>
                  </div>
                ) : (
                  <p className="mt-6 text-sm text-[#7f7e78]">
                    Рюкзак пуст. Ищите ключи, батарейки и инструменты в подъезде.
                  </p>
                )}
              </div>

              {selectedItem && (
                <div className="mt-5 flex items-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => onUseItem(selectedItem.id)}
                    className="flex-1 h-10 rounded-lg bg-[#c25e28] hover:bg-[#d46a31] text-white text-xs sm:text-sm font-semibold transition-colors"
                  >
                    Использовать
                  </button>
                  <button
                    type="button"
                    onClick={() => onDropItem(selectedItem.id)}
                    className="h-10 px-3.5 rounded-lg bg-white/8 hover:bg-red-900/40 border border-white/12 text-[#d8d5ce] text-xs font-medium flex items-center gap-1.5 transition-colors"
                    title="Выбросить (создаст шум)"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Бросить</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="mt-5 space-y-3 overflow-y-auto pr-1">
            {collectedNotes.length === 0 ? (
              <div className="py-12 text-center text-sm text-[#8a8880]">
                Вы ещё не нашли ни одной записки жильцов.
              </div>
            ) : (
              collectedNotes.map((note) => (
                <div
                  key={note.id}
                  className="rounded-lg bg-[#141311] border border-[#d6c7a9]/20 p-4"
                >
                  <div className="text-[11px] font-mono-num text-[#a69b86]">
                    {note.floorLabel}
                  </div>
                  <h4 className="font-display text-xl font-semibold text-[#f0e9db] mt-1">
                    {note.title}
                  </h4>
                  <div className="mt-2 space-y-1.5 text-sm text-[#cfc8b8] leading-relaxed">
                    {note.body.map((p, i) => (
                      <p key={i}>{p}</p>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
