import React, { useState } from 'react';
import { GameSettings, QualityPreset, TouchScalePreset } from '../types';

interface PauseSettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (next: GameSettings) => void;
  onResume: () => void;
  onRestart: () => void;
  onSave?: () => void;
  onExitToMenu?: () => void;
  isMainMenuSettings?: boolean;
}

const QUALITY_OPTIONS: { value: QualityPreset; label: string }[] = [
  { value: 'low', label: 'Низкое' },
  { value: 'medium', label: 'Среднее' },
  { value: 'high', label: 'Высокое' },
];

const TOUCH_SCALE_OPTIONS: { value: TouchScalePreset; label: string }[] = [
  { value: 'compact', label: 'Компакт.' },
  { value: 'standard', label: 'Обычн.' },
  { value: 'large', label: 'Крупн.' },
];

export const PauseSettingsModal: React.FC<PauseSettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onResume,
  onRestart,
  onSave,
  onExitToMenu,
  isMainMenuSettings = false,
}) => {
  const [savedFeedback, setSavedFeedback] = useState(false);

  const handleManualSave = () => {
    onSave?.();
    setSavedFeedback(true);
    window.setTimeout(() => setSavedFeedback(false), 1800);
  };

  return (
    <div className="fixed inset-0 z-40 bg-[#050608]/88 flex items-center justify-center p-5 pointer-events-auto">
      <div className="w-full max-w-md rounded-xl bg-[#0e1116] border border-white/15 p-6 shadow-2xl max-h-[92vh] overflow-y-auto">
        <h2 className="font-display text-3xl font-semibold text-[#f3efe6]">
          {isMainMenuSettings ? 'Настройки' : 'Пауза'}
        </h2>
        <p className="text-xs text-[#9b9a94] mt-1">
          Параметры управления, сенсора и оптимизация под мобильный GPU
        </p>

        <div className="mt-6 space-y-5">
          {/* Sensitivity */}
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-[#d8d5ce]">Чувствительность камеры</span>
              <span className="font-mono-num text-[#e6c48a]">
                {settings.sensitivity.toFixed(1)}x
              </span>
            </div>
            <input
              type="range"
              min="0.4"
              max="2.2"
              step="0.1"
              value={settings.sensitivity}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  sensitivity: parseFloat(e.target.value),
                })
              }
              className="w-full accent-[#d97736] h-2 bg-white/10 rounded-lg cursor-pointer"
            />
          </div>

          {/* Volume */}
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-[#d8d5ce]">Громкость звука</span>
              <span className="font-mono-num text-[#e6c48a]">
                {Math.round(settings.volume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.volume}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  volume: parseFloat(e.target.value),
                })
              }
              className="w-full accent-[#d97736] h-2 bg-white/10 rounded-lg cursor-pointer"
            />
          </div>

          {/* Graphics Quality */}
          <div>
            <div className="text-sm text-[#d8d5ce] mb-2">Качество графики</div>
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#07090c] border border-white/10 rounded-lg">
              {QUALITY_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, quality: opt.value })
                  }
                  className={`h-9 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                    settings.quality === opt.value
                      ? 'bg-[#c25e28] text-white'
                      : 'text-[#a5a39c] hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Touch Controls Scale */}
          <div>
            <div className="text-sm text-[#d8d5ce] mb-2">Размер кнопок Android</div>
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-[#07090c] border border-white/10 rounded-lg">
              {TOUCH_SCALE_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() =>
                    onUpdateSettings({ ...settings, touchScale: opt.value })
                  }
                  className={`h-9 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                    settings.touchScale === opt.value
                      ? 'bg-[#c25e28] text-white'
                      : 'text-[#a5a39c] hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Swap touch hands */}
          <label className="flex items-center justify-between py-1 cursor-pointer">
            <span className="text-sm text-[#d8d5ce]">Поменять джойстик и кнопки местами</span>
            <input
              type="checkbox"
              checked={settings.controlsSwapHands}
              onChange={(e) =>
                onUpdateSettings({ ...settings, controlsSwapHands: e.target.checked })
              }
              className="w-5 h-5 accent-[#d97736] rounded cursor-pointer"
            />
          </label>

          {/* Invert Y */}
          <label className="flex items-center justify-between py-1 cursor-pointer">
            <span className="text-sm text-[#d8d5ce]">Инверсия обзора по вертикали</span>
            <input
              type="checkbox"
              checked={settings.invertY}
              onChange={(e) =>
                onUpdateSettings({ ...settings, invertY: e.target.checked })
              }
              className="w-5 h-5 accent-[#d97736] rounded cursor-pointer"
            />
          </label>
        </div>

        <div className="mt-7 flex flex-col gap-2.5">
          <button
            type="button"
            onClick={onResume}
            className="w-full h-11 rounded-lg bg-[#c25e28] hover:bg-[#d46a31] text-white text-sm font-semibold transition-colors"
          >
            {isMainMenuSettings ? 'Готово' : 'Продолжить'}
          </button>

          {!isMainMenuSettings && (
            <>
              {onSave && (
                <button
                  type="button"
                  onClick={handleManualSave}
                  className="w-full h-11 rounded-lg bg-white/8 hover:bg-white/12 border border-white/12 text-[#e6c48a] text-sm font-medium transition-colors"
                >
                  {savedFeedback ? 'Прогресс сохранён' : 'Сохранить игру'}
                </button>
              )}
              <button
                type="button"
                onClick={onRestart}
                className="w-full h-11 rounded-lg bg-white/8 hover:bg-white/12 border border-white/12 text-[#e6e4df] text-sm font-medium transition-colors"
              >
                Начать заново
              </button>
              {onExitToMenu && (
                <button
                  type="button"
                  onClick={onExitToMenu}
                  className="w-full h-11 rounded-lg text-[#a5a39c] hover:text-white text-sm font-medium transition-colors"
                >
                  В главное меню
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
