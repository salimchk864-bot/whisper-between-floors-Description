import React from 'react';
import { PhoneIncoming, Radio, ShieldAlert, Smartphone, X } from 'lucide-react';
import { DifficultyLevel, PhoneMessage, WeatherType } from '../types';

interface PhoneModalProps {
  history: PhoneMessage[];
  nightNumber: number;
  weather: WeatherType;
  difficulty: DifficultyLevel;
  isNewGamePlus: boolean;
  restoredFloorsCount: number;
  generatorRunning: boolean;
  notesFoundCount: number;
  onClose: () => void;
}

const WEATHER_LABELS: Record<WeatherType, string> = {
  rain: 'Ночной дождь',
  storm: 'Гроза',
  fog: 'Густой туман',
};

const DIFFICULTY_LABELS: Record<DifficultyLevel, string> = {
  easy: 'Лёгкая',
  normal: 'Нормальная',
  hard: 'Сложная',
  nightmare: 'Кошмар',
};

const ScenePreview: React.FC<{
  scene: NonNullable<PhoneMessage['photoScene']>;
  title?: string;
  caption?: string;
}> = ({ scene, title, caption }) => {
  return (
    <div className="mt-2.5 rounded-lg overflow-hidden border border-white/12 bg-[#07090b]">
      <svg viewBox="0 0 260 110" className="w-full h-24 block">
        <rect width="260" height="110" fill="#07090b" />
        {scene === 'corridor' && (
          <>
            <polygon points="0,0 92,30 92,78 0,110" fill="#10151b" />
            <polygon points="260,0 168,30 168,78 260,110" fill="#10151b" />
            <rect x="92" y="30" width="76" height="48" fill="#090c10" stroke="#2c353f" />
            <rect x="122" y="24" width="16" height="4" fill="#d97736" opacity="0.7" />
            <ellipse cx="130" cy="63" rx="9" ry="18" fill="#020304" />
            <circle cx="127" cy="52" r="1.3" fill="#e2e8f0" />
            <circle cx="133" cy="52" r="1.3" fill="#e2e8f0" />
          </>
        )}
        {scene === 'shaft' && (
          <>
            <rect x="70" y="6" width="120" height="98" fill="#0d1116" stroke="#303843" />
            <line x1="115" y1="6" x2="115" y2="104" stroke="#3f4957" strokeWidth="2" />
            <line x1="145" y1="6" x2="145" y2="104" stroke="#3f4957" strokeWidth="2" />
            <rect x="90" y="38" width="80" height="42" fill="#050709" />
            <circle cx="130" cy="56" r="18" fill="#d97736" opacity="0.14" />
          </>
        )}
        {scene === 'basement' && (
          <>
            <rect x="0" y="76" width="260" height="34" fill="#0c1012" />
            <rect x="28" y="28" width="68" height="48" fill="#161d22" stroke="#374151" />
            <circle cx="62" cy="52" r="10" fill="#c25e28" opacity="0.4" />
            <line x1="0" y1="18" x2="260" y2="18" stroke="#2d3640" strokeWidth="5" />
            <rect x="172" y="32" width="36" height="44" fill="#11161b" stroke="#2f3742" />
          </>
        )}
        {scene === 'attic' && (
          <>
            <polygon points="0,110 130,10 260,110" fill="#0d1117" stroke="#2d3742" />
            <line x1="130" y1="18" x2="130" y2="86" stroke="#64748b" strokeWidth="2" />
            <circle cx="130" cy="24" r="6" fill="#ef4444" opacity="0.7" />
            <rect x="108" y="62" width="44" height="28" fill="#161b22" stroke="#475569" />
          </>
        )}
        <text
          x="10"
          y="16"
          fill="#94a3b8"
          fontSize="8"
          fontFamily="monospace"
        >
          АРХИВ · СНИМОК
        </text>
      </svg>
      {(title || caption) && (
        <div className="px-2.5 py-2 border-t border-white/10">
          {title && (
            <div className="text-xs font-semibold text-[#e6c48a]">{title}</div>
          )}
          {caption && (
            <div className="text-[11px] text-[#a5a39c] mt-0.5">{caption}</div>
          )}
        </div>
      )}
    </div>
  );
};

export const PhoneModal: React.FC<PhoneModalProps> = ({
  history,
  nightNumber,
  weather,
  difficulty,
  isNewGamePlus,
  restoredFloorsCount,
  generatorRunning,
  notesFoundCount,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-40 bg-[#040608]/88 flex items-center justify-center p-4 pointer-events-auto">
      <div className="w-full max-w-sm rounded-[28px] bg-[#0b0e13] border-2 border-white/18 p-4 shadow-2xl flex flex-col max-h-[88vh]">
        {/* Phone Top Notch / Status */}
        <div className="flex items-center justify-between text-[11px] font-mono-num text-[#9b9a94] pb-2.5 border-b border-white/10">
          <span className="inline-flex items-center gap-1.5 text-[#e6c48a]">
            <Smartphone className="w-3.5 h-3.5" />
            НЕТ СЕТИ · ЭКСТР.
          </span>
          <span>
            Ночь #{nightNumber}
            {isNewGamePlus ? ' · НГ+' : ''}
          </span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Убрать телефон"
            className="w-8 h-8 rounded-lg bg-white/8 hover:bg-white/15 flex items-center justify-center text-[#d8d5ce]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Night Dossier Summary */}
        <div className="mt-3 p-3 rounded-xl bg-[#121720] border border-white/10 text-xs space-y-1.5">
          <div className="flex items-center justify-between text-[#d8d5ce]">
            <span className="inline-flex items-center gap-1.5 font-semibold">
              <Radio className="w-3.5 h-3.5 text-[#c97e4a]" />
              Сводка подъезда
            </span>
            <span className="font-mono-num text-[#9b9a94]">
              {DIFFICULTY_LABELS[difficulty]}
            </span>
          </div>
          <div className="text-[11px] text-[#a5a39c] flex flex-wrap gap-x-3 gap-y-1 font-mono-num">
            <span>Погода: {WEATHER_LABELS[weather]}</span>
            <span>Щитки: {restoredFloorsCount}/5</span>
            <span>Записки: {notesFoundCount}</span>
            <span>Генератор: {generatorRunning ? 'ВКЛ' : 'ВЫКЛ'}</span>
          </div>
        </div>

        {/* Messages & Calls Feed */}
        <div className="mt-3 flex-1 overflow-y-auto space-y-2.5 pr-1">
          {history.length === 0 ? (
            <div className="py-10 text-center text-xs text-[#8f8d85]">
              Входящих сообщений пока нет. Следите за сигналом на этажах.
            </div>
          ) : (
            history.map((msg) => (
              <div
                key={msg.id}
                className={`p-3 rounded-xl border ${
                  msg.isCall
                    ? 'bg-red-950/35 border-red-500/35'
                    : 'bg-[#141922] border-white/12'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-[11px] font-mono-num">
                  <span className="font-semibold text-[#e6c48a] inline-flex items-center gap-1.5">
                    {msg.isCall ? (
                      <PhoneIncoming className="w-3.5 h-3.5 text-red-400" />
                    ) : (
                      <ShieldAlert className="w-3.5 h-3.5 text-[#c97e4a]" />
                    )}
                    {msg.sender}
                  </span>
                  <span className="text-[#8f8d85]">{msg.timestamp}</span>
                </div>
                <p className="mt-1.5 text-xs sm:text-sm text-[#e8e5dc] leading-relaxed">
                  {msg.text}
                </p>
                {msg.photoScene && (
                  <ScenePreview
                    scene={msg.photoScene}
                    title={msg.photoTitle}
                    caption={msg.photoCaption}
                  />
                )}
              </div>
            ))
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-3 w-full h-11 rounded-xl bg-[#c25e28] hover:bg-[#d46a31] text-white text-sm font-semibold transition-colors"
        >
          Убрать телефон
        </button>
      </div>
    </div>
  );
};
