import React, { useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Video, VideoOff, X } from 'lucide-react';
import { CameraFeedInfo, MonsterState } from '../types';

interface CCTVModalProps {
  feeds: CameraFeedInfo[];
  activeCameraIndex: number;
  onSelectCamera: (index: number) => void;
  onClose: () => void;
}

const STATE_LABELS: Record<MonsterState, string> = {
  IDLE: 'НЕПОДВИЖЕН',
  PATROL: 'ПАТРУЛЬ',
  SUSPICIOUS: 'ПРИСЛУШИВАЕТСЯ',
  SEARCH: 'ОБЫСК',
  CHASE: 'ПРЕСЛЕДОВАНИЕ',
  LOST_TARGET: 'ТЕРЯЕТ СЛЕД',
  RETURN_PATROL: 'УХОДИТ',
};

export const CCTVModal: React.FC<CCTVModalProps> = ({
  feeds,
  activeCameraIndex,
  onSelectCamera,
  onClose,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const activeFeed = feeds[activeCameraIndex] ?? feeds[0];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !activeFeed) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let rafId = 0;
    const renderFrame = (timeMs: number) => {
      const t = timeMs * 0.001;
      const w = canvas.width;
      const h = canvas.height;

      ctx.fillStyle = '#050806';
      ctx.fillRect(0, 0, w, h);

      if (!activeFeed.online) {
        // Offline TV static
        for (let i = 0; i < 420; i++) {
          const x = Math.random() * w;
          const y = Math.random() * h;
          const bw = 2 + Math.random() * 24;
          const shade = Math.floor(30 + Math.random() * 140);
          ctx.fillStyle = `rgb(${shade}, ${shade + 8}, ${shade})`;
          ctx.fillRect(x, y, bw, 2);
        }
        ctx.fillStyle = 'rgba(10, 14, 12, 0.72)';
        ctx.fillRect(w * 0.2, h * 0.36, w * 0.6, h * 0.28);
        ctx.strokeStyle = '#dc2626';
        ctx.strokeRect(w * 0.2, h * 0.36, w * 0.6, h * 0.28);
        ctx.fillStyle = '#fca5a5';
        ctx.font = 'bold 18px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('НЕТ СИГНАЛА · ПОМЕХИ', w / 2, h / 2 + 6);
      } else {
        // Monochrome green-tinted security camera corridor perspective
        const flicker =
          activeFeed.anomaly === 'light_dip'
            ? 0.45 + Math.sin(t * 24) * 0.25
            : 0.92 + Math.sin(t * 9.5) * 0.05;

        const grad = ctx.createRadialGradient(
          w * 0.5,
          h * 0.42,
          20,
          w * 0.5,
          h * 0.5,
          w * 0.7,
        );
        grad.addColorStop(
          0,
          `rgba(36, 54, 42, ${Math.max(0.25, 0.85 * flicker)})`,
        );
        grad.addColorStop(1, 'rgba(4, 7, 5, 0.98)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Perspective corridor lines
        const vx = w * 0.5;
        const vy = h * 0.43;
        const farW = 92;
        const farH = 66;
        const fx = vx - farW / 2;
        const fy = vy - farH / 2;

        ctx.strokeStyle = 'rgba(130, 175, 142, 0.24)';
        ctx.lineWidth = 1.2;
        ctx.strokeRect(fx, fy, farW, farH);

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(fx, fy);
        ctx.moveTo(w, 0);
        ctx.lineTo(fx + farW, fy);
        ctx.moveTo(0, h);
        ctx.lineTo(fx, fy + farH);
        ctx.moveTo(w, h);
        ctx.lineTo(fx + farW, fy + farH);
        ctx.stroke();

        // Apartment door outlines along left & right walls
        ctx.fillStyle = 'rgba(18, 28, 22, 0.72)';
        ctx.fillRect(w * 0.12, h * 0.24, 34, h * 0.55);
        ctx.fillRect(w * 0.88 - 34, h * 0.24, 34, h * 0.55);
        ctx.strokeStyle = 'rgba(130, 175, 142, 0.18)';
        ctx.strokeRect(w * 0.12, h * 0.24, 34, h * 0.55);
        ctx.strokeRect(w * 0.88 - 34, h * 0.24, 34, h * 0.55);

        // Ceiling light bulb
        ctx.fillStyle = `rgba(210, 245, 215, ${0.45 * flicker})`;
        ctx.fillRect(vx - 14, fy - 12, 28, 4);

        // Shadow peek anomaly
        if (activeFeed.anomaly === 'shadow_peek') {
          ctx.fillStyle = 'rgba(3, 5, 4, 0.92)';
          ctx.beginPath();
          ctx.ellipse(w * 0.185, h * 0.44, 14, 48, 0, 0, Math.PI * 2);
          ctx.fill();
        }

        // Real-time monster silhouette when on this floor
        if (activeFeed.monsterOnFloor) {
          const depth = Math.min(1, Math.max(0.1, activeFeed.monsterNormZ));
          const scale = 0.55 + depth * 0.85;
          const mx =
            vx + (activeFeed.monsterNormX - 0.5) * (w * 0.42) * scale;
          const baseY = vy + farH * 0.5 + depth * (h * 0.36);

          // Coat / torso
          ctx.fillStyle = 'rgba(5, 7, 6, 0.96)';
          ctx.beginPath();
          ctx.moveTo(mx - 18 * scale, baseY);
          ctx.lineTo(mx - 12 * scale, baseY - 82 * scale);
          ctx.lineTo(mx + 12 * scale, baseY - 82 * scale);
          ctx.lineTo(mx + 18 * scale, baseY);
          ctx.closePath();
          ctx.fill();

          // Shoulders & head
          ctx.beginPath();
          ctx.ellipse(mx, baseY - 78 * scale, 16 * scale, 9 * scale, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(mx, baseY - 94 * scale, 9 * scale, 0, Math.PI * 2);
          ctx.fill();

          // Pale faint eyes in night-vision IR light
          ctx.fillStyle = 'rgba(232, 248, 236, 0.85)';
          ctx.fillRect(mx - 4 * scale, baseY - 96 * scale, 2.2 * scale, 2.2 * scale);
          ctx.fillRect(mx + 2 * scale, baseY - 96 * scale, 2.2 * scale, 2.2 * scale);
        }

        // Static face interference anomaly
        if (activeFeed.anomaly === 'static_face') {
          const jx = vx + (Math.random() - 0.5) * 10;
          const jy = vy + (Math.random() - 0.5) * 8;
          ctx.fillStyle = 'rgba(220, 235, 224, 0.24)';
          ctx.beginPath();
          ctx.ellipse(jx, jy, 18, 25, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = 'rgba(8, 10, 9, 0.9)';
          ctx.fillRect(jx - 8, jy - 6, 4, 4);
          ctx.fillRect(jx + 4, jy - 6, 4, 4);
          ctx.fillRect(jx - 5, jy + 7, 10, 5);
        }

        // Faint analog noise scanbars
        for (let i = 0; i < 45; i++) {
          const sx = Math.random() * w;
          const sy = Math.random() * h;
          ctx.fillStyle = 'rgba(180, 225, 190, 0.08)';
          ctx.fillRect(sx, sy, 6 + Math.random() * 18, 1.5);
        }
      }

      // CRT scanlines
      ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
      for (let y = 0; y < h; y += 3) {
        ctx.fillRect(0, y, w, 1);
      }

      // Camera HUD overlay inside CRT
      ctx.fillStyle = 'rgba(198, 238, 206, 0.88)';
      ctx.font = '12px monospace';
      ctx.textAlign = 'left';
      ctx.fillText(
        `${activeFeed.id} · ${activeFeed.label.toUpperCase()}`,
        14,
        22,
      );
      ctx.textAlign = 'right';
      ctx.fillText(
        activeFeed.online ? 'ЗАПИСЬ' : 'СБОЙ',
        w - 14,
        22,
      );

      rafId = requestAnimationFrame(renderFrame);
    };

    rafId = requestAnimationFrame(renderFrame);
    return () => cancelAnimationFrame(rafId);
  }, [activeFeed]);

  if (!activeFeed) return null;

  return (
    <div className="fixed inset-0 z-40 bg-[#040607]/92 flex items-center justify-center p-4 sm:p-6 pointer-events-auto">
      <div className="w-full max-w-2xl rounded-xl bg-[#0e1215] border border-white/15 p-4 sm:p-5 shadow-2xl">
        <div className="flex items-center justify-between gap-3 mb-3">
          <div>
            <div className="text-[11px] font-mono-num text-[#7aa885] uppercase tracking-wider">
              Пост охраны · Кв. №5
            </div>
            <h2 className="font-display text-2xl font-semibold text-[#f3efe6]">
              Монитор видеонаблюдения
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть монитор"
            className="w-10 h-10 rounded-lg bg-white/8 hover:bg-white/15 flex items-center justify-center text-[#d8d5ce]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative rounded-lg overflow-hidden border-2 border-[#232b27] bg-black">
          <canvas
            ref={canvasRef}
            width={480}
            height={270}
            className="w-full aspect-video block"
          />

          <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between gap-2 text-xs font-mono-num pointer-events-none">
            <span className="px-2.5 py-1 rounded bg-black/75 border border-white/10 text-[#b7e2c2] flex items-center gap-1.5">
              {activeFeed.online ? (
                <Video className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <VideoOff className="w-3.5 h-3.5 text-red-400" />
              )}
              {activeFeed.label}
            </span>

            {activeFeed.online && activeFeed.monsterOnFloor && (
              <span className="px-2.5 py-1 rounded bg-red-950/90 border border-red-500/50 text-red-200 font-semibold">
                ДВИЖЕНИЕ: {STATE_LABELS[activeFeed.monsterState]}
              </span>
            )}
          </div>
        </div>

        {/* Camera switcher */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onSelectCamera(activeCameraIndex - 1)}
              className="h-10 px-3 rounded-lg bg-white/8 hover:bg-white/15 border border-white/12 text-[#e6e4df] flex items-center gap-1 text-xs font-medium"
            >
              <ChevronLeft className="w-4 h-4" />
              Пред.
            </button>
            <button
              type="button"
              onClick={() => onSelectCamera(activeCameraIndex + 1)}
              className="h-10 px-3 rounded-lg bg-white/8 hover:bg-white/15 border border-white/12 text-[#e6e4df] flex items-center gap-1 text-xs font-medium"
            >
              След.
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {feeds.map((feed, idx) => {
              const active = idx === activeCameraIndex;
              return (
                <button
                  key={feed.id}
                  type="button"
                  onClick={() => onSelectCamera(idx)}
                  className={`h-10 px-3 rounded-lg border text-xs font-mono-num transition-colors ${
                    active
                      ? 'bg-[#c25e28] border-[#f59e0b]/70 text-white font-semibold'
                      : feed.monsterOnFloor && feed.online
                        ? 'bg-red-950/70 border-red-500/45 text-red-200 hover:bg-red-900/70'
                        : 'bg-[#14191e] border-white/12 text-[#b8b5ad] hover:text-white'
                  }`}
                >
                  {feed.id}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
