import React from 'react';
import {
  Pause,
  Backpack,
  FileText,
  Volume2,
  Heart,
  BatteryCharging,
  Zap,
  Eye,
  AlertTriangle,
  Smartphone,
  Award,
  ShieldAlert,
} from 'lucide-react';
import { GameState, HUDState } from '../types';
import { TOTAL_NOTES_COUNT } from '../story/NotesData';

interface GameHUDProps {
  hud: HUDState;
  onPause: () => void;
  onOpenInventory: () => void;
  onOpenPhone: () => void;
  onCloseNote: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  hud,
  onPause,
  onOpenInventory,
  onOpenPhone,
  onCloseNote,
}) => {
  if (hud.gameState === GameState.MENU || hud.gameState === GameState.ENDING) {
    return null;
  }

  const noiseColor =
    hud.noiseLevel > 70
      ? 'bg-red-500'
      : hud.noiseLevel > 40
        ? 'bg-[#e6a23c]'
        : 'bg-[#7aa885]';

  const staminaColor = hud.exhausted
    ? 'bg-red-500'
    : hud.stamina <= 30
      ? 'bg-[#e6a23c]'
      : 'bg-[#7aa885]';

  const healthColor =
    hud.health <= 35
      ? 'text-red-400'
      : hud.health <= 65
        ? 'text-[#e6c48a]'
        : 'text-[#d8d5ce]';

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-3 sm:p-5">
      {/* Damage Crimson Vignette */}
      {hud.damageFlash > 0.01 && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at center, transparent 42%, rgba(165, 22, 22, ${Math.min(0.75, hud.damageFlash * 0.72)}) 100%)`,
          }}
        />
      )}

      {/* Subtle Fear Tension Edge Vignette */}
      {hud.fearLevel > 0.35 && (
        <div
          className="fixed inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at center, transparent 58%, rgba(5, 7, 12, ${Math.min(0.55, (hud.fearLevel - 0.35) * 0.85)}) 100%)`,
          }}
        />
      )}

      {/* Door Peephole Circular Mask */}
      {hud.gameState === GameState.PEEPHOLE && (
        <div
          className="fixed inset-0 pointer-events-none flex flex-col items-center justify-between py-14"
          style={{
            background:
              'radial-gradient(circle at center, transparent 22%, rgba(3, 4, 6, 0.94) 37%, #020304 54%)',
          }}
        >
          <div className="px-4 py-1.5 rounded-lg bg-[#090b0e]/90 border border-white/15 text-xs font-mono-num text-[#e6c48a]">
            {hud.peepholeLabel ?? 'Дверной глазок'}
          </div>
          <div className="px-4 py-2 rounded-lg bg-[#090b0e]/90 border border-white/12 text-xs text-[#c8c5bc]">
            Свайп / мышь — осмотреться · E / V или «Выйти» — отойти
          </div>
        </div>
      )}

      {/* Top Bar: Pause, Inventory, Phone on left; status panel on right */}
      {hud.gameState !== GameState.CUTSCENE && (
        <div className="relative z-10 flex items-start justify-between gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 sm:gap-2 pointer-events-auto">
            <button
              type="button"
              onClick={onPause}
              className="h-11 px-3 sm:px-3.5 rounded-lg bg-[#0a0c0f]/82 border border-white/15 text-[#e6e4df] hover:bg-[#14181e] flex items-center gap-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0"
              aria-label="Пауза"
            >
              <Pause className="w-4 h-4" />
              <span className="hidden sm:inline">Пауза</span>
            </button>

            <button
              type="button"
              onClick={onOpenInventory}
              className="h-11 px-3 sm:px-3.5 rounded-lg bg-[#0a0c0f]/82 border border-white/15 text-[#e6e4df] hover:bg-[#14181e] flex items-center gap-2 text-sm font-medium transition-colors whitespace-nowrap shrink-0"
              aria-label="Инвентарь и записки"
              title="Инвентарь и записки (Tab / I)"
            >
              <Backpack className="w-4 h-4 text-[#e6c48a]" />
              <span className="font-mono-num text-xs sm:text-sm">
                {hud.inventory.length}/{hud.maxInventorySlots}
              </span>
            </button>

            <button
              type="button"
              onClick={onOpenPhone}
              className={`relative h-11 px-3 sm:px-3.5 rounded-lg border flex items-center gap-1.5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                hud.phoneUnreadCount > 0
                  ? 'bg-[#1a1510]/90 border-[#f59e0b]/65 text-[#f6deb2]'
                  : 'bg-[#0a0c0f]/82 border-white/15 text-[#e6e4df] hover:bg-[#14181e]'
              }`}
              aria-label="Телефон"
              title="Телефон (P)"
            >
              <Smartphone className="w-4 h-4 text-[#c97e4a]" />
              <span className="hidden sm:inline">Телефон</span>
              {hud.phoneUnreadCount > 0 && (
                <span className="ml-0.5 px-1.5 py-0.5 rounded bg-[#c25e28] text-white font-mono-num text-[10px] leading-none font-bold">
                  {hud.phoneUnreadCount}
                </span>
              )}
            </button>
          </div>

          <div className="flex flex-col items-end text-right bg-[#0a0c0f]/78 border border-white/10 rounded-lg px-3 py-2 max-w-[58vw] sm:max-w-none">
            <div className="flex items-center gap-1.5 sm:gap-2 text-[11px] sm:text-sm text-[#e6e4df] font-mono-num truncate">
              <span className="truncate">{hud.locationName}</span>
              <span aria-hidden="true" className="text-white/30">
                ·
              </span>
              <span className="shrink-0">
                Лифт {hud.elevatorFloor}
                {hud.elevatorPowered ? '' : ' (выкл)'}
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-x-2.5 gap-y-1 mt-1 text-[11px] font-mono-num text-[#a5a39c]">
              <span className={`inline-flex items-center gap-1 ${healthColor}`}>
                <Heart className="w-3 h-3" />
                {hud.health}%
              </span>

              <span
                className={`inline-flex items-center gap-1 ${
                  hud.battery <= 20 ? 'text-red-400' : 'text-[#e6c48a]'
                }`}
              >
                <BatteryCharging className="w-3 h-3" />
                {hud.battery}%
              </span>

              <span className="inline-flex items-center gap-1">
                <FileText className="w-3 h-3" />
                {hud.notesFound.length}/{TOTAL_NOTES_COUNT}
              </span>
            </div>

            {/* Stamina + Noise Bars */}
            <div className="flex flex-wrap items-center justify-end gap-x-3 gap-y-1 mt-1.5 text-[10px] font-mono-num text-[#9b9a94]">
              <div
                className="flex items-center gap-1.5"
                title="Выносливость для бега"
              >
                <Zap
                  className={`w-3 h-3 ${hud.exhausted ? 'text-red-400' : 'text-[#9ec4b0]'}`}
                />
                <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-100 ${staminaColor}`}
                    style={{ width: `${Math.max(0, Math.min(100, hud.stamina))}%` }}
                  />
                </div>
                <span className={hud.exhausted ? 'text-red-400' : 'text-[#9ec4b0]'}>
                  {hud.stamina}%
                </span>
              </div>

              <div className="flex items-center gap-1.5" title="Уровень шума">
                <Volume2 className="w-3 h-3 text-[#b8b5ad]" />
                <div className="w-12 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-150 ${noiseColor}`}
                    style={{ width: `${Math.min(100, Math.max(4, hud.noiseLevel))}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="mt-1 text-[10px] font-mono-num text-[#c97e4a] truncate">
              {hud.generatorRunning
                ? `Генератор: ВКЛ · Ночь #${hud.nightNumber}${hud.isNewGamePlus ? ' (НГ+)' : ''}`
                : `Генератор: топл. ${hud.generatorFuelAdded ? '1/1' : '0/1'} · пред. ${hud.generatorFusesInserted}/3`}
            </div>
          </div>
        </div>
      )}

      {/* Danger / Attack Windup Indicator */}
      {(hud.monsterWindingUp || (hud.dangerLevel > 0.35 && hud.gameState === GameState.PLAYING)) && (
        <div className="fixed top-20 sm:top-22 left-1/2 -translate-x-1/2 z-20 pointer-events-none flex flex-col items-center gap-1.5">
          {hud.monsterWindingUp ? (
            <div className="px-4 py-1.5 rounded-lg bg-red-950/92 border border-red-500/75 text-xs font-semibold text-red-100 flex items-center gap-2 shadow-lg">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>Замах! Уйдите в сторону или бегите!</span>
            </div>
          ) : (
            <div className="px-3.5 py-1 rounded-lg bg-[#140a0a]/85 border border-red-500/40 text-[11px] font-mono-num text-red-200 flex items-center gap-2">
              <span>Опасность рядом</span>
              <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-red-500 transition-all duration-150"
                  style={{ width: `${Math.round(hud.dangerLevel * 100)}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Incoming Phone SMS / Call Toast */}
      {hud.phoneMessage &&
        (hud.gameState === GameState.PLAYING || hud.gameState === GameState.HIDING) && (
          <button
            type="button"
            onClick={onOpenPhone}
            className="fixed top-24 left-3 sm:left-5 z-20 max-w-xs text-left p-3 rounded-xl bg-[#0e131a]/94 border border-[#c25e28]/60 shadow-xl pointer-events-auto hover:bg-[#151c26] transition-colors"
          >
            <div className="flex items-center justify-between gap-2 text-[11px] font-mono-num text-[#e6c48a]">
              <span className="inline-flex items-center gap-1.5 font-semibold">
                <Smartphone className="w-3.5 h-3.5" />
                {hud.phoneMessage.isCall ? 'Входящий вызов' : hud.phoneMessage.sender}
              </span>
              <span className="text-[#8f8d85]">{hud.phoneMessage.timestamp}</span>
            </div>
            <div className="mt-1 text-xs text-[#e8e5dc] line-clamp-2">
              {hud.phoneMessage.text}
            </div>
            <div className="mt-1 text-[10px] text-[#c97e4a]">
              Нажмите (или P), чтобы открыть телефон
            </div>
          </button>
        )}

      {/* Achievement Unlocked Toast */}
      {hud.achievementToast && (
        <div className="fixed top-36 sm:top-28 right-3 sm:right-5 z-20 max-w-xs p-3 rounded-xl bg-[#101613]/94 border border-emerald-500/45 shadow-xl pointer-events-none">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
            <Award className="w-4 h-4 shrink-0" />
            <span>Достижение: {hud.achievementToast.title}</span>
          </div>
          <div className="mt-1 text-[11px] text-[#c8c5bc]">
            {hud.achievementToast.description}
          </div>
        </div>
      )}

      {/* Hiding Banner */}
      {hud.gameState === GameState.HIDING && (
        <div className="fixed top-22 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2 pointer-events-none">
          <div className="px-4 py-2 rounded-lg bg-[#090b0e]/90 border border-white/15 text-center">
            <div className="text-xs font-mono-num text-[#e6c48a]">
              Укрытие: {hud.hidingSpotName ?? 'Укрытие'}
            </div>
            <div className="text-[11px] text-[#b8b5ad] mt-0.5">
              Нажмите E / C или «Выйти», чтобы выбраться
            </div>
          </div>

          {hud.flashlightOn && (
            <div className="px-3.5 py-1.5 rounded-lg bg-red-950/90 border border-red-500/45 text-xs text-red-200 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span>Выключите фонарик (F) — свет заметен снаружи!</span>
            </div>
          )}
        </div>
      )}

      {/* Center Reticle & Contextual Interaction Prompt */}
      {hud.gameState === GameState.PLAYING && (
        <div className="fixed inset-0 flex flex-col items-center justify-center pointer-events-none">
          <div
            className={`rounded-full transition-all ${
              hud.activePrompt
                ? 'w-2 h-2 bg-[#f59e0b] ring-4 ring-[#f59e0b]/25'
                : 'w-1.5 h-1.5 bg-white/45'
            }`}
          />
          {hud.activePrompt && (
            <div className="mt-4 px-3.5 py-2 rounded-lg bg-[#0a0c0f]/86 border border-white/15 text-center max-w-[280px]">
              <div className="text-xs text-[#a5a39c] truncate">{hud.activePrompt.title}</div>
              <div className="text-sm font-semibold text-[#f3efe6] mt-0.5">
                {hud.activePrompt.actionText}
              </div>
              {hud.activePrompt.secondaryActionText && (
                <div className="mt-1 pt-1 border-t border-white/10 text-[11px] text-[#9ec4d8] flex items-center justify-center gap-1">
                  <Eye className="w-3 h-3" />
                  <span>V: {hud.activePrompt.secondaryActionText}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Atmospheric Subtitle Strip */}
      <div className="relative z-10 flex justify-center pb-32 sm:pb-10">
        {hud.subtitle &&
          (hud.gameState === GameState.PLAYING ||
            hud.gameState === GameState.HIDING ||
            hud.gameState === GameState.PEEPHOLE) && (
            <div className="px-4 py-2.5 rounded-lg bg-[#090b0e]/90 border border-white/12 text-xs sm:text-sm text-[#e8e5dc] text-center max-w-md leading-relaxed">
              {hud.subtitle}
            </div>
          )}
      </div>

      {/* Readable Note Modal (GameState.INSPECTING) */}
      {hud.gameState === GameState.INSPECTING && hud.activeNote && (
        <div className="fixed inset-0 z-30 bg-[#050608]/88 flex items-center justify-center p-5 pointer-events-auto">
          <div className="w-full max-w-md rounded-xl bg-[#161412] border border-[#d6c7a9]/25 p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="text-xs text-[#a69b86] font-mono-num">
              {hud.activeNote.floorLabel}
            </div>
            <h2 className="font-display text-2xl font-semibold text-[#f0e9db] mt-1.5">
              {hud.activeNote.title}
            </h2>
            <div className="mt-4 space-y-3 text-sm sm:text-[15px] leading-relaxed text-[#d7d0c2]">
              {hud.activeNote.body.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>
            {hud.activeNote.hint && (
              <div className="mt-4 pt-3 border-t border-[#d6c7a9]/15 text-xs text-[#e6c48a]">
                {hud.activeNote.hint}
              </div>
            )}
            <div className="mt-6 flex justify-end">
              <button
                type="button"
                onClick={onCloseNote}
                className="h-11 px-5 rounded-lg bg-[#c25e28] hover:bg-[#d46a31] text-white text-sm font-semibold transition-colors"
              >
                Закрыть
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
