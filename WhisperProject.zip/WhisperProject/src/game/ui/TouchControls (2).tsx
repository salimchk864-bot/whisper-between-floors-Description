import React, { useEffect, useRef, useState } from 'react';
import {
  Flashlight,
  Hand,
  ArrowDownToLine,
  Eye,
  Zap,
  LogOut,
} from 'lucide-react';
import { GameState, InteractPrompt, TouchScalePreset } from '../types';

interface TouchControlsProps {
  gameState: GameState;
  crouching: boolean;
  sprinting: boolean;
  exhausted: boolean;
  flashlightOn: boolean;
  activePrompt: InteractPrompt | null;
  touchScale: TouchScalePreset;
  controlsSwapHands: boolean;
  onJoystickMove: (x: number, y: number) => void;
  onSprintChange: (active: boolean) => void;
  onLookDelta: (dx: number, dy: number) => void;
  onToggleCrouch: () => void;
  onToggleFlashlight: () => void;
  onInteract: () => void;
  onSecondaryInteract: () => void;
}

const JOYSTICK_MAX_RADIUS = 40;

const SCALE_CLASSES: Record<TouchScalePreset, string> = {
  compact: 'scale-90',
  standard: 'scale-100',
  large: 'scale-110',
};

export const TouchControls: React.FC<TouchControlsProps> = ({
  gameState,
  crouching,
  sprinting,
  exhausted,
  flashlightOn,
  activePrompt,
  touchScale,
  controlsSwapHands,
  onJoystickMove,
  onSprintChange,
  onLookDelta,
  onToggleCrouch,
  onToggleFlashlight,
  onInteract,
  onSecondaryInteract,
}) => {
  const [knobOffset, setKnobOffset] = useState({ x: 0, y: 0 });
  const [joystickActive, setJoystickActive] = useState(false);
  const [sprintToggled, setSprintToggled] = useState(false);

  const joyZoneRef = useRef<HTMLDivElement>(null);
  const joyPointerId = useRef<number | null>(null);
  const joyOrigin = useRef({ x: 0, y: 0 });

  const lookPointerId = useRef<number | null>(null);
  const lastLookPos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    if (exhausted && sprintToggled) {
      setSprintToggled(false);
      onSprintChange(false);
    }
  }, [exhausted, sprintToggled, onSprintChange]);

  useEffect(() => {
    if (gameState !== GameState.PLAYING && sprintToggled) {
      setSprintToggled(false);
      onSprintChange(false);
    }
  }, [gameState, sprintToggled, onSprintChange]);

  const handleToggleSprint = (e: React.MouseEvent | React.PointerEvent) => {
    e.stopPropagation();
    if (exhausted) return;
    const next = !sprintToggled;
    setSprintToggled(next);
    onSprintChange(next);
  };

  const handleJoyPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== null) return;
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    joyPointerId.current = e.pointerId;

    const rect = joyZoneRef.current?.getBoundingClientRect();
    if (rect) {
      joyOrigin.current = {
        x: rect.left + rect.width / 2,
        y: rect.top + rect.height / 2,
      };
    } else {
      joyOrigin.current = { x: e.clientX, y: e.clientY };
    }
    setJoystickActive(true);
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    updateJoystick(e.clientX, e.clientY);
  };

  const handleJoyPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPointerId.current !== e.pointerId) return;
    e.stopPropagation();
    joyPointerId.current = null;
    setJoystickActive(false);
    setKnobOffset({ x: 0, y: 0 });
    onJoystickMove(0, 0);
  };

  const updateJoystick = (clientX: number, clientY: number) => {
    const dx = clientX - joyOrigin.current.x;
    const dy = clientY - joyOrigin.current.y;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(dist, JOYSTICK_MAX_RADIUS);
    const angle = Math.atan2(dy, dx);

    const kx = dist > 0.001 ? Math.cos(angle) * clamped : 0;
    const ky = dist > 0.001 ? Math.sin(angle) * clamped : 0;

    setKnobOffset({ x: kx, y: ky });
    onJoystickMove(kx / JOYSTICK_MAX_RADIUS, -ky / JOYSTICK_MAX_RADIUS);
  };

  const handleLookPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== null) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    lookPointerId.current = e.pointerId;
    lastLookPos.current = { x: e.clientX, y: e.clientY };
  };

  const handleLookPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    const dx = e.clientX - lastLookPos.current.x;
    const dy = e.clientY - lastLookPos.current.y;
    lastLookPos.current = { x: e.clientX, y: e.clientY };
    onLookDelta(dx, dy);
  };

  const handleLookPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPointerId.current !== e.pointerId) return;
    lookPointerId.current = null;
  };

  const isSpecialView =
    gameState === GameState.HIDING || gameState === GameState.PEEPHOLE;

  const scaleClass = SCALE_CLASSES[touchScale] ?? 'scale-100';
  const moveSideClass = controlsSwapHands
    ? 'right-4 sm:right-8 origin-bottom-right flex-row-reverse'
    : 'left-4 sm:left-8 origin-bottom-left';
  const actionSideClass = controlsSwapHands
    ? 'left-4 sm:left-8 origin-bottom-left flex-row-reverse'
    : 'right-4 sm:right-8 origin-bottom-right';
  const sprintActive = sprintToggled || sprinting;

  return (
    <div className="fixed inset-0 z-10 pointer-events-none">
      {/* Fullscreen swipe-to-look layer */}
      <div
        className="absolute inset-0 pointer-events-auto touch-none"
        onPointerDown={handleLookPointerDown}
        onPointerMove={handleLookPointerMove}
        onPointerUp={handleLookPointerUp}
        onPointerCancel={handleLookPointerUp}
        aria-label="Область поворота камеры свайпом"
      />

      {/* Virtual Joystick + Sprint Toggle */}
      {!isSpecialView && (
        <div
          className={`absolute bottom-5 sm:bottom-8 ${moveSideClass} ${scaleClass} flex items-end gap-3 pointer-events-auto`}
        >
          <div
            ref={joyZoneRef}
            onPointerDown={handleJoyPointerDown}
            onPointerMove={handleJoyPointerMove}
            onPointerUp={handleJoyPointerUp}
            onPointerCancel={handleJoyPointerUp}
            className="w-28 h-28 rounded-full border border-white/15 bg-[#0a0c0f]/60 flex items-center justify-center touch-none"
            role="application"
            aria-label="Джойстик движения"
          >
            <div
              className={`w-12 h-12 rounded-full border transition-colors ${
                joystickActive
                  ? 'bg-[#d97736]/80 border-[#f59e0b]/80'
                  : 'bg-white/15 border-white/25'
              }`}
              style={{
                transform: `translate3d(${knobOffset.x}px, ${knobOffset.y}px, 0)`,
              }}
            />
          </div>

          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={handleToggleSprint}
            disabled={exhausted}
            className={`w-14 h-14 rounded-xl border flex flex-col items-center justify-center gap-0.5 transition-colors ${
              exhausted
                ? 'bg-red-950/60 border-red-500/40 text-red-300/70'
                : sprintActive
                  ? 'bg-[#c25e28]/90 border-[#f59e0b]/85 text-white shadow-md'
                  : 'bg-[#0a0c0f]/78 border-white/15 text-[#d8d5ce]'
            }`}
            aria-label="Переключить бег"
            aria-pressed={sprintActive}
            title="Бег (переключение / Shift)"
          >
            <Zap className="w-4 h-4" />
            <span className="text-[10px] leading-none font-medium">
              {exhausted ? 'Устал' : sprintActive ? 'Бежит' : 'Бег'}
            </span>
          </button>
        </div>
      )}

      {/* Action Buttons */}
      <div
        className={`absolute bottom-5 sm:bottom-8 ${actionSideClass} ${scaleClass} flex items-end gap-2.5 pointer-events-auto`}
      >
        {!isSpecialView && (
          <div className="flex flex-col gap-2.5">
            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={onToggleCrouch}
              className={`w-13 h-13 rounded-xl border flex flex-col items-center justify-center gap-0.5 transition-colors ${
                crouching
                  ? 'bg-[#c25e28]/85 border-[#f59e0b]/70 text-white'
                  : 'bg-[#0a0c0f]/78 border-white/15 text-[#d8d5ce]'
              }`}
              aria-label="Присесть"
              title="Присесть (C)"
            >
              <ArrowDownToLine className="w-5 h-5" />
              <span className="text-[10px] leading-none font-medium">Присед</span>
            </button>

            <button
              type="button"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={onToggleFlashlight}
              className={`w-13 h-13 rounded-xl border flex flex-col items-center justify-center gap-0.5 transition-colors ${
                flashlightOn
                  ? 'bg-[#e6c48a]/20 border-[#e6c48a]/65 text-[#f6deb2]'
                  : 'bg-[#0a0c0f]/78 border-white/15 text-[#9a9890]'
              }`}
              aria-label="Фонарик"
              title="Фонарик (F)"
            >
              <Flashlight className="w-5 h-5" />
              <span className="text-[10px] leading-none font-medium">Свет</span>
            </button>
          </div>
        )}

        {gameState === GameState.HIDING && (
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={onToggleFlashlight}
            className={`w-13 h-13 rounded-xl border flex flex-col items-center justify-center gap-0.5 transition-colors ${
              flashlightOn
                ? 'bg-[#e6c48a]/20 border-[#e6c48a]/65 text-[#f6deb2]'
                : 'bg-[#0a0c0f]/78 border-white/15 text-[#9a9890]'
            }`}
            aria-label="Фонарик"
          >
            <Flashlight className="w-5 h-5" />
            <span className="text-[10px] leading-none font-medium">Свет</span>
          </button>
        )}

        {!isSpecialView && activePrompt?.secondaryActionText && (
          <button
            type="button"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={onSecondaryInteract}
            className="w-14 h-14 rounded-xl border bg-[#141920]/90 border-[#94a3b8]/50 text-[#e6e4df] flex flex-col items-center justify-center gap-1 transition-colors"
            aria-label={activePrompt.secondaryActionText}
            title="Посмотреть в глазок (V)"
          >
            <Eye className="w-5 h-5" />
            <span className="text-[10px] leading-none font-medium">Глазок</span>
          </button>
        )}

        <button
          type="button"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={onInteract}
          disabled={!isSpecialView && !activePrompt}
          className={`w-16 h-16 rounded-2xl border flex flex-col items-center justify-center gap-1 transition-all ${
            isSpecialView || activePrompt
              ? 'bg-[#c25e28]/90 border-[#f59e0b]/80 text-white shadow-lg'
              : 'bg-[#0a0c0f]/55 border-white/10 text-white/30'
          }`}
          aria-label={
            isSpecialView
              ? 'Выйти'
              : activePrompt
                ? activePrompt.actionText
                : 'Взаимодействие'
          }
          title="Взаимодействие (E)"
        >
          {isSpecialView ? <LogOut className="w-6 h-6" /> : <Hand className="w-6 h-6" />}
          <span className="text-[10px] leading-none font-semibold">
            {isSpecialView ? 'Выйти' : 'Действие'}
          </span>
        </button>
      </div>
    </div>
  );
};
