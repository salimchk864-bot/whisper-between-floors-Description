import React, { useEffect, useState } from 'react';
import { Delete, KeyRound, X } from 'lucide-react';
import { KeypadPromptInfo } from '../types';

interface KeypadModalProps {
  keypad: KeypadPromptInfo;
  onSubmitCode: (code: string) => boolean;
  onClose: () => void;
}

export const KeypadModal: React.FC<KeypadModalProps> = ({
  keypad,
  onSubmitCode,
  onClose,
}) => {
  const [digits, setDigits] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const appendDigit = (d: string) => {
    setErrorMsg(null);
    setDigits((prev) => (prev.length < 4 ? prev + d : prev));
  };

  const handleSubmit = () => {
    if (digits.length < 4) {
      setErrorMsg('Введите все 4 цифры кода.');
      return;
    }
    const ok = onSubmitCode(digits);
    if (!ok) {
      setErrorMsg('Неверный код. Сверьте обе половины в кв. 2 и кв. 5.');
      setDigits('');
    }
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key >= '0' && e.key <= '9') {
        appendDigit(e.key);
      } else if (e.key === 'Backspace') {
        setErrorMsg(null);
        setDigits((prev) => prev.slice(0, -1));
      } else if (e.key === 'Enter') {
        handleSubmit();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [digits]);

  return (
    <div className="fixed inset-0 z-40 bg-[#040608]/90 flex items-center justify-center p-4 pointer-events-auto">
      <div className="w-full max-w-xs rounded-2xl bg-[#10141a] border border-white/18 p-5 shadow-2xl">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-[11px] font-mono-num text-[#c97e4a] inline-flex items-center gap-1">
              <KeyRound className="w-3.5 h-3.5" />
              КОДОВЫЙ ЗАМОК
            </div>
            <h2 className="font-display text-xl font-semibold text-[#f3efe6] mt-0.5">
              {keypad.title}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть кодовый замок"
            className="w-9 h-9 rounded-lg bg-white/8 hover:bg-white/15 flex items-center justify-center text-[#b8b5ad]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="mt-2 text-xs text-[#a5a39c] leading-relaxed">
          {keypad.hint}
        </p>

        {/* 4-digit PIN display */}
        <div className="mt-4 grid grid-cols-4 gap-2">
          {[0, 1, 2, 3].map((slot) => (
            <div
              key={slot}
              className="h-12 rounded-lg bg-[#07090d] border border-white/18 flex items-center justify-center font-mono-num text-xl font-bold text-[#e6c48a]"
            >
              {digits[slot] ?? '—'}
            </div>
          ))}
        </div>

        {errorMsg && (
          <div className="mt-2.5 text-xs text-red-400 text-center">
            {errorMsg}
          </div>
        )}

        {/* Numeric keypad */}
        <div className="mt-4 grid grid-cols-3 gap-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => appendDigit(d)}
              className="h-12 rounded-xl bg-[#181e27] hover:bg-[#232b38] border border-white/12 text-[#f3efe6] font-mono-num text-lg font-semibold transition-colors"
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              setErrorMsg(null);
              setDigits((prev) => prev.slice(0, -1));
            }}
            aria-label="Стереть цифру"
            className="h-12 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-[#b8b5ad] flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => appendDigit('0')}
            className="h-12 rounded-xl bg-[#181e27] hover:bg-[#232b38] border border-white/12 text-[#f3efe6] font-mono-num text-lg font-semibold transition-colors"
          >
            0
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            className="h-12 rounded-xl bg-[#c25e28] hover:bg-[#d46a31] text-white text-xs font-semibold transition-colors"
          >
            Ввод
          </button>
        </div>
      </div>
    </div>
  );
};
