import React, { useRef, useState } from 'react';
import {
  Download,
  FileArchive,
  FolderCode,
  Save,
  Share2,
  Upload,
  X,
} from 'lucide-react';
import { SaveManager } from '../save/SaveManager';

interface DownloadModalProps {
  onClose: () => void;
  onSaveImported: () => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  onClose,
  onSaveImported,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [zipDownloading, setZipDownloading] = useState(false);
  const [zipStatus, setZipStatus] = useState<string | null>(null);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const handleDownloadProjectZip = async () => {
    if (zipDownloading) return;
    setZipDownloading(true);
    setZipStatus(null);
    try {
      const response = await fetch('/whisper-between-floors.zip');
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'whisper-between-floors.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setZipStatus(
        'Архив с готовым Android-проектом (папка android/ + сборщик Whisper_Between_Floors.apk) скачан.',
      );
    } catch {
      setZipStatus('Не удалось скачать архив. Попробуйте ещё раз.');
    } finally {
      setZipDownloading(false);
    }
  };

  const handleExportSave = () => {
    const json = SaveManager.exportBackupJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'whisper-floors-save.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setSaveMessage('Файл сохранения скачан.');
  };

  const handleShareSaveFile = async () => {
    const json = SaveManager.exportBackupJson();
    const file = new File([json], 'whisper-floors-save.json', {
      type: 'application/json',
    });
    if (
      typeof navigator !== 'undefined' &&
      typeof navigator.canShare === 'function' &&
      navigator.canShare({ files: [file] })
    ) {
      try {
        await navigator.share({
          title: 'Сохранение «Шёпот между этажами»',
          files: [file],
        });
        setSaveMessage('Файл сохранения отправлен.');
        return;
      } catch {
        // Fallback to direct download
      }
    }
    handleExportSave();
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const res = SaveManager.importBackupJson(text);
      if (res.ok) {
        onSaveImported();
        setSaveMessage(
          res.hasSave
            ? 'Прогресс, концовки и достижения восстановлены.'
            : 'Концовки и достижения импортированы.',
        );
      } else {
        setSaveMessage('Неверный формат файла сохранения.');
      }
    } catch {
      setSaveMessage('Не удалось прочитать файл.');
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="fixed inset-0 z-40 bg-[#050608]/90 flex items-center justify-center p-4 sm:p-6 pointer-events-auto">
      <div className="w-full max-w-lg rounded-xl bg-[#0e1116] border border-white/15 p-6 shadow-2xl max-h-[92vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-xs font-mono-num tracking-wider text-[#c97e4a]">
              COLD SILENCE STUDIO · v0.5.0 · ANDROID APK
            </div>
            <h2 className="font-display text-3xl font-semibold text-[#f3efe6] mt-1">
              Получить Whisper_Between_Floors.apk
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть"
            className="w-9 h-9 rounded-lg bg-white/6 hover:bg-white/12 flex items-center justify-center text-[#b8b5ad]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-5 space-y-4">
          {/* 1. Honest status + Complete Android Project Download */}
          <div className="p-4 rounded-xl bg-[#13171e] border border-[#c25e28]/45">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#c25e28]/18 border border-[#c25e28]/40 flex items-center justify-center shrink-0 text-[#e6c48a]">
                <FileArchive className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[#f3efe6]">
                  1. Скачать готовый Android-проект для сборки APK
                </div>
                <p className="text-xs text-[#b8b5ad] mt-1.5 leading-relaxed">
                  В этой облачной среде отсутствуют Java JDK и Android SDK, поэтому
                  скомпилировать бинарный <span className="font-mono-num text-[#e6c48a]">.apk</span>{' '}
                  напрямую здесь нельзя. В архиве ниже лежит{' '}
                  <strong className="text-[#f3efe6]">полный автономный Android-проект</strong>{' '}
                  (папка <span className="font-mono-num text-[#e6c48a]">android/</span> со
                  вшитыми офлайн-ассетами игры, без загрузки сайта).
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-2.5">
                  <button
                    type="button"
                    onClick={handleDownloadProjectZip}
                    disabled={zipDownloading}
                    className="h-10 px-4 rounded-lg bg-[#c25e28] hover:bg-[#d46a31] disabled:opacity-60 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    {zipDownloading
                      ? 'Подготовка архива...'
                      : 'Скачать Android-проект (.zip)'}
                  </button>
                  {zipStatus && (
                    <span className="text-xs text-[#e6c48a]">{zipStatus}</span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 2. How to compile Whisper_Between_Floors.apk */}
          <div className="p-4 rounded-xl bg-[#13171e] border border-white/12">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-white/6 border border-white/12 flex items-center justify-center shrink-0 text-[#e6c48a]">
                <FolderCode className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[#f3efe6]">
                  2. Как получить файл Whisper_Between_Floors.apk
                </div>
                <ul className="mt-1.5 space-y-1.5 text-xs text-[#9b9a94] leading-relaxed">
                  <li>
                    <strong className="text-[#e6e4df]">Через GitHub (без программ на ПК):</strong>{' '}
                    загрузите файлы из архива в репозиторий GitHub, откройте вкладку{' '}
                    <span className="font-mono-num text-[#c8c5bc]">Actions → Build Android APK</span>{' '}
                    и скачайте готовый{' '}
                    <span className="font-mono-num text-[#e6c48a]">Whisper_Between_Floors.apk</span>.
                  </li>
                  <li>
                    <strong className="text-[#e6e4df]">Через Android Studio:</strong>{' '}
                    распакуйте архив, откройте папку{' '}
                    <span className="font-mono-num text-[#c8c5bc]">android/</span> и нажмите{' '}
                    <span className="font-mono-num text-[#c8c5bc]">Build → Build APK(s)</span>.
                  </li>
                  <li>
                    <strong className="text-[#e6e4df]">Через терминал:</strong>{' '}
                    выполните{' '}
                    <span className="font-mono-num text-[#c8c5bc]">bash scripts/build-android-apk.sh</span>.
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* 3. Save Export / Share / Import */}
          <div className="p-4 rounded-xl bg-[#13171e] border border-white/12">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-white/6 border border-white/12 flex items-center justify-center shrink-0 text-[#e6c48a]">
                <Save className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-[#f3efe6]">
                  3. Перенос сохранения в APK-версию (.json)
                </div>
                <p className="text-xs text-[#9b9a94] mt-1 leading-relaxed">
                  Сохраните или отправьте прогресс, концовки и достижения для переноса
                  в установленное Android-приложение.
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleExportSave}
                    className="h-9 px-3.5 rounded-lg bg-white/8 hover:bg-white/14 border border-white/14 text-[#e6e4df] text-xs font-medium inline-flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Скачать (.json)
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleShareSaveFile()}
                    className="h-9 px-3.5 rounded-lg bg-white/8 hover:bg-white/14 border border-white/14 text-[#e6c48a] text-xs font-medium inline-flex items-center gap-1.5 transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    Отправить файл
                  </button>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="h-9 px-3.5 rounded-lg bg-white/8 hover:bg-white/14 border border-white/14 text-[#b8b5ad] hover:text-white text-xs font-medium inline-flex items-center gap-1.5 transition-colors"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Загрузить
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="application/json,.json"
                    onChange={(e) => void handleImportFile(e)}
                    className="hidden"
                  />
                </div>
                {saveMessage && (
                  <p className="mt-2 text-xs text-[#e6c48a]">{saveMessage}</p>
                )}
              </div>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="mt-5 w-full h-11 rounded-lg bg-white/8 hover:bg-white/14 border border-white/14 text-[#f3efe6] text-sm font-medium transition-colors"
        >
          Закрыть
        </button>
      </div>
    </div>
  );
};
