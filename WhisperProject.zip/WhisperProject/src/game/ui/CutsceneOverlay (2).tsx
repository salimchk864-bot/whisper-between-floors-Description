import React from 'react';
import { SkipForward } from 'lucide-react';
import { CutsceneInfo } from '../types';

interface CutsceneOverlayProps {
  cutscene: CutsceneInfo;
  onSkip: () => void;
}

export const CutsceneOverlay: React.FC<CutsceneOverlayProps> = ({
  cutscene,
  onSkip,
}) => {
  return (
    <div className="fixed inset-0 z-30 pointer-events-none flex flex-col justify-between">
      {/* Top cinematic bar */}
      <div className="h-16 sm:h-20 bg-[#040507] border-b border-white/8 flex items-center justify-between px-5 sm:px-8 pointer-events-auto">
        <div className="text-xs font-mono-num text-[#c97e4a] tracking-wide">
          {cutscene.title}
        </div>
        <button
          type="button"
          onClick={onSkip}
          className="h-9 px-3.5 rounded-lg bg-white/10 hover:bg-white/20 border border-white/15 text-xs font-medium text-[#f3efe6] flex items-center gap-1.5 transition-colors"
        >
          <span>Пропустить</span>
          <SkipForward className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Bottom cinematic bar */}
      <div className="h-20 sm:h-24 bg-[#040507] border-t border-white/8 flex items-center justify-center px-6 text-center">
        <p className="text-sm sm:text-base text-[#e8e5dc] max-w-2xl leading-relaxed">
          {cutscene.caption}
        </p>
      </div>
    </div>
  );
};
