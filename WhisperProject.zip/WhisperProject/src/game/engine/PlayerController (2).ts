import * as THREE from 'three';
import { BUILDING } from '../world/BuildingConfig';
import { CollisionWorld } from './CollisionWorld';
import { SoundEngine } from '../audio/SoundEngine';
import { GameSettings, InputState } from '../types';

const _forward = new THREE.Vector3();
const _right = new THREE.Vector3();
const _moveDir = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _lookDir = new THREE.Vector3();

export interface HidingCameraTarget {
  id: string;
  name: string;
  camPos: THREE.Vector3;
  lookYaw: number;
  lookPitch: number;
  returnPos: THREE.Vector3;
}

export interface PeepholeCameraTarget {
  label: string;
  camPos: THREE.Vector3;
  lookYaw: number;
  lookPitch: number;
}

export class PlayerController {
  public position = new THREE.Vector3(-0.6, 0.0, -0.5);
  public yaw = Math.PI * 0.85;
  public pitch = -0.02;
  public crouching = false;
  public sprinting = false;
  public flashlightOn = true;

  public health = 100;
  public stamina = 100;
  public exhausted = false;
  public battery = 100;
  public noiseLevel = 0; // 0..100

  private velocityY = 0;
  private currentEyeHeight: number = BUILDING.EYE_STANDING;
  private bobPhase = 0;
  private lastStepHalfCycle = 0;
  private surfaceKind: 'concrete' | 'metal' | 'wood' = 'concrete';
  private noiseImpulse = 0;
  private damageFlash = 0;
  private exhaustedTimer = 0;
  private adrenalineTimer = 0;
  private invulnTimer = 0;

  // Hiding / Peephole camera states
  public hidingTarget: HidingCameraTarget | null = null;
  public peepholeTarget: PeepholeCameraTarget | null = null;
  private savedYawBeforeSpecial = 0;
  private savedPitchBeforeSpecial = 0;
  private currentCamPos = new THREE.Vector3();
  private currentFov = 68;
  private staminaDrainScale = 1.0;
  private batteryDrainScale = 1.0;
  private fearLevel = 0;

  public flashlight: THREE.SpotLight;
  public flashlightTarget: THREE.Object3D;
  private flashlightFlicker = 1;
  private smoothedYaw = Math.PI * 0.85;
  private smoothedPitch = -0.02;

  private keys = new Set<string>();

  constructor(
    private camera: THREE.PerspectiveCamera,
    scene: THREE.Scene,
    private collision: CollisionWorld,
    private sound: SoundEngine,
    isSoftwareGl: boolean,
  ) {
    this.camera.rotation.order = 'YXZ';

    this.flashlight = new THREE.SpotLight(
      0xfff0d6,
      5.4,
      21,
      Math.PI / 4.7,
      0.65,
      1.6,
    );
    this.flashlight.castShadow = !isSoftwareGl;
    this.flashlight.shadow.mapSize.set(512, 512);
    this.flashlight.shadow.camera.near = 0.25;
    this.flashlight.shadow.camera.far = 18;
    this.flashlight.shadow.bias = -0.0005;

    this.flashlightTarget = new THREE.Object3D();
    scene.add(this.flashlight);
    scene.add(this.flashlightTarget);
    this.flashlight.target = this.flashlightTarget;

    this.reset();
  }

  public reset(): void {
    this.position.set(-0.6, 0.0, -0.5);
    this.yaw = Math.PI * 0.85;
    this.pitch = -0.02;
    this.smoothedYaw = this.yaw;
    this.smoothedPitch = this.pitch;
    this.velocityY = 0;
    this.crouching = false;
    this.sprinting = false;
    this.flashlightOn = true;
    this.health = 100;
    this.stamina = 100;
    this.exhausted = false;
    this.battery = 100;
    this.noiseLevel = 0;
    this.noiseImpulse = 0;
    this.damageFlash = 0;
    this.exhaustedTimer = 0;
    this.adrenalineTimer = 0;
    this.invulnTimer = 0;
    this.hidingTarget = null;
    this.peepholeTarget = null;
    this.currentEyeHeight = BUILDING.EYE_STANDING;
    this.bobPhase = 0;
    this.lastStepHalfCycle = 0;
    this.currentCamPos.set(
      this.position.x,
      this.position.y + this.currentEyeHeight,
      this.position.z,
    );
    this.syncCamera(0, 0, 1);
  }

  public setKey(code: string, down: boolean): void {
    if (down) this.keys.add(code);
    else this.keys.delete(code);
  }

  public toggleCrouch(): boolean {
    if (this.hidingTarget || this.peepholeTarget) return this.crouching;
    this.crouching = !this.crouching;
    if (this.crouching) this.sprinting = false;
    return this.crouching;
  }

  public toggleFlashlight(): boolean {
    if (this.battery <= 0.5 && !this.flashlightOn) {
      this.sound.playFlashlightToggle(false);
      return false;
    }
    this.flashlightOn = !this.flashlightOn;
    this.sound.playFlashlightToggle(this.flashlightOn);
    return this.flashlightOn;
  }

  public addBattery(amount: number): void {
    this.battery = Math.min(100, this.battery + amount);
  }

  public heal(amount: number): void {
    this.health = Math.min(100, this.health + amount);
  }

  public takeDamage(amount: number): number {
    this.health = Math.max(0, this.health - amount);
    this.damageFlash = 1.0;
    this.addNoiseImpulse(65);
    this.adrenalineTimer = 2.2;
    this.invulnTimer = 1.65;
    this.exhausted = false;
    this.exhaustedTimer = 0;
    this.stamina = Math.min(100, this.stamina + 24);
    return this.health;
  }

  public isInvulnerable(): boolean {
    return this.invulnTimer > 0;
  }

  public getDamageFlash(): number {
    return this.damageFlash;
  }

  public addNoiseImpulse(amount: number): void {
    this.noiseImpulse = Math.max(this.noiseImpulse, Math.min(100, amount));
  }

  public setFlashlightFlicker(intensityScale: number): void {
    this.flashlightFlicker = intensityScale;
  }

  public setDifficultyScales(staminaScale: number, batteryScale: number): void {
    this.staminaDrainScale = staminaScale;
    this.batteryDrainScale = batteryScale;
  }

  public setFearLevel(fear: number): void {
    this.fearLevel = THREE.MathUtils.clamp(fear, 0, 1);
  }

  public enterHiding(target: HidingCameraTarget): void {
    this.hidingTarget = target;
    this.savedYawBeforeSpecial = this.yaw;
    this.savedPitchBeforeSpecial = this.pitch;
    this.yaw = target.lookYaw;
    this.pitch = target.lookPitch;
    this.sprinting = false;
    this.sound.playDoorCreak();
  }

  public exitHiding(): void {
    if (!this.hidingTarget) return;
    this.position.copy(this.hidingTarget.returnPos);
    this.yaw = this.savedYawBeforeSpecial;
    this.pitch = this.savedPitchBeforeSpecial;
    this.hidingTarget = null;
    this.sound.playDoorCreak();
  }

  public enterPeephole(target: PeepholeCameraTarget): void {
    this.peepholeTarget = target;
    this.savedYawBeforeSpecial = this.yaw;
    this.savedPitchBeforeSpecial = this.pitch;
    this.yaw = target.lookYaw;
    this.pitch = target.lookPitch;
    this.sprinting = false;
    this.sound.playFlashlightToggle(true);
  }

  public exitPeephole(): void {
    if (!this.peepholeTarget) return;
    this.yaw = this.savedYawBeforeSpecial;
    this.pitch = this.savedPitchBeforeSpecial;
    this.peepholeTarget = null;
    this.sound.playFlashlightToggle(false);
  }

  public applyLookDelta(dx: number, dy: number, settings: GameSettings): void {
    const sens = 0.0032 * settings.sensitivity;
    const invertSign = settings.invertY ? -1 : 1;
    this.yaw -= dx * sens;
    this.pitch -= dy * sens * invertSign;

    if (this.hidingTarget) {
      const diff = this.normalizeAngle(this.yaw - this.hidingTarget.lookYaw);
      this.yaw =
        this.hidingTarget.lookYaw + THREE.MathUtils.clamp(diff, -0.58, 0.58);
      this.pitch = THREE.MathUtils.clamp(this.pitch, -0.45, 0.45);
    } else if (this.peepholeTarget) {
      const diff = this.normalizeAngle(this.yaw - this.peepholeTarget.lookYaw);
      this.yaw =
        this.peepholeTarget.lookYaw + THREE.MathUtils.clamp(diff, -0.35, 0.35);
      this.pitch = THREE.MathUtils.clamp(this.pitch, -0.3, 0.3);
    } else {
      this.pitch = THREE.MathUtils.clamp(this.pitch, -1.35, 1.35);
    }
  }

  private normalizeAngle(a: number): number {
    while (a > Math.PI) a -= Math.PI * 2;
    while (a < -Math.PI) a += Math.PI * 2;
    return a;
  }

  public update(
    delta: number,
    input: InputState,
    settings: GameSettings,
    elevatorLockDeltaY = 0,
  ): void {
    const dt = Math.min(delta, 0.05);

    this.damageFlash = Math.max(0, this.damageFlash - dt * 1.4);
    this.noiseImpulse = Math.max(0, this.noiseImpulse - dt * 55);
    if (this.adrenalineTimer > 0) this.adrenalineTimer = Math.max(0, this.adrenalineTimer - dt);
    if (this.invulnTimer > 0) this.invulnTimer = Math.max(0, this.invulnTimer - dt);
    if (this.exhaustedTimer > 0) {
      this.exhaustedTimer = Math.max(0, this.exhaustedTimer - dt);
    }

    // Drain battery slowly while flashlight is active (~3.8 min continuous run)
    if (this.flashlightOn) {
      this.battery = Math.max(0, this.battery - dt * 0.45 * this.batteryDrainScale);
      if (this.battery <= 0) {
        this.flashlightOn = false;
        this.sound.playFlashlightToggle(false);
      }
    }

    if (input.lookDeltaX !== 0 || input.lookDeltaY !== 0) {
      this.applyLookDelta(input.lookDeltaX, input.lookDeltaY, settings);
      input.lookDeltaX = 0;
      input.lookDeltaY = 0;
    }

    this.smoothedYaw = THREE.MathUtils.damp(this.smoothedYaw, this.yaw, 24, dt);
    this.smoothedPitch = THREE.MathUtils.damp(this.smoothedPitch, this.pitch, 24, dt);

    // Special modes: Hiding or Door Peephole (no free movement)
    if (this.hidingTarget) {
      this.noiseLevel = THREE.MathUtils.damp(
        this.noiseLevel,
        Math.max(4, this.noiseImpulse),
        8,
        dt,
      );
      this.stamina = Math.min(100, this.stamina + dt * 14);
      this.currentCamPos.x = THREE.MathUtils.damp(
        this.currentCamPos.x,
        this.hidingTarget.camPos.x,
        10,
        dt,
      );
      this.currentCamPos.y = THREE.MathUtils.damp(
        this.currentCamPos.y,
        this.hidingTarget.camPos.y,
        10,
        dt,
      );
      this.currentCamPos.z = THREE.MathUtils.damp(
        this.currentCamPos.z,
        this.hidingTarget.camPos.z,
        10,
        dt,
      );
      this.syncCamera(0, 0, dt);
      return;
    }

    if (this.peepholeTarget) {
      this.noiseLevel = THREE.MathUtils.damp(
        this.noiseLevel,
        Math.max(2, this.noiseImpulse),
        8,
        dt,
      );
      this.currentCamPos.x = THREE.MathUtils.damp(
        this.currentCamPos.x,
        this.peepholeTarget.camPos.x,
        14,
        dt,
      );
      this.currentCamPos.y = THREE.MathUtils.damp(
        this.currentCamPos.y,
        this.peepholeTarget.camPos.y,
        14,
        dt,
      );
      this.currentCamPos.z = THREE.MathUtils.damp(
        this.currentCamPos.z,
        this.peepholeTarget.camPos.z,
        14,
        dt,
      );
      this.syncCamera(0, 0, dt);
      return;
    }

    let moveX = input.moveX;
    let moveY = input.moveY;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) moveY += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) moveY -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) moveX += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) moveX -= 1;

    const mag = Math.hypot(moveX, moveY);
    if (mag > 1) {
      moveX /= mag;
      moveY /= mag;
    }

    const wantsSprint =
      input.sprint ||
      this.keys.has('ShiftLeft') ||
      this.keys.has('ShiftRight');

    if (
      wantsSprint &&
      !this.crouching &&
      !this.exhausted &&
      mag > 0.25 &&
      this.stamina > 2
    ) {
      this.sprinting = true;
      this.stamina = Math.max(0, this.stamina - dt * 20 * this.staminaDrainScale);
      if (this.stamina <= 0.4) {
        this.stamina = 0;
        this.sprinting = false;
        this.exhausted = true;
        this.exhaustedTimer = 2.6;
        input.sprint = false;
      }
    } else {
      this.sprinting = false;
      const regenRate = mag > 0.1 ? 10 : 17;
      this.stamina = Math.min(100, this.stamina + dt * regenRate);
      if (this.exhausted && this.exhaustedTimer <= 0 && this.stamina >= 25) {
        this.exhausted = false;
      }
    }

    _forward.set(-Math.sin(this.smoothedYaw), 0, -Math.cos(this.smoothedYaw));
    _right.crossVectors(_forward, _up).normalize();

    _moveDir.set(0, 0, 0);
    _moveDir.addScaledVector(_forward, moveY);
    _moveDir.addScaledVector(_right, moveX);

    const baseSpeed = this.crouching
      ? BUILDING.CROUCH_SPEED
      : this.sprinting
        ? this.adrenalineTimer > 0
          ? BUILDING.ADRENALINE_SPEED
          : BUILDING.SPRINT_SPEED
        : this.exhausted
          ? BUILDING.EXHAUSTED_SPEED
          : this.adrenalineTimer > 0
            ? BUILDING.WALK_SPEED * 1.18
            : BUILDING.WALK_SPEED;
    const moveSpeed = mag > 0.04 ? baseSpeed * Math.min(1, mag) : 0;

    let nextX = this.position.x + _moveDir.x * moveSpeed * dt;
    let nextZ = this.position.z + _moveDir.z * moveSpeed * dt;

    const targetEye = this.crouching
      ? BUILDING.EYE_CROUCHING
      : BUILDING.EYE_STANDING;
    this.currentEyeHeight = THREE.MathUtils.damp(
      this.currentEyeHeight,
      targetEye,
      10,
      dt,
    );

    const resolved = this.collision.resolveHorizontal(
      nextX,
      nextZ,
      this.position.y,
      this.currentEyeHeight + 0.14,
      BUILDING.PLAYER_RADIUS,
    );
    nextX = resolved.x;
    nextZ = resolved.z;

    const movedDist = Math.hypot(
      nextX - this.position.x,
      nextZ - this.position.z,
    );
    this.position.x = nextX;
    this.position.z = nextZ;

    if (elevatorLockDeltaY !== 0) {
      this.position.y += elevatorLockDeltaY;
      this.velocityY = 0;
    }

    const floorSample = this.collision.sampleFloor(
      this.position.x,
      this.position.z,
      this.position.y,
    );

    if (floorSample) {
      this.surfaceKind = floorSample.surfaceKind;
      const diff = floorSample.y - this.position.y;
      if (diff >= -0.28) {
        this.position.y = THREE.MathUtils.damp(
          this.position.y,
          floorSample.y,
          18,
          dt,
        );
        this.velocityY = 0;
      } else {
        this.velocityY -= 16 * dt;
        this.position.y += this.velocityY * dt;
        if (this.position.y <= floorSample.y) {
          this.position.y = floorSample.y;
          this.velocityY = 0;
        }
      }
    } else {
      this.velocityY -= 16 * dt;
      this.position.y += this.velocityY * dt;
      if (this.position.y < -3.2) {
        this.position.y = -3.2;
        this.velocityY = 0;
      }
    }

    // Calculate live noise level
    let targetNoise = 0;
    if (movedDist > 0.002) {
      if (this.crouching) targetNoise = 14;
      else if (this.sprinting) targetNoise = 85;
      else targetNoise = 42 * Math.min(1, mag);
    }
    targetNoise = Math.max(targetNoise, this.noiseImpulse);
    this.noiseLevel = THREE.MathUtils.damp(this.noiseLevel, targetNoise, 8, dt);

    let bobOffsetY = 0;
    let bobOffsetX = 0;
    if (movedDist > 0.001 && Math.abs(this.velocityY) < 0.5) {
      const freq = this.crouching ? 4.2 : this.sprinting ? 7.6 : 6.0;
      this.bobPhase += movedDist * freq;
      const amp = this.crouching ? 0.02 : this.sprinting ? 0.062 : 0.04;
      bobOffsetY = Math.sin(this.bobPhase) * amp;
      bobOffsetX = Math.cos(this.bobPhase * 0.5) * amp * 0.45;

      const halfCycle = Math.floor((this.bobPhase + Math.PI * 0.5) / Math.PI);
      if (halfCycle !== this.lastStepHalfCycle) {
        this.lastStepHalfCycle = halfCycle;
        if (halfCycle % 2 === 0) {
          this.sound.playFootstep(
            this.crouching,
            this.surfaceKind,
            this.sprinting,
          );
        }
      }
    } else {
      this.bobPhase = 0;
    }

    _right.set(Math.cos(this.smoothedYaw), 0, -Math.sin(this.smoothedYaw));
    const goalX = this.position.x + _right.x * bobOffsetX;
    const goalY = this.position.y + this.currentEyeHeight + bobOffsetY;
    const goalZ = this.position.z + _right.z * bobOffsetX;

    this.currentCamPos.x = THREE.MathUtils.damp(this.currentCamPos.x, goalX, 26, dt);
    this.currentCamPos.y = THREE.MathUtils.damp(this.currentCamPos.y, goalY, 26, dt);
    this.currentCamPos.z = THREE.MathUtils.damp(this.currentCamPos.z, goalZ, 26, dt);

    this.syncCamera(bobOffsetX, bobOffsetY, dt);
  }

  private syncCamera(_bobX: number, _bobY: number, dt: number): void {
    const targetFov = this.peepholeTarget
      ? 94
      : this.sprinting
        ? 74
        : 68 + this.fearLevel * 2.5;
    if (Math.abs(this.currentFov - targetFov) > 0.1) {
      this.currentFov = THREE.MathUtils.damp(this.currentFov, targetFov, 10, dt || 0.016);
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    const fearRoll =
      this.fearLevel > 0.35 && !this.peepholeTarget
        ? Math.sin(performance.now() * 0.0055) * 0.014 * (this.fearLevel - 0.35)
        : 0;
    this.camera.position.copy(this.currentCamPos);
    this.camera.rotation.set(this.smoothedPitch, this.smoothedYaw, fearRoll, 'YXZ');

    _right.set(Math.cos(this.smoothedYaw), 0, -Math.sin(this.smoothedYaw));
    const lowBatteryScale =
      this.battery < 15 ? 0.55 + Math.sin(performance.now() * 0.025) * 0.35 : 1;
    this.flashlight.visible = this.flashlightOn && !this.peepholeTarget;

    if (this.flashlight.visible) {
      this.flashlight.intensity = 5.4 * this.flashlightFlicker * lowBatteryScale;
      this.flashlight.position
        .copy(this.camera.position)
        .addScaledVector(_right, 0.16);
      this.flashlight.position.y -= 0.14;

      _lookDir.set(0, 0, -1).applyEuler(this.camera.rotation);
      this.flashlightTarget.position
        .copy(this.camera.position)
        .addScaledVector(_lookDir, 6.0);
    }
  }
}
