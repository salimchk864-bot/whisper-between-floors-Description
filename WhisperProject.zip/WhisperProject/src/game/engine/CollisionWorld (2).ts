export interface BoxCollider {
  id?: string;
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  minZ: number;
  maxZ: number;
  enabled: boolean;
}

export type SurfaceKind = 'concrete' | 'metal' | 'wood';

export interface WalkSurface {
  id?: string;
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  onMetal?: boolean;
  surfaceKind?: SurfaceKind;
  getY: (x: number, z: number) => number;
}

export class CollisionWorld {
  private colliders: BoxCollider[] = [];
  private surfaces: WalkSurface[] = [];

  public addCollider(collider: Omit<BoxCollider, 'enabled'> & { enabled?: boolean }): BoxCollider {
    const entry: BoxCollider = {
      ...collider,
      enabled: collider.enabled ?? true,
    };
    this.colliders.push(entry);
    return entry;
  }

  public addWalkSurface(surface: WalkSurface): WalkSurface {
    this.surfaces.push(surface);
    return surface;
  }

  public sampleFloor(
    x: number,
    z: number,
    currentFootY: number,
  ): { y: number; onMetal: boolean; surfaceKind: SurfaceKind } | null {
    let bestY = -Infinity;
    let bestMetal = false;
    let bestKind: SurfaceKind = 'concrete';
    const maxStepUp = 0.55;
    const margin = 0.04;

    for (let i = 0; i < this.surfaces.length; i++) {
      const s = this.surfaces[i];
      if (
        x >= s.minX - margin &&
        x <= s.maxX + margin &&
        z >= s.minZ - margin &&
        z <= s.maxZ + margin
      ) {
        const surfaceY = s.getY(x, z);
        if (surfaceY <= currentFootY + maxStepUp && surfaceY > bestY) {
          bestY = surfaceY;
          bestMetal = Boolean(s.onMetal);
          bestKind = s.surfaceKind ?? (s.onMetal ? 'metal' : 'concrete');
        }
      }
    }

    if (bestY === -Infinity) return null;
    return { y: bestY, onMetal: bestMetal, surfaceKind: bestKind };
  }

  public resolveHorizontal(
    x: number,
    z: number,
    footY: number,
    playerHeight: number,
    radius: number,
  ): { x: number; z: number } {
    let px = x;
    let pz = z;
    const bodyBottom = footY + 0.25;
    const bodyTop = footY + playerHeight;

    // Two resolution passes prevent corner snagging
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 0; i < this.colliders.length; i++) {
        const c = this.colliders[i];
        if (!c.enabled) continue;
        if (c.maxY <= bodyBottom || c.minY >= bodyTop) continue;

        const closestX = Math.max(c.minX, Math.min(px, c.maxX));
        const closestZ = Math.max(c.minZ, Math.min(pz, c.maxZ));

        const dx = px - closestX;
        const dz = pz - closestZ;
        const distSq = dx * dx + dz * dz;

        if (distSq < radius * radius) {
          const dist = Math.sqrt(distSq);
          if (dist > 0.0001) {
            const overlap = radius - dist;
            px += (dx / dist) * overlap;
            pz += (dz / dist) * overlap;
          } else {
            // Center inside AABB: push out along shallowest axis
            const leftPen = Math.abs(px - c.minX);
            const rightPen = Math.abs(c.maxX - px);
            const frontPen = Math.abs(pz - c.minZ);
            const backPen = Math.abs(c.maxZ - pz);
            const minPen = Math.min(leftPen, rightPen, frontPen, backPen);

            if (minPen === leftPen) px = c.minX - radius;
            else if (minPen === rightPen) px = c.maxX + radius;
            else if (minPen === frontPen) pz = c.minZ - radius;
            else pz = c.maxZ + radius;
          }
        }
      }
    }

    return { x: px, z: pz };
  }

  public clear(): void {
    this.colliders = [];
    this.surfaces = [];
  }
}
