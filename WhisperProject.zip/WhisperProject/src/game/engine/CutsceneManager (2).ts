import * as THREE from 'three';
import { CutsceneInfo } from '../types';
import { SoundEngine } from '../audio/SoundEngine';

export interface CutsceneDefinition {
  id: string;
  title: string;
  caption: string;
  duration: number;
  startPos: THREE.Vector3;
  endPos: THREE.Vector3;
  lookAt: THREE.Vector3;
  onStart?: () => void;
  onComplete?: () => void;
}

const _camPos = new THREE.Vector3();

export class CutsceneManager {
  public active: CutsceneDefinition | null = null;
  private elapsed = 0;
  private triggeredIds = new Set<string>();

  constructor(private sound: SoundEngine) {}

  public setTriggeredIds(ids: string[]): void {
    this.triggeredIds = new Set(ids);
  }

  public getTriggeredIds(): string[] {
    return Array.from(this.triggeredIds);
  }

  public hasTriggered(id: string): boolean {
    return this.triggeredIds.has(id);
  }

  public play(def: CutsceneDefinition, allowReplay = false): boolean {
    if (!allowReplay && this.triggeredIds.has(def.id)) return false;
    this.triggeredIds.add(def.id);
    this.active = def;
    this.elapsed = 0;
    def.onStart?.();
    return true;
  }

  public skip(): void {
    if (!this.active) return;
    const done = this.active;
    this.active = null;
    done.onComplete?.();
  }

  public getInfo(): CutsceneInfo | null {
    if (!this.active) return null;
    return {
      id: this.active.id,
      title: this.active.title,
      caption: this.active.caption,
    };
  }

  public update(delta: number, camera: THREE.PerspectiveCamera): boolean {
    if (!this.active) return false;
    this.elapsed += delta;
    const t = Math.min(1, this.elapsed / this.active.duration);
    const smoothT = t * t * (3 - 2 * t);

    _camPos.lerpVectors(this.active.startPos, this.active.endPos, smoothT);
    camera.position.copy(_camPos);
    camera.lookAt(this.active.lookAt);

    if (t >= 1) {
      const done = this.active;
      this.active = null;
      done.onComplete?.();
      return false;
    }
    return true;
  }

  public reset(): void {
    this.active = null;
    this.elapsed = 0;
    this.triggeredIds.clear();
  }
}
