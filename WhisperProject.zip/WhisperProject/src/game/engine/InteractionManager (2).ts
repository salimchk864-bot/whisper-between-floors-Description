import * as THREE from 'three';
import { InteractCategory, InteractPrompt } from '../types';

export const INTERACTION_LAYER = 1;

export interface InteractableConfig {
  id: string;
  mesh: THREE.Object3D;
  title: string;
  actionText: string;
  secondaryActionText?: string;
  category: InteractCategory;
  maxDistance?: number;
  enabled?: boolean;
  onInteract: () => void;
  onSecondaryInteract?: () => void;
}

const _centerNdc = new THREE.Vector2(0, 0);

export class InteractionManager {
  private raycaster = new THREE.Raycaster();
  private entries = new Map<string, InteractableConfig>();
  private targets: THREE.Object3D[] = [];
  private activeEntry: InteractableConfig | null = null;
  private accumTime = 0;

  constructor() {
    this.raycaster.layers.set(INTERACTION_LAYER);
    this.raycaster.far = 2.65;
  }

  public register(config: InteractableConfig): InteractableConfig {
    config.mesh.layers.enable(INTERACTION_LAYER);
    config.mesh.traverse((child) => {
      child.layers.enable(INTERACTION_LAYER);
      child.userData.interactId = config.id;
    });
    const normalized: InteractableConfig = {
      ...config,
      enabled: config.enabled ?? true,
      maxDistance: config.maxDistance ?? 2.35,
    };
    this.entries.set(config.id, normalized);
    this.targets.push(config.mesh);
    return normalized;
  }

  public updateEntry(
    id: string,
    patch: Partial<
      Pick<
        InteractableConfig,
        'title' | 'actionText' | 'secondaryActionText' | 'enabled'
      >
    >,
  ): void {
    const entry = this.entries.get(id);
    if (!entry) return;
    if (patch.title !== undefined) entry.title = patch.title;
    if (patch.actionText !== undefined) entry.actionText = patch.actionText;
    if (patch.secondaryActionText !== undefined) {
      entry.secondaryActionText = patch.secondaryActionText;
    }
    if (patch.enabled !== undefined) entry.enabled = patch.enabled;
  }

  public update(camera: THREE.Camera, delta: number): InteractPrompt | null {
    this.accumTime += delta;
    if (this.accumTime < 0.05) {
      return this.toPrompt(this.activeEntry);
    }
    this.accumTime = 0;

    this.raycaster.setFromCamera(_centerNdc, camera);
    const hits = this.raycaster.intersectObjects(this.targets, true);

    let found: InteractableConfig | null = null;
    for (let i = 0; i < hits.length; i++) {
      const hit = hits[i];
      const interactId = hit.object.userData.interactId as string | undefined;
      if (!interactId) continue;
      const entry = this.entries.get(interactId);
      if (!entry || !entry.enabled) continue;
      if (hit.distance <= (entry.maxDistance ?? 2.35)) {
        found = entry;
        break;
      }
    }

    this.activeEntry = found;
    return this.toPrompt(found);
  }

  public triggerActive(): boolean {
    if (!this.activeEntry || !this.activeEntry.enabled) return false;
    this.activeEntry.onInteract();
    return true;
  }

  public triggerSecondaryActive(): boolean {
    if (
      !this.activeEntry ||
      !this.activeEntry.enabled ||
      !this.activeEntry.onSecondaryInteract
    ) {
      return false;
    }
    this.activeEntry.onSecondaryInteract();
    return true;
  }

  private toPrompt(entry: InteractableConfig | null): InteractPrompt | null {
    if (!entry) return null;
    return {
      id: entry.id,
      title: entry.title,
      actionText: entry.actionText,
      secondaryActionText: entry.secondaryActionText,
      category: entry.category,
    };
  }

  public clear(): void {
    this.entries.clear();
    this.targets = [];
    this.activeEntry = null;
  }
}
