import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  AchievementDef,
  AchievementId,
  CreatureId,
  EndingId,
  EndingInfo,
  GameSettings,
  GameState,
  HUDState,
  InputState,
  NightSeedData,
  PhoneMessage,
  ReadableNote,
} from '../types';
import {
  DIFFICULTY_PROFILES,
  getFloorBaseY,
  getFloorFromY,
  getLocationLabel,
} from '../world/BuildingConfig';
import { CollisionWorld } from './CollisionWorld';
import { InteractionManager } from './InteractionManager';
import {
  HidingCameraTarget,
  PeepholeCameraTarget,
  PlayerController,
} from './PlayerController';
import { CutsceneManager } from './CutsceneManager';
import { SoundEngine } from '../audio/SoundEngine';
import { InventorySystem, MAX_INVENTORY_SLOTS } from '../inventory/InventorySystem';
import { SaveManager } from '../save/SaveManager';
import { MaterialLibrary } from '../world/MaterialLibrary';
import {
  BuildingBuilder,
  BuildingBuildResult,
} from '../world/BuildingBuilder';
import { ElevatorSystem } from '../world/ElevatorSystem';
import { MonsterAI } from '../world/MonsterAI';
import { WhisperDirector } from '../world/WhisperDirector';
import { WeatherSystem } from '../world/WeatherSystem';
import { SecurityCameraSystem } from '../world/SecurityCameraSystem';
import { AchievementManager } from '../achievements/AchievementManager';
import { CreatureGalleryManager } from '../story/CreatureGalleryData';
import { createRandomNightSeed } from '../world/NightConfig';

const ENDINGS: Record<EndingId, EndingInfo> = {
  good: {
    id: 'good',
    title: 'Рассвет за дверью',
    subtitle: 'Хорошая концовка',
    description:
      'Вы восстановили питание генератора и вырвались из подъезда живым. Но где-то за спиной, на пролёте между вторым и третьим, шёпот всё ещё ждёт следующего жильца.',
  },
  bad: {
    id: 'bad',
    title: 'Новый голос на пролёте',
    subtitle: 'Плохая концовка',
    description:
      'Тьма между этажами поглотила вас прежде, чем удалось добраться до выхода. Утром дверь подъезда снова окажется запертой изнутри.',
  },
  secret: {
    id: 'secret',
    title: 'Свидетель №0',
    subtitle: 'Секретная концовка',
    description:
      'Вы нашли потайную комнату наблюдателя и замкнули контур кассетой №4. Выход открылся, но теперь в записи на плёнке звучит и ваш собственный голос.',
  },
  true: {
    id: 'true',
    title: 'Тишина в эфире',
    subtitle: 'Истинная концовка',
    description:
      'Запустив генератор и заглушив антенный передатчик на чердаке кассетой №4, вы навсегда оборвали сигнал «Холодной тишины». Подъезд наконец затих.',
  },
};

function detectSoftwareWebGL(): boolean {
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl2');
  if (!gl) return true;
  const ext = gl.getExtension('WEBGL_debug_renderer_info');
  const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
  const gpu = String(gl.getParameter(param));
  gl.getExtension('WEBGL_lose_context')?.loseContext();
  return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
}

interface PendingKeypadState {
  id: string;
  title: string;
  hint: string;
  expectedCode: string;
  onUnlocked: () => void;
}

export class HorrorEngine {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private isSoftwareGl: boolean;

  private collision = new CollisionWorld();
  private interaction = new InteractionManager();
  private sound = new SoundEngine();
  private inventory = new InventorySystem();
  private achievements = new AchievementManager();
  private creatures = new CreatureGalleryManager();
  private cctv = new SecurityCameraSystem();
  private cutscenes: CutsceneManager;
  private materials: MaterialLibrary;
  private player: PlayerController;
  private elevator: ElevatorSystem;
  private monster: MonsterAI;
  private director: WhisperDirector;
  private weather: WeatherSystem;
  private building: BuildingBuildResult;
  private nightSeed: NightSeedData;

  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;

  private gameState: GameState = GameState.MENU;
  private settings: GameSettings = {
    sensitivity: 1.0,
    volume: 0.8,
    quality: 'medium',
    invertY: false,
    difficulty: 'normal',
    touchScale: 'standard',
    controlsSwapHands: false,
  };

  private input: InputState = {
    moveX: 0,
    moveY: 0,
    lookDeltaX: 0,
    lookDeltaY: 0,
    sprint: false,
  };

  private activeNote: ReadableNote | null = null;
  private activeEnding: EndingInfo | null = null;
  private activeKeypad: PendingKeypadState | null = null;
  private notesFound = new Set<string>();
  private subtitle: string | null = null;
  private subtitleTimer = 0;
  private phoneMessage: PhoneMessage | null = null;
  private phoneMessageTimer = 0;
  private phoneHistory: PhoneMessage[] = [];
  private phoneUnreadCount = 0;
  private achievementToast: AchievementDef | null = null;
  private achievementToastTimer = 0;
  private activeCameraIndex = 0;
  private quietTimeAccum = 0;
  private fearLevel = 0;
  private breathingTimer = 0;

  private hudEmitAccum = 0;
  private autoSaveAccum = 0;
  private heartbeatTimer = 0;
  private lastFootNoiseEmit = 0;
  private isTouchDevice: boolean;

  private onHudUpdate: (hud: HUDState) => void;
  private onContextLost?: () => void;
  private onContextRestored?: () => void;

  private resizeObserver: ResizeObserver;
  private envRT: THREE.WebGLRenderTarget | null = null;

  constructor(
    container: HTMLElement,
    onHudUpdate: (hud: HUDState) => void,
    handlers?: {
      onContextLost?: () => void;
      onContextRestored?: () => void;
      initialNightSeed?: NightSeedData;
    },
  ) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.onContextLost = handlers?.onContextLost;
    this.onContextRestored = handlers?.onContextRestored;
    this.isTouchDevice =
      typeof window !== 'undefined' &&
      ('ontouchstart' in window || navigator.maxTouchPoints > 0);

    this.nightSeed =
      handlers?.initialNightSeed ?? createRandomNightSeed(undefined, false);

    this.isSoftwareGl = detectSoftwareWebGL();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height);
    container.appendChild(this.renderer.domElement);

    this.renderer.domElement.addEventListener(
      'webglcontextlost',
      this.handleContextLost,
    );
    this.renderer.domElement.addEventListener(
      'webglcontextrestored',
      this.handleContextRestored,
    );

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x06080b);
    this.scene.fog = new THREE.FogExp2(0x06080b, 0.082);

    this.camera = new THREE.PerspectiveCamera(68, width / height, 0.08, 38);
    this.applyQualityPreset();

    const pmrem = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.envRT = pmrem.fromScene(roomEnv, 0.04);
    this.scene.environment = this.envRT.texture;
    this.scene.environmentIntensity = 0.18;
    roomEnv.dispose();
    pmrem.dispose();

    const hemi = new THREE.HemisphereLight(0x3a4d66, 0x161816, 0.34);
    this.scene.add(hemi);

    const maxAniso = this.renderer.capabilities.getMaxAnisotropy();
    this.materials = new MaterialLibrary(maxAniso, this.isSoftwareGl);
    this.cutscenes = new CutsceneManager(this.sound);
    this.weather = new WeatherSystem(this.scene, this.sound);
    this.weather.setWeather(this.nightSeed.weather);

    this.player = new PlayerController(
      this.camera,
      this.scene,
      this.collision,
      this.sound,
      this.isSoftwareGl,
    );

    this.elevator = new ElevatorSystem(
      this.scene,
      this.materials,
      this.collision,
      this.interaction,
      this.sound,
      {
        onSubtitle: (msg) => this.showSubtitle(msg),
        onStallCutscene: () => {
          this.discoverCreature('whisper_phenomenon');
          this.playElevatorStallCutscene();
        },
      },
    );

    this.monster = new MonsterAI(
      this.scene,
      this.materials,
      this.collision,
      this.sound,
      {
        onPlayerHit: (dmg, pulledFromHide) =>
          this.handleMonsterHit(dmg, pulledFromHide),
        onFirstSighting: () => {
          this.discoverCreature('stalker');
          this.playFirstSightingCutscene();
        },
        onSpottedPlayer: () => this.discoverCreature('stalker'),
        onEscapedChase: () => this.unlockAchievement('first_escape'),
        onSubtitle: (msg) => this.showSubtitle(msg),
      },
    );

    const builder = new BuildingBuilder(
      this.scene,
      this.materials,
      this.collision,
      this.interaction,
      this.sound,
      this.inventory,
      {
        nightSeed: this.nightSeed,
        cameraMountSpecs: this.cctv.getMountSpecs(),
        onOpenNote: (note) => this.openNote(note),
        onSubtitle: (msg) => this.showSubtitle(msg),
        onEnterHide: (target) => this.enterHiding(target),
        onEnterPeephole: (target) => this.enterPeephole(target),
        onOpenCCTV: () => this.openCCTV(),
        onOpenKeypad: (opts) => this.openKeypad(opts),
        onGeneratorStarted: () => this.playPowerRestoredCutscene(),
        onSecretRoomDiscovered: () => {
          this.discoverCreature('signal_zero');
          this.unlockAchievement('explorer');
          this.playSecretRoomCutscene();
        },
        onSecretFound: () => {
          this.discoverCreature('signal_zero');
          this.unlockAchievement('explorer');
        },
        onRadioTriggered: () => this.discoverCreature('whisper_phenomenon'),
        onStoryRevelation: () => {
          this.discoverCreature('signal_zero');
          this.playStoryRevelationCutscene();
        },
        onTriggerEnding: (ending) => this.playEndingCutscene(ending),
        onNoiseImpulse: (pos, rad) => {
          this.player.addNoiseImpulse(75);
          this.monster.notifyNoise(pos, rad);
        },
        onStateChanged: () => {
          this.saveProgress();
          this.emitHud(true);
        },
        onRegisterDoorBridge: (bridge) =>
          this.monster.registerDoorBridge(bridge),
        onLinkNavEdge: (corridorId, roomId, roomPos, floor, doorId) =>
          this.monster.linkApartmentDoorEdge(
            corridorId,
            roomId,
            roomPos,
            floor,
            doorId,
          ),
      },
    );
    this.building = builder.build();
    this.monster.configureNight(
      this.nightSeed.monsterStartFloor,
      this.nightSeed.patrolBias,
    );

    this.director = new WhisperDirector(
      this.scene,
      this.sound,
      this.elevator,
      {
        onSubtitle: (msg) => this.showSubtitle(msg),
        onFlickerPower: (floor) => this.building.flickerFloorLight(floor),
        onCreakNearestDoor: (floor) => this.building.creakNearestDoor(floor),
        onPhoneMessage: (msg) => this.pushPhoneMessage(msg),
        onPhantomSeen: () => this.discoverCreature('shadow_phantom'),
        onWhisperHeard: () => this.discoverCreature('whisper_phenomenon'),
      },
    );

    this.applyDifficultyToSystems();

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(this.container);

    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);

    this.emitHud(true);
    this.clock.start();
    this.tick();
  }

  private discoverCreature(id: CreatureId): void {
    if (this.creatures.discover(id)) {
      this.emitHud(true);
    }
  }

  private unlockAchievement(id: AchievementId): void {
    const def = this.achievements.unlock(id);
    if (def) {
      this.achievementToast = def;
      this.achievementToastTimer = 4.6;
      this.sound.playAchievementChime();
      this.emitHud(true);
    }
  }

  private pushPhoneMessage(msg: PhoneMessage): void {
    this.phoneMessage = msg;
    this.phoneMessageTimer = 5.4;
    this.phoneUnreadCount += 1;
    this.phoneHistory = [msg, ...this.phoneHistory].slice(0, 18);
    this.emitHud(true);
  }

  private applyDifficultyToSystems(): void {
    const prof = DIFFICULTY_PROFILES[this.settings.difficulty];
    this.player.setDifficultyScales(
      prof.staminaDrainScale,
      prof.batteryDrainScale,
    );
    this.monster.setDifficulty(
      this.settings.difficulty,
      this.nightSeed.isNewGamePlus,
    );
    this.director.setDifficulty(
      this.settings.difficulty,
      this.nightSeed.isNewGamePlus,
    );
  }

  private handleContextLost = (e: Event): void => {
    e.preventDefault();
    this.onContextLost?.();
  };

  private handleContextRestored = (): void => {
    this.onContextRestored?.();
  };

  private handleResize(): void {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.applyQualityPreset();
  }

  private applyQualityPreset(): void {
    const dpr = window.devicePixelRatio || 1;
    if (this.isSoftwareGl) {
      this.renderer.setPixelRatio(1);
      this.renderer.shadowMap.enabled = false;
      this.camera.far = 30;
    } else if (this.settings.quality === 'low') {
      this.renderer.setPixelRatio(Math.min(dpr, 1));
      this.renderer.shadowMap.enabled = false;
      this.camera.far = 26;
    } else if (this.settings.quality === 'medium') {
      this.renderer.setPixelRatio(Math.min(dpr, 1.5));
      this.renderer.shadowMap.enabled = true;
      this.camera.far = 36;
    } else {
      this.renderer.setPixelRatio(Math.min(dpr, 2));
      this.renderer.shadowMap.enabled = true;
      this.camera.far = 48;
    }
    this.camera.updateProjectionMatrix();
  }

  private handleKeyDown = (e: KeyboardEvent): void => {
    this.player.setKey(e.code, true);

    if (e.code === 'Escape') {
      if (this.gameState === GameState.INSPECTING) this.closeNote();
      else if (this.gameState === GameState.INVENTORY) this.toggleInventory();
      else if (this.gameState === GameState.CCTV) this.closeCCTV();
      else if (this.gameState === GameState.PHONE) this.closePhone();
      else if (this.gameState === GameState.KEYPAD) this.closeKeypad();
      else if (this.gameState === GameState.PEEPHOLE) this.exitPeephole();
      else if (this.gameState === GameState.HIDING) this.exitHiding();
      else if (this.gameState === GameState.PLAYING) this.setPaused(true);
      else if (this.gameState === GameState.PAUSED) this.setPaused(false);
      return;
    }

    if (this.gameState === GameState.CUTSCENE && e.code === 'Space') {
      this.skipCutscene();
      return;
    }

    if (e.code === 'Tab' || e.code === 'KeyI') {
      if (
        this.gameState === GameState.PLAYING ||
        this.gameState === GameState.INVENTORY
      ) {
        e.preventDefault();
        this.toggleInventory();
      }
      return;
    }

    if (e.code === 'KeyM' || e.code === 'KeyP') {
      if (
        this.gameState === GameState.PLAYING ||
        this.gameState === GameState.PHONE
      ) {
        if (this.gameState === GameState.PHONE) this.closePhone();
        else this.openPhone();
      }
      return;
    }

    if (this.gameState === GameState.CCTV) {
      if (e.code === 'KeyE') this.closeCCTV();
      else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
        this.selectCamera(this.activeCameraIndex + 1);
      } else if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
        this.selectCamera(this.activeCameraIndex - 1);
      }
      return;
    }

    if (this.gameState === GameState.HIDING) {
      if (e.code === 'KeyE' || e.code === 'KeyC') this.exitHiding();
      if (e.code === 'KeyF') this.toggleFlashlight();
      return;
    }

    if (this.gameState === GameState.PEEPHOLE) {
      if (e.code === 'KeyE' || e.code === 'KeyV') this.exitPeephole();
      return;
    }

    if (this.gameState !== GameState.PLAYING) return;

    if (e.code === 'KeyF') this.toggleFlashlight();
    else if (e.code === 'KeyC' || e.code === 'ControlLeft') this.toggleCrouch();
    else if (e.code === 'KeyE') this.triggerInteract();
    else if (e.code === 'KeyV') this.triggerSecondaryInteract();
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.player.setKey(e.code, false);
  };

  // --- Cutscenes ---
  private playFirstSightingCutscene(): void {
    const mPos = this.monster.position.clone();
    this.cutscenes.play({
      id: 'first_encounter',
      title: 'Оно здесь',
      caption: 'Высокий силуэт в полумраке подъезда повернулся на ваш свет...',
      duration: 3.0,
      startPos: this.camera.position.clone(),
      endPos: this.camera.position.clone().add(new THREE.Vector3(0, 0.08, 0)),
      lookAt: new THREE.Vector3(mPos.x, mPos.y + 1.6, mPos.z),
      onStart: () => {
        this.gameState = GameState.CUTSCENE;
        this.sound.playMonsterAlert();
        this.emitHud(true);
      },
      onComplete: () => {
        if (this.gameState === GameState.CUTSCENE) {
          this.gameState = GameState.PLAYING;
        }
        this.saveProgress();
        this.emitHud(true);
      },
    });
  }

  private playElevatorStallCutscene(): void {
    this.cutscenes.play({
      id: 'elevator_stall',
      title: 'Остановка между этажами',
      caption: 'Тросы резко дёрнулись. За решёткой шахты кто-то зашептал...',
      duration: 2.8,
      startPos: this.camera.position.clone(),
      endPos: new THREE.Vector3(
        this.camera.position.x,
        this.camera.position.y + 0.12,
        this.camera.position.z,
      ),
      lookAt: new THREE.Vector3(-2.8, this.camera.position.y + 0.3, -2.1),
      onStart: () => {
        this.gameState = GameState.CUTSCENE;
        this.emitHud(true);
      },
      onComplete: () => {
        if (this.gameState === GameState.CUTSCENE) {
          this.gameState = GameState.PLAYING;
        }
        this.emitHud(true);
      },
    });
  }

  private playSecretRoomCutscene(): void {
    const y4 = getFloorBaseY(4);
    this.cutscenes.play({
      id: 'secret_room_discovery',
      title: 'Потайная комната',
      caption:
        'Фальшстена отъехала в сторону. За ней скрыта комната наблюдателя...',
      duration: 3.4,
      startPos: new THREE.Vector3(3.3, y4 + 1.55, -5.8),
      endPos: new THREE.Vector3(3.3, y4 + 1.6, -7.2),
      lookAt: new THREE.Vector3(3.4, y4 + 1.1, -9.1),
      onStart: () => {
        this.gameState = GameState.CUTSCENE;
        this.sound.playWhisper(0, 0.8);
        this.emitHud(true);
      },
      onComplete: () => {
        if (this.gameState === GameState.CUTSCENE) {
          this.gameState = GameState.PLAYING;
        }
        this.emitHud(true);
      },
    });
  }

  private playPowerRestoredCutscene(): void {
    const y0 = getFloorBaseY(0);
    this.elevator.setPowerEnabled(true);
    this.cutscenes.play({
      id: 'power_restored',
      title: 'Электричество восстановлено',
      caption:
        'Дизель набрал обороты. Свет на этажах и лифт снова под напряжением!',
      duration: 3.4,
      startPos: new THREE.Vector3(2.3, y0 + 1.5, -0.3),
      endPos: new THREE.Vector3(2.7, y0 + 1.65, 0.6),
      lookAt: new THREE.Vector3(3.7, y0 + 0.85, -0.3),
      onStart: () => {
        this.gameState = GameState.CUTSCENE;
        this.emitHud(true);
      },
      onComplete: () => {
        if (this.gameState === GameState.CUTSCENE) {
          this.gameState = GameState.PLAYING;
        }
        this.emitHud(true);
      },
    });
  }

  private playStoryRevelationCutscene(): void {
    const y6 = getFloorBaseY(6);
    this.cutscenes.play({
      id: 'story_revelation',
      title: 'Сигнал заглушён',
      caption:
        'Лента кассеты №4 остановила несущую частоту. Шёпот между этажами стих.',
      duration: 3.6,
      startPos: new THREE.Vector3(2.6, y6 + 1.5, -0.3),
      endPos: new THREE.Vector3(3.2, y6 + 1.6, 0.4),
      lookAt: new THREE.Vector3(4.1, y6 + 1.1, -0.3),
      onStart: () => {
        this.gameState = GameState.CUTSCENE;
        this.sound.playElevatorChime();
        this.emitHud(true);
      },
      onComplete: () => {
        if (this.gameState === GameState.CUTSCENE) {
          this.gameState = GameState.PLAYING;
        }
        this.saveProgress();
        this.emitHud(true);
      },
    });
  }

  private playEndingCutscene(endingId: EndingId): void {
    const ending = ENDINGS[endingId];
    SaveManager.recordEnding(endingId);
    SaveManager.clearSave();
    if (endingId === 'good' || endingId === 'secret' || endingId === 'true') {
      this.unlockAchievement('survivor');
    }

    this.cutscenes.play(
      {
        id: `chapter_finale_${endingId}`,
        title: ending.title,
        caption: ending.subtitle,
        duration: 2.6,
        startPos: this.camera.position.clone(),
        endPos: this.camera.position.clone().add(new THREE.Vector3(0, 0.25, 0)),
        lookAt:
          endingId === 'bad'
            ? this.monster.position.clone().add(new THREE.Vector3(0, 1.7, 0))
            : new THREE.Vector3(-4.2, 1.5, -0.35),
        onStart: () => {
          this.gameState = GameState.CUTSCENE;
          this.emitHud(true);
        },
        onComplete: () => {
          this.activeEnding = ending;
          this.gameState = GameState.ENDING;
          this.sound.setPaused(true);
          this.emitHud(true);
        },
      },
      true,
    );
  }

  public skipCutscene(): void {
    if (this.gameState !== GameState.CUTSCENE) return;
    this.cutscenes.skip();
  }

  private handleMonsterHit(damage: number, pulledFromHide: boolean): void {
    if (pulledFromHide) {
      this.player.exitHiding();
      this.showSubtitle('Оно вытащило вас из укрытия!');
    } else {
      this.showSubtitle(
        'Существо задело вас! Используйте рывок адреналина, чтобы оторваться!',
      );
    }
    const remaining = this.player.takeDamage(damage);
    this.sound.playDistantBang(0);
    if (remaining <= 0) {
      this.playEndingCutscene('bad');
    } else {
      this.emitHud(true);
    }
  }

  // --- Lifecycle & Public API ---
  public startNewGame(): void {
    SaveManager.clearSave();
    this.sound.unlock();
    this.sound.setPaused(false);
    this.quietTimeAccum = 0;
    this.phoneHistory = [];
    this.phoneUnreadCount = 0;
    this.applyDifficultyToSystems();
    this.gameState = GameState.PLAYING;

    const weatherLabel =
      this.nightSeed.weather === 'storm'
        ? 'Гроза за окнами'
        : this.nightSeed.weather === 'fog'
          ? 'Густой туман'
          : 'Дождь';
    this.showSubtitle(
      `Ночь #${this.nightSeed.nightNumber}${this.nightSeed.isNewGamePlus ? ' (НГ+)' : ''} · ${weatherLabel}. Осмотрите ящики на 1 этаже.`,
    );

    window.setTimeout(() => {
      if (this.disposed || this.gameState !== GameState.PLAYING) return;
      this.sound.playPhoneBuzz();
      this.pushPhoneMessage({
        id: `sms_intro_${this.nightSeed.nightNumber}`,
        sender: 'Неизвестный номер',
        text: this.nightSeed.isNewGamePlus
          ? 'Второй круг запущен. Кодовый шкаф в кв. 5 хранит резерв — ищи две половины кода в кв. 2 и кв. 5.'
          : 'Если встретишь Наблюдателя — беги по коридору за угол и прячься в шкафах. В кв. 5 есть монитор камер!',
        timestamp: '00:04',
        photoTitle: 'Дежурный пост охраны (2 этаж)',
        photoCaption: 'Камеры подъезда выведены на монитор квартиры №5.',
        photoScene: 'corridor',
      });
    }, 2800);

    this.saveProgress();
    this.emitHud(true);
  }

  public continueSavedGame(): void {
    const save = SaveManager.loadSave();
    if (!save) {
      this.startNewGame();
      return;
    }

    this.sound.unlock();
    this.sound.setPaused(false);

    if (save.difficulty) {
      this.settings.difficulty = save.difficulty;
    }
    if (save.nightSeed) {
      this.nightSeed = save.nightSeed;
      this.weather.setWeather(save.nightSeed.weather ?? 'rain');
      this.monster.configureNight(
        save.nightSeed.monsterStartFloor,
        save.nightSeed.patrolBias,
      );
    }

    this.applyDifficultyToSystems();

    this.player.position.set(save.playerPos.x, save.playerPos.y, save.playerPos.z);
    this.player.yaw = save.playerYaw;
    this.player.pitch = save.playerPitch;
    this.player.health = save.health;
    this.player.stamina = save.stamina ?? 100;
    this.player.battery = save.battery;
    this.player.flashlightOn = save.flashlightOn;
    this.inventory.setItems(save.inventory);
    this.notesFound = new Set(save.notesFound);
    this.phoneHistory = Array.isArray(save.phoneHistory) ? save.phoneHistory : [];
    this.cutscenes.setTriggeredIds(save.triggeredCutscenes);
    this.elevator.setAtFloorImmediate(save.elevatorFloor);
    this.elevator.setPowerEnabled(save.generatorRunning);

    this.building.applySavedState({
      restoredFloors: save.restoredFloors,
      unlockedDoors: save.unlockedDoors,
      unlockedKeypads: save.unlockedKeypads,
      pickedUpWorldItems: save.pickedUpWorldItems,
      generatorFuelAdded: save.generatorFuelAdded,
      generatorFusesInserted: save.generatorFusesInserted,
      generatorRunning: save.generatorRunning,
      secretPanelOpen: save.secretPanelOpen,
      ventGrateOpen: save.ventGrateOpen,
      atticTransmitterActive: save.atticTransmitterActive,
    });

    this.gameState = GameState.PLAYING;
    this.showSubtitle(`Сохранение загружено (Ночь #${this.nightSeed.nightNumber}).`);
    this.emitHud(true);
  }

  public saveProgress(): void {
    if (this.gameState === GameState.MENU || this.gameState === GameState.ENDING) {
      return;
    }
    const gen = this.building.getGeneratorState();
    const sec = this.building.getSecretStates();
    SaveManager.writeSave({
      version: 2,
      savedAt: Date.now(),
      playerPos: {
        x: this.player.position.x,
        y: this.player.position.y,
        z: this.player.position.z,
      },
      playerYaw: this.player.yaw,
      playerPitch: this.player.pitch,
      health: this.player.health,
      stamina: Math.round(this.player.stamina),
      battery: this.player.battery,
      flashlightOn: this.player.flashlightOn,
      inventory: this.inventory.getItems(),
      notesFound: Array.from(this.notesFound),
      pickedUpWorldItems: this.building.getPickedUpItemIds(),
      unlockedDoors: this.building.getUnlockedDoors(),
      unlockedKeypads: this.building.getUnlockedKeypads(),
      restoredFloors: this.building.getRestoredFloors(),
      generatorFuelAdded: gen.fuelAdded,
      generatorFusesInserted: gen.fusesInserted,
      generatorRunning: gen.running,
      secretPanelOpen: sec.secretPanelOpen,
      ventGrateOpen: sec.ventGrateOpen,
      atticTransmitterActive: sec.atticTransmitterActive,
      triggeredCutscenes: this.cutscenes.getTriggeredIds(),
      elevatorFloor: this.elevator.currentFloor,
      discoveredEndings: SaveManager.getDiscoveredEndings(),
      nightSeed: this.nightSeed,
      difficulty: this.settings.difficulty,
      phoneHistory: this.phoneHistory,
    });
  }

  public setPaused(paused: boolean): void {
    if (this.gameState === GameState.MENU || this.gameState === GameState.ENDING) {
      return;
    }
    if (paused) {
      this.saveProgress();
    }
    this.gameState = paused ? GameState.PAUSED : GameState.PLAYING;
    this.sound.setPaused(paused);
    this.input.moveX = 0;
    this.input.moveY = 0;
    this.input.sprint = false;
    this.emitHud(true);
  }

  public toggleInventory(): void {
    if (this.gameState === GameState.PLAYING) {
      this.gameState = GameState.INVENTORY;
      this.input.moveX = 0;
      this.input.moveY = 0;
      this.input.sprint = false;
    } else if (this.gameState === GameState.INVENTORY) {
      this.gameState = GameState.PLAYING;
    }
    this.emitHud(true);
  }

  public openCCTV(): void {
    if (this.gameState !== GameState.PLAYING) return;
    this.gameState = GameState.CCTV;
    this.input.moveX = 0;
    this.input.moveY = 0;
    this.input.sprint = false;
    this.sound.playCameraSwitch();
    this.checkCCTVDiscoveries();
    this.emitHud(true);
  }

  public closeCCTV(): void {
    if (this.gameState !== GameState.CCTV) return;
    this.sound.playCameraSwitch();
    this.gameState = GameState.PLAYING;
    this.emitHud(true);
  }

  public selectCamera(idx: number): void {
    const count = 5;
    this.activeCameraIndex = ((idx % count) + count) % count;
    this.sound.playCameraSwitch();
    this.checkCCTVDiscoveries();
    this.emitHud(true);
  }

  private checkCCTVDiscoveries(): void {
    const feeds = this.cctv.getFeeds(this.monster.position, this.monster.state);
    const active = feeds[this.activeCameraIndex];
    if (!active) return;
    if (active.monsterOnFloor) this.discoverCreature('stalker');
    if (active.anomaly !== 'none') this.discoverCreature('shadow_phantom');
  }

  public openPhone(): void {
    if (
      this.gameState !== GameState.PLAYING &&
      this.gameState !== GameState.HIDING
    ) {
      return;
    }
    this.phoneUnreadCount = 0;
    this.phoneMessage = null;
    this.input.moveX = 0;
    this.input.moveY = 0;
    this.input.sprint = false;
    this.gameState = GameState.PHONE;
    this.sound.playFlashlightToggle(true);
    this.emitHud(true);
  }

  public closePhone(): void {
    if (this.gameState !== GameState.PHONE) return;
    this.gameState = this.player.hidingTarget ? GameState.HIDING : GameState.PLAYING;
    this.sound.playFlashlightToggle(false);
    this.emitHud(true);
  }

  public openKeypad(opts: PendingKeypadState): void {
    if (this.gameState !== GameState.PLAYING) return;
    this.activeKeypad = opts;
    this.input.moveX = 0;
    this.input.moveY = 0;
    this.input.sprint = false;
    this.gameState = GameState.KEYPAD;
    this.sound.playKeypadBeep();
    this.emitHud(true);
  }

  public submitKeypadCode(code: string): boolean {
    if (!this.activeKeypad) return false;
    if (code === this.activeKeypad.expectedCode) {
      this.sound.playKeypadBeep(true);
      const onUnlocked = this.activeKeypad.onUnlocked;
      this.activeKeypad = null;
      this.gameState = GameState.PLAYING;
      onUnlocked();
      this.saveProgress();
      this.emitHud(true);
      return true;
    }
    this.sound.playKeypadBeep(false);
    return false;
  }

  public closeKeypad(): void {
    if (this.gameState !== GameState.KEYPAD) return;
    this.activeKeypad = null;
    this.gameState = GameState.PLAYING;
    this.emitHud(true);
  }

  public useInventoryItem(itemId: string): void {
    if (!this.inventory.hasItem(itemId)) return;

    if (itemId === 'battery') {
      if (this.player.battery >= 99) {
        this.showSubtitle('Фонарик уже полностью заряжен.');
        return;
      }
      this.inventory.consumeItem('battery', 1);
      this.player.addBattery(45);
      this.sound.playFlashlightToggle(true);
      this.showSubtitle('Батарейка заменена (+45% заряда).');
    } else if (itemId === 'medkit') {
      if (this.player.health >= 100) {
        this.showSubtitle('Здоровье на максимуме.');
        return;
      }
      this.inventory.consumeItem('medkit', 1);
      this.player.heal(50);
      this.sound.playItemPickup();
      this.showSubtitle('Использована аптечка (+50 здоровья).');
    } else {
      this.showSubtitle(
        'Этот предмет применяется автоматически при взаимодействии с нужным объектом.',
      );
      return;
    }

    this.saveProgress();
    this.emitHud(true);
  }

  public dropInventoryItem(itemId: string): void {
    if (this.inventory.consumeItem(itemId, 1)) {
      this.sound.playItemDrop();
      this.player.addNoiseImpulse(72);
      this.monster.notifyNoise(this.player.position, 11);
      this.showSubtitle('Предмет выброшен на пол (громкий звук!).');
      this.saveProgress();
      this.emitHud(true);
    }
  }

  public enterHiding(target: HidingCameraTarget): void {
    this.player.enterHiding(target);
    this.monster.notifyPlayerEnteredHide(target.id, this.player.position);
    this.gameState = GameState.HIDING;
    this.emitHud(true);
  }

  public exitHiding(): void {
    if (this.gameState !== GameState.HIDING) return;
    this.player.exitHiding();
    this.gameState = GameState.PLAYING;
    this.emitHud(true);
  }

  public enterPeephole(target: PeepholeCameraTarget): void {
    this.player.enterPeephole(target);
    this.gameState = GameState.PEEPHOLE;
    this.emitHud(true);
  }

  public exitPeephole(): void {
    if (this.gameState !== GameState.PEEPHOLE) return;
    this.player.exitPeephole();
    this.gameState = GameState.PLAYING;
    this.emitHud(true);
  }

  public updateSettings(next: GameSettings): void {
    this.settings = { ...next };
    this.sound.setVolume(next.volume);
    this.applyDifficultyToSystems();
    this.applyQualityPreset();
  }

  public setJoystickInput(x: number, y: number): void {
    this.input.moveX = x;
    this.input.moveY = y;
  }

  public setSprint(active: boolean): void {
    this.input.sprint = active;
  }

  public addLookDelta(dx: number, dy: number): void {
    this.input.lookDeltaX += dx;
    this.input.lookDeltaY += dy;
  }

  public toggleCrouch(): void {
    if (this.gameState === GameState.HIDING) {
      this.exitHiding();
      return;
    }
    if (this.gameState !== GameState.PLAYING) return;
    this.sound.unlock();
    this.player.toggleCrouch();
    this.emitHud(true);
  }

  public toggleFlashlight(): void {
    if (
      this.gameState !== GameState.PLAYING &&
      this.gameState !== GameState.HIDING
    ) {
      return;
    }
    this.sound.unlock();
    this.player.toggleFlashlight();
    this.emitHud(true);
  }

  public triggerInteract(): void {
    if (this.gameState === GameState.HIDING) {
      this.exitHiding();
      return;
    }
    if (this.gameState === GameState.PEEPHOLE) {
      this.exitPeephole();
      return;
    }
    if (this.gameState !== GameState.PLAYING) return;
    this.sound.unlock();
    if (this.interaction.triggerActive()) {
      this.emitHud(true);
    }
  }

  public triggerSecondaryInteract(): void {
    if (this.gameState !== GameState.PLAYING) return;
    this.sound.unlock();
    if (this.interaction.triggerSecondaryActive()) {
      this.emitHud(true);
    }
  }

  public openNote(note: ReadableNote): void {
    this.notesFound.add(note.id);
    this.activeNote = note;
    this.gameState = GameState.INSPECTING;
    this.input.moveX = 0;
    this.input.moveY = 0;
    this.saveProgress();
    this.emitHud(true);
  }

  public closeNote(): void {
    this.activeNote = null;
    if (this.gameState === GameState.INSPECTING) {
      this.gameState = GameState.PLAYING;
    }
    this.emitHud(true);
  }

  public showSubtitle(text: string): void {
    this.subtitle = text;
    this.subtitleTimer = 4.2;
    this.emitHud(true);
  }

  private afterDraw(cb: () => void): void {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    if (!gl || typeof gl.fenceSync !== 'function') {
      this.frameId = window.setTimeout(cb, 80);
      return;
    }
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) return;
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = (): void => {
    if (this.disposed) return;

    const delta = Math.min(this.clock.getDelta(), 0.08);
    const elapsed = this.clock.elapsedTime;

    if (this.gameState === GameState.MENU) {
      this.camera.position.set(-0.4, 1.55, 0.3);
      this.camera.rotation.set(
        -0.06,
        Math.PI * 0.78 + Math.sin(elapsed * 0.28) * 0.16,
        0,
        'YXZ',
      );
      this.player.flashlight.visible = true;
      this.player.flashlight.position.copy(this.camera.position);
      this.player.flashlightTarget.position.set(
        Math.sin(elapsed * 0.4) * 1.5,
        1.2,
        4.2,
      );
      this.weather.update(delta, 1, 0);
    } else if (this.gameState === GameState.CUTSCENE) {
      this.cutscenes.update(delta, this.camera);
    } else if (
      this.gameState === GameState.PLAYING ||
      this.gameState === GameState.HIDING ||
      this.gameState === GameState.PEEPHOLE ||
      this.gameState === GameState.CCTV ||
      this.gameState === GameState.PHONE ||
      this.gameState === GameState.KEYPAD
    ) {
      const playerFloor = getFloorFromY(this.player.position.y);
      this.weather.update(delta, playerFloor, this.player.position.z);

      const elevatorDeltaY = this.elevator.update(delta, elapsed);
      const insideElevator = this.elevator.isPlayerInside(
        this.player.position.x,
        this.player.position.y,
        this.player.position.z,
      );
      if (
        this.gameState === GameState.PLAYING ||
        this.gameState === GameState.HIDING ||
        this.gameState === GameState.PEEPHOLE
      ) {
        this.player.update(
          delta,
          this.input,
          this.settings,
          insideElevator ? elevatorDeltaY : 0,
        );
      }

      this.cctv.update(delta);

      // Update Monster AI
      this.monster.update(
        delta,
        elapsed,
        this.player.position,
        this.player.noiseLevel,
        this.player.flashlightOn,
        this.player.crouching,
        this.player.hidingTarget?.id ?? null,
        this.building.hidingZones,
        this.building.occlusionMeshes,
        this.player.isInvulnerable(),
      );

      // Fear System calculation + gentle nervous breathing
      const targetFear = THREE.MathUtils.clamp(
        this.monster.dangerLevel * 0.72 +
          (!this.player.flashlightOn ? 0.18 : 0) +
          (this.monster.state === 'CHASE' ? 0.28 : 0),
        0,
        1,
      );
      this.fearLevel = THREE.MathUtils.damp(this.fearLevel, targetFear, 1.4, delta);
      this.player.setFearLevel(this.fearLevel);

      if (this.fearLevel > 0.52) {
        this.breathingTimer -= delta;
        if (this.breathingTimer <= 0) {
          this.sound.playBreathing(this.fearLevel);
          this.breathingTimer = 2.6 - this.fearLevel * 1.1;
        }
      }

      // Achievement: Night Guest (explore basement)
      if (playerFloor === 0) {
        this.unlockAchievement('night_guest');
      }

      // Achievement: Quiet One (steady quiet movement)
      if (
        this.gameState === GameState.PLAYING &&
        this.player.noiseLevel < 34 &&
        !this.player.sprinting &&
        (Math.abs(this.input.moveX) > 0.1 || Math.abs(this.input.moveY) > 0.1)
      ) {
        this.quietTimeAccum += delta;
        if (this.quietTimeAccum >= 18) {
          this.unlockAchievement('quiet_one');
        }
      } else if (this.player.noiseLevel > 58) {
        this.quietTimeAccum = 0;
      }

      // Emit footstep noise impulse to monster if sprinting
      this.lastFootNoiseEmit += delta;
      if (this.player.sprinting && this.lastFootNoiseEmit > 0.65) {
        this.lastFootNoiseEmit = 0;
        this.monster.notifyNoise(this.player.position, 13);
      }

      // Heartbeat audio when monster is dangerously close
      if (this.monster.currentDistance < 8.5) {
        this.heartbeatTimer -= delta;
        if (this.heartbeatTimer <= 0) {
          const proximity = 1 - this.monster.currentDistance / 8.5;
          this.sound.playHeartbeat(0.35 + proximity * 0.65);
          this.heartbeatTimer = 1.15 - proximity * 0.55;
        }
      }

      const genState = this.building.getGeneratorState();
      this.director.update(
        delta,
        elapsed,
        this.player.position,
        playerFloor,
        this.monster.currentDistance,
        genState.running,
        this.building.floorLights,
        (scale) => this.player.setFlashlightFlicker(scale),
      );

      if (this.subtitleTimer > 0) {
        this.subtitleTimer -= delta;
        if (this.subtitleTimer <= 0) {
          this.subtitle = null;
          this.emitHud(true);
        }
      }

      if (this.phoneMessageTimer > 0) {
        this.phoneMessageTimer -= delta;
        if (this.phoneMessageTimer <= 0) {
          this.phoneMessage = null;
          this.emitHud(true);
        }
      }

      if (this.achievementToastTimer > 0) {
        this.achievementToastTimer -= delta;
        if (this.achievementToastTimer <= 0) {
          this.achievementToast = null;
          this.emitHud(true);
        }
      }

      this.autoSaveAccum += delta;
      if (this.autoSaveAccum >= 12) {
        this.autoSaveAccum = 0;
        this.saveProgress();
      }

      this.hudEmitAccum += delta;
      if (this.hudEmitAccum >= 0.08) {
        this.hudEmitAccum = 0;
        this.emitHud(false);
      }
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  private emitHud(force: boolean): void {
    const prompt =
      this.gameState === GameState.PLAYING
        ? this.interaction.update(this.camera, force ? 0.1 : 0.08)
        : null;

    const currentFloor = getFloorFromY(this.player.position.y);
    const gen = this.building.getGeneratorState();

    this.onHudUpdate({
      gameState: this.gameState,
      currentFloor,
      locationName: getLocationLabel(
        currentFloor,
        this.player.position.x,
        this.player.position.z,
      ),
      elevatorFloor: this.elevator.currentFloor,
      elevatorState: this.elevator.state,
      elevatorPowered: this.elevator.powerEnabled,
      flashlightOn: this.player.flashlightOn,
      battery: Math.round(this.player.battery),
      health: Math.round(this.player.health),
      stamina: Math.round(this.player.stamina),
      exhausted: this.player.exhausted,
      noiseLevel: Math.round(this.player.noiseLevel),
      crouching: this.player.crouching,
      sprinting: this.player.sprinting,
      hidingSpotName: this.player.hidingTarget?.name ?? null,
      peepholeActive: Boolean(this.player.peepholeTarget),
      peepholeLabel: this.player.peepholeTarget?.label ?? null,
      activePrompt: prompt,
      activeNote: this.activeNote,
      activeCutscene: this.cutscenes.getInfo(),
      activeEnding: this.activeEnding,
      activeKeypad: this.activeKeypad
        ? {
            id: this.activeKeypad.id,
            title: this.activeKeypad.title,
            hint: this.activeKeypad.hint,
          }
        : null,
      subtitle: this.subtitle,
      phoneMessage: this.phoneMessage,
      phoneHistory: this.phoneHistory,
      phoneUnreadCount: this.phoneUnreadCount,
      achievementToast: this.achievementToast,
      inventory: this.inventory.getItems(),
      maxInventorySlots: MAX_INVENTORY_SLOTS,
      notesFound: Array.from(this.notesFound),
      restoredFloors: this.building.getRestoredFloors(),
      generatorRunning: gen.running,
      generatorFuelAdded: gen.fuelAdded,
      generatorFusesInserted: gen.fusesInserted,
      monsterState: this.monster.state,
      monsterDistance: Math.round(this.monster.currentDistance * 10) / 10,
      monsterWindingUp: this.monster.isWindingUp,
      dangerLevel: this.monster.dangerLevel,
      fearLevel: this.fearLevel,
      tension: this.director.tension,
      damageFlash: this.player.getDamageFlash(),
      nightNumber: this.nightSeed.nightNumber,
      difficulty: this.settings.difficulty,
      weather: this.nightSeed.weather,
      isNewGamePlus: this.nightSeed.isNewGamePlus,
      isTouchDevice: this.isTouchDevice,
      cctvFeeds: this.cctv.getFeeds(this.monster.position, this.monster.state),
      activeCameraIndex: this.activeCameraIndex,
      discoveredCreatures: this.creatures.getDiscoveredIds(),
    });
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
    this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);

    this.renderer.domElement.removeEventListener(
      'webglcontextlost',
      this.handleContextLost,
    );
    this.renderer.domElement.removeEventListener(
      'webglcontextrestored',
      this.handleContextRestored,
    );

    this.sound.dispose();
    this.elevator.dispose();
    this.monster.dispose();
    this.weather.dispose();
    this.materials.dispose();
    this.building.disposables.forEach((g) => g.dispose());
    this.envRT?.dispose();
    this.collision.clear();
    this.interaction.clear();

    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
