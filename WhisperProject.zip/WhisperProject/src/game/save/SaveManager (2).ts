import { AchievementId, CreatureId, EndingId, SaveDataV2 } from '../types';
import { AchievementManager } from '../achievements/AchievementManager';
import { CreatureGalleryManager } from '../story/CreatureGalleryData';

const SAVE_KEY = 'whisper_floors_save_v2';
const ENDINGS_KEY = 'whisper_floors_endings_v2';

export interface SaveBackupBundle {
  app: 'whisper-between-floors';
  exportedAt: number;
  save: SaveDataV2 | null;
  discoveredEndings: EndingId[];
  achievements?: AchievementId[];
  discoveredCreatures?: CreatureId[];
}

export class SaveManager {
  public static hasSave(): boolean {
    try {
      return Boolean(localStorage.getItem(SAVE_KEY));
    } catch {
      return false;
    }
  }

  public static loadSave(): SaveDataV2 | null {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as SaveDataV2;
      if (parsed && parsed.version === 2) return parsed;
      return null;
    } catch {
      return null;
    }
  }

  public static writeSave(data: SaveDataV2): void {
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(data));
    } catch {
      // Ignore quota errors on restricted environments
    }
  }

  public static clearSave(): void {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      // Ignore
    }
  }

  public static getDiscoveredEndings(): EndingId[] {
    try {
      const raw = localStorage.getItem(ENDINGS_KEY);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch {
      return [];
    }
  }

  public static recordEnding(ending: EndingId): EndingId[] {
    const existing = new Set(this.getDiscoveredEndings());
    existing.add(ending);
    const list = Array.from(existing);
    try {
      localStorage.setItem(ENDINGS_KEY, JSON.stringify(list));
    } catch {
      // Ignore
    }
    return list;
  }

  public static exportBackupJson(): string {
    const ach = new AchievementManager();
    const creatures = new CreatureGalleryManager();
    const bundle: SaveBackupBundle = {
      app: 'whisper-between-floors',
      exportedAt: Date.now(),
      save: this.loadSave(),
      discoveredEndings: this.getDiscoveredEndings(),
      achievements: ach.getUnlockedIds(),
      discoveredCreatures: creatures.getDiscoveredIds(),
    };
    return JSON.stringify(bundle, null, 2);
  }

  public static importBackupJson(raw: string): {
    ok: boolean;
    hasSave: boolean;
    endingsCount: number;
  } {
    try {
      const parsed = JSON.parse(raw) as Partial<SaveBackupBundle>;
      if (!parsed || parsed.app !== 'whisper-between-floors') {
        return { ok: false, hasSave: this.hasSave(), endingsCount: 0 };
      }

      if (parsed.save && parsed.save.version === 2) {
        this.writeSave(parsed.save);
      }

      if (Array.isArray(parsed.discoveredEndings)) {
        const merged = new Set(this.getDiscoveredEndings());
        for (const e of parsed.discoveredEndings) {
          if (e === 'good' || e === 'bad' || e === 'secret' || e === 'true') {
            merged.add(e);
          }
        }
        localStorage.setItem(ENDINGS_KEY, JSON.stringify(Array.from(merged)));
      }

      if (Array.isArray(parsed.achievements)) {
        const ach = new AchievementManager();
        ach.mergeUnlocked(parsed.achievements);
      }

      if (Array.isArray(parsed.discoveredCreatures)) {
        const creatures = new CreatureGalleryManager();
        creatures.mergeDiscovered(parsed.discoveredCreatures);
      }

      return {
        ok: true,
        hasSave: this.hasSave(),
        endingsCount: this.getDiscoveredEndings().length,
      };
    } catch {
      return { ok: false, hasSave: this.hasSave(), endingsCount: 0 };
    }
  }
}
