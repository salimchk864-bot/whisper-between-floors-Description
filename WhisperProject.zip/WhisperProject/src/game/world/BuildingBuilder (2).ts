import * as THREE from 'three';
import { BUILDING, getFloorBaseY } from './BuildingConfig';
import { MaterialLibrary } from './MaterialLibrary';
import { BoxCollider, CollisionWorld } from '../engine/CollisionWorld';
import { InteractionManager } from '../engine/InteractionManager';
import { SoundEngine } from '../audio/SoundEngine';
import { InventorySystem } from '../inventory/InventorySystem';
import { HidingCameraTarget, PeepholeCameraTarget } from '../engine/PlayerController';
import { HidingCheckZone, DoorNavBridge } from './MonsterAI';
import { ApartmentBuilder } from './ApartmentBuilder';
import { STORY_NOTES } from '../story/NotesData';
import { EndingId, NightSeedData, ReadableNote } from '../types';

export interface FloorLightRig {
  floor: number;
  light: THREE.PointLight;
  tubeMat: THREE.MeshStandardMaterial;
  powered: boolean;
  baseIntensity: number;
  isApartment?: boolean;
  flickerPhase?: number;
}

export interface WorldItemHandle {
  id: string;
  mesh: THREE.Object3D;
  pickedUp: boolean;
}

export interface BuildingCallbacks {
  nightSeed: NightSeedData;
  cameraMountSpecs: { pos: THREE.Vector3; yaw: number; floor: number }[];
  onOpenNote: (note: ReadableNote) => void;
  onSubtitle: (text: string) => void;
  onEnterHide: (target: HidingCameraTarget) => void;
  onEnterPeephole: (target: PeepholeCameraTarget) => void;
  onOpenCCTV: () => void;
  onOpenKeypad: (opts: {
    id: string;
    title: string;
    hint: string;
    expectedCode: string;
    onUnlocked: () => void;
  }) => void;
  onGeneratorStarted: () => void;
  onSecretRoomDiscovered: () => void;
  onSecretFound: () => void;
  onRadioTriggered?: () => void;
  onStoryRevelation: () => void;
  onTriggerEnding: (ending: EndingId) => void;
  onNoiseImpulse: (pos: THREE.Vector3, radius: number) => void;
  onStateChanged: () => void;
  onRegisterDoorBridge: (bridge: DoorNavBridge) => void;
  onLinkNavEdge: (
    corridorNodeId: string,
    roomNodeId: string,
    roomPos: THREE.Vector3,
    floor: number,
    doorId: string,
  ) => void;
}

export interface BuildingBuildResult {
  floorLights: FloorLightRig[];
  occlusionMeshes: THREE.Object3D[];
  hidingZones: HidingCheckZone[];
  disposables: THREE.BufferGeometry[];
  getRestoredFloors: () => number[];
  getUnlockedDoors: () => string[];
  getUnlockedKeypads: () => string[];
  getPickedUpItemIds: () => string[];
  getGeneratorState: () => {
    fuelAdded: boolean;
    fusesInserted: number;
    running: boolean;
  };
  getSecretStates: () => {
    secretPanelOpen: boolean;
    ventGrateOpen: boolean;
    atticTransmitterActive: boolean;
  };
  applySavedState: (state: {
    restoredFloors: number[];
    unlockedDoors: string[];
    unlockedKeypads?: string[];
    pickedUpWorldItems: string[];
    generatorFuelAdded: boolean;
    generatorFusesInserted: number;
    generatorRunning: boolean;
    secretPanelOpen: boolean;
    ventGrateOpen: boolean;
    atticTransmitterActive: boolean;
  }) => void;
  creakNearestDoor: (floor: number) => void;
  flickerFloorLight: (floor: number) => void;
}

export class BuildingBuilder {
  private geos: THREE.BufferGeometry[] = [];
  private occlusionMeshes: THREE.Object3D[] = [];
  private floorLights: FloorLightRig[] = [];
  private hidingZones: HidingCheckZone[] = [];

  private restoredFloors = new Set<number>([1, 4]);
  private unlockedDoors = new Set<string>();
  private unlockedKeypads = new Set<string>();
  private pickedUpItems = new Set<string>();
  private worldItems = new Map<string, WorldItemHandle>();
  private doorActions = new Map<string, () => void>();
  private floorDoorIds = new Map<number, string[]>();

  // Generator & puzzle states
  private generatorFuelAdded = false;
  private generatorFusesInserted = 0;
  private generatorRunning = false;
  private secretPanelOpen = false;
  private ventGrateOpen = false;
  private atticTransmitterActive = false;

  // Dynamic pivots & colliders for save restoration
  private dynamicUnlockers = new Map<string, () => void>();
  private generatorLedMat!: THREE.MeshStandardMaterial;

  constructor(
    private scene: THREE.Scene,
    private mats: MaterialLibrary,
    private collision: CollisionWorld,
    private interaction: InteractionManager,
    private sound: SoundEngine,
    private inventory: InventorySystem,
    private callbacks: BuildingCallbacks,
  ) {}

  private trackGeo<T extends THREE.BufferGeometry>(g: T): T {
    this.geos.push(g);
    return g;
  }

  public build(): BuildingBuildResult {
    this.buildSlabsAndPerimeterWalls();
    this.buildAllStairFlights();
    this.buildBasementAndSwitchboard();
    this.buildFloor1EntranceAndMailboxes();
    this.buildResidentialFloorsAndPeepholes();
    this.buildFloor3VentAndSecretNiche();
    this.buildFloor4Apt10AndSecretRoom();
    this.buildAtticAndTransmitter();
    this.buildHidingSpots();
    this.buildWorldItemsAndNotes();

    const aptBuilder = new ApartmentBuilder({
      scene: this.scene,
      mats: this.mats,
      collision: this.collision,
      interaction: this.interaction,
      sound: this.sound,
      nightSeed: this.callbacks.nightSeed,
      unlockedKeypads: this.unlockedKeypads,
      dynamicUnlockers: this.dynamicUnlockers,
      occlusionMeshes: this.occlusionMeshes,
      floorLights: this.floorLights,
      trackGeo: (g) => this.trackGeo(g),
      addWallBox: (x1, x2, y1, y2, z1, z2, mat, collide, occlude) =>
        this.addWallBox(x1, x2, y1, y2, z1, z2, mat, collide, occlude),
      buildInteriorDoor: (opts) => this.buildInteriorDoor(opts),
      registerHidingSpot: (cfg) => this.registerHidingSpot(cfg),
      spawnWorldItem: (cfg) => this.spawnWorldItem(cfg),
      spawnWorldNote: (id, note, pos) => this.spawnWorldNote(id, note, pos),
      linkNavEdge: (cId, rId, rPos, floor, doorId) =>
        this.callbacks.onLinkNavEdge(cId, rId, rPos, floor, doorId),
      onOpenCCTV: () => this.callbacks.onOpenCCTV(),
      onSecretFound: () => this.callbacks.onSecretFound(),
      onSubtitle: (msg) => this.callbacks.onSubtitle(msg),
      onNoiseImpulse: (pos, rad) => this.callbacks.onNoiseImpulse(pos, rad),
      onRadioTriggered: () => this.callbacks.onRadioTriggered?.(),
      onOpenKeypad: (opts) => this.callbacks.onOpenKeypad(opts),
    });
    aptBuilder.buildAllApartments();

    this.buildSecurityCameras(this.callbacks.cameraMountSpecs);
    this.buildFloorLights();

    return {
      floorLights: this.floorLights,
      occlusionMeshes: this.occlusionMeshes,
      hidingZones: this.hidingZones,
      disposables: this.geos,
      getRestoredFloors: () => Array.from(this.restoredFloors).sort(),
      getUnlockedDoors: () => Array.from(this.unlockedDoors),
      getUnlockedKeypads: () => Array.from(this.unlockedKeypads),
      getPickedUpItemIds: () => Array.from(this.pickedUpItems),
      getGeneratorState: () => ({
        fuelAdded: this.generatorFuelAdded,
        fusesInserted: this.generatorFusesInserted,
        running: this.generatorRunning,
      }),
      getSecretStates: () => ({
        secretPanelOpen: this.secretPanelOpen,
        ventGrateOpen: this.ventGrateOpen,
        atticTransmitterActive: this.atticTransmitterActive,
      }),
      applySavedState: (s) => this.applySavedState(s),
      creakNearestDoor: (floor) => this.creakNearestDoor(floor),
      flickerFloorLight: (floor) => this.flickerFloorLight(floor),
    };
  }

  private addWallBox(
    x1: number,
    x2: number,
    y1: number,
    y2: number,
    z1: number,
    z2: number,
    mat: THREE.Material,
    collide = true,
    occlude = true,
  ): THREE.Mesh {
    const w = Math.abs(x2 - x1);
    const h = Math.abs(y2 - y1);
    const d = Math.abs(z2 - z1);
    const mesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(w, h, d)),
      mat,
    );
    mesh.position.set((x1 + x2) / 2, (y1 + y2) / 2, (z1 + z2) / 2);
    mesh.receiveShadow = true;
    this.scene.add(mesh);

    if (occlude) this.occlusionMeshes.push(mesh);

    if (collide) {
      this.collision.addCollider({
        minX: Math.min(x1, x2),
        maxX: Math.max(x1, x2),
        minY: Math.min(y1, y2),
        maxY: Math.max(y1, y2),
        minZ: Math.min(z1, z2),
        maxZ: Math.max(z1, z2),
      });
    }
    return mesh;
  }

  private buildSlabsAndPerimeterWalls(): void {
    const t = BUILDING.WALL_THICKNESS;
    const slabT = BUILDING.SLAB_THICKNESS;

    // Floors 0 (Basement) through 6 (Attic)
    for (let f: number = BUILDING.MIN_FLOOR; f <= BUILDING.MAX_FLOOR; f++) {
      const y = getFloorBaseY(f);
      const w = BUILDING.EAST_X - BUILDING.WEST_X;
      const d = BUILDING.LANDING_SOUTH_Z - BUILDING.NORTH_Z;

      const slab = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(w, slabT, d)),
        this.mats.floorTile,
      );
      slab.position.set(
        (BUILDING.WEST_X + BUILDING.EAST_X) / 2,
        y - slabT / 2,
        (BUILDING.NORTH_Z + BUILDING.LANDING_SOUTH_Z) / 2,
      );
      slab.receiveShadow = true;
      this.scene.add(slab);
      this.occlusionMeshes.push(slab);

      if (f > BUILDING.MIN_FLOOR) {
        const ceil = new THREE.Mesh(
          this.trackGeo(new THREE.PlaneGeometry(w, d)),
          this.mats.ceilingConcrete,
        );
        ceil.rotation.x = Math.PI / 2;
        ceil.position.set(
          (BUILDING.WEST_X + BUILDING.EAST_X) / 2,
          y - slabT - 0.005,
          (BUILDING.NORTH_Z + BUILDING.LANDING_SOUTH_Z) / 2,
        );
        this.scene.add(ceil);
      }

      this.collision.addWalkSurface({
        id: `landing_floor_${f}`,
        minX: BUILDING.WEST_X,
        maxX: BUILDING.EAST_X,
        minZ: BUILDING.NORTH_Z,
        maxZ: BUILDING.LANDING_SOUTH_Z,
        getY: () => y,
      });

      if (f >= 1 && f <= 5) {
        const stencil = new THREE.Mesh(
          this.trackGeo(new THREE.PlaneGeometry(0.55, 0.55)),
          this.mats.createStencilPlateMaterial(
            String(f),
            '#324239',
            '#d2d4cc',
            128,
            128,
          ),
        );
        stencil.position.set(-1.35, y + 1.85, BUILDING.NORTH_Z + 0.015);
        this.scene.add(stencil);
      }

      // Perimeter walls for floor f
      const y1 = y;
      const y2 = y + BUILDING.FLOOR_HEIGHT;
      const wallMat =
        f === 0
          ? this.mats.wallBasementBrick
          : f === 6
            ? this.mats.wallAtticPlanks
            : this.mats.wallStairwell;

      // West wall
      this.addWallBox(
        BUILDING.WEST_X - t,
        BUILDING.WEST_X,
        y1,
        y2,
        BUILDING.NORTH_Z,
        BUILDING.LANDING_SOUTH_Z,
        wallMat,
      );

      // East wall (Floor 3 Secret Niche Z in [-0.2, +0.9]; Floor 1 Apt 2 & Floor 5 Apt 14 Z in [-0.75, +0.15])
      if (f === 3) {
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1,
          y2,
          BUILDING.NORTH_Z,
          -0.2,
          wallMat,
        );
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1,
          y2,
          0.9,
          BUILDING.LANDING_SOUTH_Z,
          wallMat,
        );
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1 + 2.0,
          y2,
          -0.2,
          0.9,
          wallMat,
          false,
        );
      } else if (f === 1 || f === 2 || f === 4 || f === 5) {
        // East doorways for Apt 2 (F1), Apt 5 (F2), Apt 11 (F4), Apt 14 (F5)
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1,
          y2,
          BUILDING.NORTH_Z,
          -0.75,
          wallMat,
        );
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1,
          y2,
          0.15,
          BUILDING.LANDING_SOUTH_Z,
          wallMat,
        );
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1 + 2.1,
          y2,
          -0.75,
          0.15,
          wallMat,
          false,
        );
      } else {
        this.addWallBox(
          BUILDING.EAST_X,
          BUILDING.EAST_X + t,
          y1,
          y2,
          BUILDING.NORTH_Z,
          BUILDING.LANDING_SOUTH_Z,
          wallMat,
        );
      }

      // North wall: Elevator shaft opening (Floors 1..5) + Apt 4 (F2), Apt 7 (F3), Apt 10 (F4), Apt 13 (F5)
      if (f >= 1 && f <= 5) {
        this.addWallBox(
          BUILDING.WEST_X - t,
          BUILDING.ELEVATOR_CENTER_X - BUILDING.ELEVATOR_DOOR_WIDTH / 2,
          y1,
          y2,
          BUILDING.NORTH_Z - t,
          BUILDING.NORTH_Z,
          wallMat,
        );
        this.addWallBox(
          BUILDING.ELEVATOR_CENTER_X - BUILDING.ELEVATOR_DOOR_WIDTH / 2,
          BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2,
          y1 + BUILDING.ELEVATOR_DOOR_HEIGHT,
          y2,
          BUILDING.NORTH_Z - t,
          BUILDING.NORTH_Z,
          wallMat,
          false,
        );

        // North wall east of elevator: X from -2.15 to +5.2
        if (f >= 2 && f <= 5) {
          // Doorway opening at X in [2.85, 3.75] for Apt 4 (F2), Apt 7 (F3), Apt 10 (F4), Apt 13 (F5)
          this.addWallBox(
            BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2,
            2.85,
            y1,
            y2,
            BUILDING.NORTH_Z - t,
            BUILDING.NORTH_Z,
            wallMat,
          );
          this.addWallBox(
            3.75,
            BUILDING.EAST_X + t,
            y1,
            y2,
            BUILDING.NORTH_Z - t,
            BUILDING.NORTH_Z,
            wallMat,
          );
          this.addWallBox(
            2.85,
            3.75,
            y1 + 2.1,
            y2,
            BUILDING.NORTH_Z - t,
            BUILDING.NORTH_Z,
            wallMat,
            false,
          );
        } else {
          this.addWallBox(
            BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2,
            BUILDING.EAST_X + t,
            y1,
            y2,
            BUILDING.NORTH_Z - t,
            BUILDING.NORTH_Z,
            wallMat,
          );
        }
      } else {
        // Basement & Attic solid North wall
        this.addWallBox(
          BUILDING.WEST_X - t,
          BUILDING.EAST_X + t,
          y1,
          y2,
          BUILDING.NORTH_Z - t,
          BUILDING.NORTH_Z,
          wallMat,
        );
      }

      // South walls flanking stairwell opening (Z = +1.5)
      this.addWallBox(
        BUILDING.WEST_X - t,
        BUILDING.STAIR_WEST_X,
        y1,
        y2,
        BUILDING.LANDING_SOUTH_Z,
        BUILDING.LANDING_SOUTH_Z + t,
        wallMat,
      );
      this.addWallBox(
        BUILDING.STAIR_EAST_X,
        BUILDING.EAST_X + t,
        y1,
        y2,
        BUILDING.LANDING_SOUTH_Z,
        BUILDING.LANDING_SOUTH_Z + t,
        wallMat,
      );
    }

    // Attic Roof Slab at Y = 19.2
    const roofY = getFloorBaseY(BUILDING.MAX_FLOOR) + BUILDING.FLOOR_HEIGHT;
    const roofW = BUILDING.EAST_X - BUILDING.WEST_X;
    const roofD = BUILDING.STAIR_SOUTH_Z - BUILDING.NORTH_Z;
    const roof = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(roofW, 0.3, roofD)),
      this.mats.wallAtticPlanks,
    );
    roof.position.set(
      (BUILDING.WEST_X + BUILDING.EAST_X) / 2,
      roofY + 0.15,
      (BUILDING.NORTH_Z + BUILDING.STAIR_SOUTH_Z) / 2,
    );
    this.scene.add(roof);
  }

  private buildAllStairFlights(): void {
    const t = BUILDING.WALL_THICKNESS;

    for (let f = BUILDING.MIN_FLOOR; f <= BUILDING.MAX_FLOOR; f++) {
      const y1 = getFloorBaseY(f);
      const y2 = y1 + BUILDING.FLOOR_HEIGHT;
      const wallMat =
        f === 0
          ? this.mats.wallBasementBrick
          : f === 6
            ? this.mats.wallAtticPlanks
            : this.mats.wallStairwell;

      this.addWallBox(
        BUILDING.STAIR_WEST_X - t,
        BUILDING.STAIR_WEST_X,
        y1,
        y2,
        BUILDING.LANDING_SOUTH_Z,
        BUILDING.STAIR_SOUTH_Z + t,
        wallMat,
      );
      this.addWallBox(
        BUILDING.STAIR_EAST_X,
        BUILDING.STAIR_EAST_X + t,
        y1,
        y2,
        BUILDING.LANDING_SOUTH_Z,
        BUILDING.STAIR_SOUTH_Z + t,
        wallMat,
      );

      // South stairwell wall with windows on residential half-landings 1..4
      if (f >= 1 && f <= 4) {
        const winMinX = -1.65;
        const winMaxX = 0.25;
        const winMinY = y1 + BUILDING.HALF_HEIGHT + 0.72;
        const winMaxY = y1 + BUILDING.HALF_HEIGHT + 2.55;

        this.addWallBox(
          BUILDING.STAIR_WEST_X,
          winMinX,
          y1,
          y2,
          BUILDING.STAIR_SOUTH_Z,
          BUILDING.STAIR_SOUTH_Z + t,
          wallMat,
        );
        this.addWallBox(
          winMaxX,
          BUILDING.STAIR_EAST_X,
          y1,
          y2,
          BUILDING.STAIR_SOUTH_Z,
          BUILDING.STAIR_SOUTH_Z + t,
          wallMat,
        );
        this.addWallBox(
          winMinX,
          winMaxX,
          y1,
          winMinY,
          BUILDING.STAIR_SOUTH_Z,
          BUILDING.STAIR_SOUTH_Z + t,
          wallMat,
        );
        this.addWallBox(
          winMinX,
          winMaxX,
          winMaxY,
          y2,
          BUILDING.STAIR_SOUTH_Z,
          BUILDING.STAIR_SOUTH_Z + t,
          wallMat,
        );

        const winW = winMaxX - winMinX;
        const winH = winMaxY - winMinY;
        const winCX = (winMinX + winMaxX) / 2;
        const winCY = (winMinY + winMaxY) / 2;

        const glass = new THREE.Mesh(
          this.trackGeo(new THREE.PlaneGeometry(winW - 0.1, winH - 0.1)),
          this.mats.windowGlass,
        );
        glass.position.set(winCX, winCY, BUILDING.STAIR_SOUTH_Z + 0.08);
        glass.rotation.y = Math.PI;
        this.scene.add(glass);

        const mullionV = new THREE.Mesh(
          this.trackGeo(new THREE.BoxGeometry(0.06, winH, 0.08)),
          this.mats.trimDark,
        );
        mullionV.position.set(winCX, winCY, BUILDING.STAIR_SOUTH_Z + 0.08);
        this.scene.add(mullionV);

        const mullionH = new THREE.Mesh(
          this.trackGeo(new THREE.BoxGeometry(winW, 0.06, 0.08)),
          this.mats.trimDark,
        );
        mullionH.position.set(winCX, winCY + 0.25, BUILDING.STAIR_SOUTH_Z + 0.08);
        this.scene.add(mullionH);

        const sill = new THREE.Mesh(
          this.trackGeo(new THREE.BoxGeometry(winW + 0.16, 0.06, 0.26)),
          this.mats.concreteStep,
        );
        sill.position.set(winCX, winMinY + 0.02, BUILDING.STAIR_SOUTH_Z - 0.04);
        this.scene.add(sill);
      } else {
        this.addWallBox(
          BUILDING.STAIR_WEST_X,
          BUILDING.STAIR_EAST_X,
          y1,
          y2,
          BUILDING.STAIR_SOUTH_Z,
          BUILDING.STAIR_SOUTH_Z + t,
          wallMat,
        );
      }
    }

    // Basement stairwell pit ground slab (Y = -3.2)
    const stairPitW = BUILDING.STAIR_EAST_X - BUILDING.STAIR_WEST_X;
    const stairPitD = BUILDING.STAIR_SOUTH_Z - BUILDING.LANDING_SOUTH_Z;
    const stairGround = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(stairPitW, 0.22, stairPitD)),
      this.mats.floorTile,
    );
    stairGround.position.set(
      (BUILDING.STAIR_WEST_X + BUILDING.STAIR_EAST_X) / 2,
      getFloorBaseY(0) - 0.11,
      (BUILDING.LANDING_SOUTH_Z + BUILDING.STAIR_SOUTH_Z) / 2,
    );
    stairGround.receiveShadow = true;
    this.scene.add(stairGround);

    // Block dead space under Flight B at Basement Y = -3.2
    this.collision.addCollider({
      minX: BUILDING.STAIR_WEST_X,
      maxX: BUILDING.FLIGHT_A_MIN_X,
      minY: getFloorBaseY(0),
      maxY: getFloorBaseY(0) + 2.2,
      minZ: BUILDING.LANDING_SOUTH_Z + 0.15,
      maxZ: BUILDING.LANDING_SOUTH_Z + 0.35,
    });

    // Build stair flights connecting floor f -> f+1 for f = 0..5
    for (let f = BUILDING.MIN_FLOOR; f < BUILDING.MAX_FLOOR; f++) {
      const baseY = getFloorBaseY(f);
      const halfY = baseY + BUILDING.HALF_HEIGHT;

      const hlW = BUILDING.STAIR_EAST_X - BUILDING.STAIR_WEST_X;
      const hlD = BUILDING.HALF_LANDING_MAX_Z - BUILDING.HALF_LANDING_MIN_Z;
      const hlSlab = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(hlW, 0.2, hlD)),
        this.mats.floorTile,
      );
      hlSlab.position.set(
        (BUILDING.STAIR_WEST_X + BUILDING.STAIR_EAST_X) / 2,
        halfY - 0.1,
        (BUILDING.HALF_LANDING_MIN_Z + BUILDING.HALF_LANDING_MAX_Z) / 2,
      );
      hlSlab.receiveShadow = true;
      this.scene.add(hlSlab);

      this.collision.addWalkSurface({
        id: `half_landing_${f}`,
        minX: BUILDING.STAIR_WEST_X,
        maxX: BUILDING.STAIR_EAST_X,
        minZ: BUILDING.HALF_LANDING_MIN_Z,
        maxZ: BUILDING.HALF_LANDING_MAX_Z,
        getY: () => halfY,
      });

      this.buildStairFlight(
        BUILDING.FLIGHT_A_MIN_X,
        BUILDING.FLIGHT_A_MAX_X,
        BUILDING.STAIR_START_Z,
        BUILDING.STAIR_END_Z,
        baseY,
        halfY,
        BUILDING.FLIGHT_A_MIN_X + 0.04,
      );

      this.buildStairFlight(
        BUILDING.FLIGHT_B_MIN_X,
        BUILDING.FLIGHT_B_MAX_X,
        BUILDING.STAIR_END_Z,
        BUILDING.STAIR_START_Z,
        halfY,
        baseY + BUILDING.FLOOR_HEIGHT,
        BUILDING.FLIGHT_B_MAX_X - 0.04,
      );

      const nextY = baseY + BUILDING.FLOOR_HEIGHT;
      this.buildBalustrade(
        BUILDING.FLIGHT_B_MAX_X,
        BUILDING.FLIGHT_A_MIN_X,
        nextY,
        BUILDING.LANDING_SOUTH_Z + 0.04,
        nextY,
        BUILDING.LANDING_SOUTH_Z + 0.04,
      );
      this.collision.addCollider({
        minX: BUILDING.FLIGHT_B_MAX_X,
        maxX: BUILDING.FLIGHT_A_MIN_X,
        minY: nextY,
        maxY: nextY + 1.4,
        minZ: BUILDING.LANDING_SOUTH_Z - 0.06,
        maxZ: BUILDING.LANDING_SOUTH_Z + 0.14,
      });
    }

    // Attic top landing overlook railing (Floor 6, X in [-1.05, +1.4], Z = 1.5)
    const f6Y = getFloorBaseY(6);
    this.buildBalustrade(
      BUILDING.FLIGHT_B_MAX_X,
      BUILDING.STAIR_EAST_X,
      f6Y,
      BUILDING.LANDING_SOUTH_Z + 0.04,
      f6Y,
      BUILDING.LANDING_SOUTH_Z + 0.04,
    );
    this.collision.addCollider({
      minX: BUILDING.FLIGHT_B_MAX_X,
      maxX: BUILDING.STAIR_EAST_X,
      minY: f6Y,
      maxY: f6Y + 1.4,
      minZ: BUILDING.LANDING_SOUTH_Z - 0.06,
      maxZ: BUILDING.LANDING_SOUTH_Z + 0.14,
    });

    // Locked Basement Door at Floor 1 stairwell descent (X in [-2.8, -1.05], Z = 1.5)
    this.buildGateDoor({
      id: 'door_basement',
      x: -1.92,
      y: getFloorBaseY(1),
      z: BUILDING.LANDING_SOUTH_Z + 0.05,
      width: 1.65,
      title: 'Дверь в подвал',
      requiredKey: 'key_basement',
      missingMsg: 'Тяжёлая решётчатая дверь в подвал заперта. Нужен ключ от подвала.',
      openMsg: 'Замок поддался. Из подвала тянет сыростью и запахом солярки.',
    });

    // Locked Attic Door at Floor 6 arrival (X in [-2.8, -1.05], Z = 1.5, Y = 16.0)
    this.buildGateDoor({
      id: 'door_attic',
      x: -1.92,
      y: getFloorBaseY(6),
      z: BUILDING.LANDING_SOUTH_Z + 0.05,
      width: 1.65,
      title: 'Дверь на чердак',
      requiredKey: 'key_attic',
      missingMsg: 'Стальная дверь на чердак закрыта на массивный замок. Нужен ключ от чердака.',
      openMsg: 'Дверь на чердак отворена. Над головой скрипят сухие балки.',
    });
  }

  private buildGateDoor(opts: {
    id: string;
    x: number;
    y: number;
    z: number;
    width: number;
    title: string;
    requiredKey: string;
    missingMsg: string;
    openMsg: string;
  }): void {
    const pivot = new THREE.Group();
    pivot.position.set(opts.x - opts.width / 2, opts.y, opts.z);
    this.scene.add(pivot);

    const doorLeaf = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(opts.width, 2.2, 0.07)),
      this.mats.doorSteel,
    );
    doorLeaf.position.set(opts.width / 2, 1.1, 0);
    pivot.add(doorLeaf);
    this.occlusionMeshes.push(doorLeaf);

    const col = this.collision.addCollider({
      minX: opts.x - opts.width / 2,
      maxX: opts.x + opts.width / 2,
      minY: opts.y,
      maxY: opts.y + 2.4,
      minZ: opts.z - 0.14,
      maxZ: opts.z + 0.14,
    });

    const openFn = () => {
      this.unlockedDoors.add(opts.id);
      pivot.rotation.y = -Math.PI * 0.48;
      col.enabled = false;
      this.interaction.updateEntry(opts.id, { enabled: false });
    };
    this.dynamicUnlockers.set(opts.id, openFn);

    this.callbacks.onRegisterDoorBridge({
      id: opts.id,
      pos: new THREE.Vector3(opts.x, opts.y, opts.z),
      isOpen: () => this.unlockedDoors.has(opts.id),
      isLocked: () => !this.unlockedDoors.has(opts.id),
      forceOpen: openFn,
    });

    this.interaction.register({
      id: opts.id,
      mesh: doorLeaf,
      title: opts.title,
      actionText: 'Открыть дверь',
      category: 'door',
      onInteract: () => {
        if (this.unlockedDoors.has(opts.id)) return;
        if (!this.inventory.hasItem(opts.requiredKey)) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(opts.missingMsg);
          return;
        }
        this.sound.playDoorCreak();
        this.callbacks.onNoiseImpulse(pivot.position, 11);
        openFn();
        this.callbacks.onSubtitle(opts.openMsg);
        this.callbacks.onStateChanged();
      },
    });
  }

  private buildStairFlight(
    minX: number,
    maxX: number,
    startZ: number,
    endZ: number,
    startY: number,
    endY: number,
    railX: number,
  ): void {
    const steps = BUILDING.STEPS_PER_FLIGHT;
    const width = maxX - minX;
    const centerX = (minX + maxX) / 2;
    const totalZ = endZ - startZ;
    const totalY = endY - startY;
    const stepDepth = Math.abs(totalZ) / steps;
    const stepRise = totalY / steps;
    const dirZ = Math.sign(totalZ);

    const stepGeo = this.trackGeo(
      new THREE.BoxGeometry(width, stepRise, stepDepth + 0.02),
    );
    const noseGeo = this.trackGeo(new THREE.BoxGeometry(width, 0.025, 0.04));

    for (let s = 0; s < steps; s++) {
      const sy = startY + (s + 0.5) * stepRise;
      const sz = startZ + dirZ * (s + 0.5) * stepDepth;

      const stepMesh = new THREE.Mesh(stepGeo, this.mats.concreteStep);
      stepMesh.position.set(centerX, sy, sz);
      stepMesh.receiveShadow = true;
      this.scene.add(stepMesh);

      const nose = new THREE.Mesh(noseGeo, this.mats.stairNosing);
      nose.position.set(
        centerX,
        sy + stepRise / 2 + 0.004,
        sz - dirZ * (stepDepth / 2 - 0.02),
      );
      this.scene.add(nose);
    }

    const flightLen = Math.hypot(totalZ, totalY);
    const angle = Math.atan2(totalY, Math.abs(totalZ));
    const soffit = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(width, 0.18, flightLen)),
      this.mats.ceilingConcrete,
    );
    soffit.position.set(centerX, (startY + endY) / 2 - 0.14, (startZ + endZ) / 2);
    soffit.rotation.x = dirZ > 0 ? -angle : angle;
    this.scene.add(soffit);

    const zMin = Math.min(startZ, endZ);
    const zMax = Math.max(startZ, endZ);
    this.collision.addWalkSurface({
      minX,
      maxX,
      minZ: zMin,
      maxZ: zMax,
      getY: (_x, z) => {
        const t = THREE.MathUtils.clamp((z - startZ) / totalZ, 0, 1);
        return startY + t * totalY;
      },
    });

    this.buildBalustrade(railX, railX, startY, startZ, endY, endZ);
    this.collision.addCollider({
      minX: railX - 0.08,
      maxX: railX + 0.08,
      minY: Math.min(startY, endY),
      maxY: Math.max(startY, endY) + 1.2,
      minZ: zMin,
      maxZ: zMax,
    });
  }

  private buildBalustrade(
    x1: number,
    x2: number,
    y1: number,
    z1: number,
    y2: number,
    z2: number,
  ): void {
    const railH = 0.94;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dz = z2 - z1;
    const horizLen = Math.hypot(dx, dz);
    const totalLen = Math.hypot(horizLen, dy);
    const posts = Math.max(2, Math.round(horizLen / 0.45) + 1);

    const postGeo = this.trackGeo(new THREE.BoxGeometry(0.032, railH, 0.032));
    for (let i = 0; i < posts; i++) {
      const t = i / (posts - 1);
      const px = x1 + dx * t;
      const py = y1 + dy * t + railH / 2;
      const pz = z1 + dz * t;
      const post = new THREE.Mesh(postGeo, this.mats.railingMetal);
      post.position.set(px, py, pz);
      this.scene.add(post);
    }

    const handrail = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.06, 0.045, totalLen + 0.04)),
      this.mats.handrailWood,
    );
    handrail.position.set((x1 + x2) / 2, (y1 + y2) / 2 + railH, (z1 + z2) / 2);

    const yawAngle = Math.atan2(dx, dz);
    const pitchAngle = -Math.atan2(dy, horizLen);
    handrail.rotation.order = 'YXZ';
    handrail.rotation.y = yawAngle;
    handrail.rotation.x = pitchAngle;
    this.scene.add(handrail);
  }

  private buildBasementAndSwitchboard(): void {
    const y0 = getFloorBaseY(0);

    // Overhead industrial pipes in basement
    for (const pz of [-1.6, -1.1, 0.9]) {
      const pipe = new THREE.Mesh(
        this.trackGeo(new THREE.CylinderGeometry(0.075, 0.075, 9.0, 10)),
        this.mats.pipeMetal,
      );
      pipe.rotation.z = Math.PI / 2;
      pipe.position.set(0.5, y0 + 2.75, pz);
      this.scene.add(pipe);
    }

    // Partition wall dividing Basement West and Switchboard Room (X = +1.8)
    this.addWallBox(1.75, 1.9, y0, y0 + 3.2, -2.1, -0.75, this.mats.wallBasementBrick);
    this.addWallBox(1.75, 1.9, y0, y0 + 3.2, 0.25, 1.5, this.mats.wallBasementBrick);
    this.addWallBox(
      1.75,
      1.9,
      y0 + 2.15,
      y0 + 3.2,
      -0.75,
      0.25,
      this.mats.wallBasementBrick,
      false,
    );

    const signPlate = new THREE.Mesh(
      this.trackGeo(new THREE.PlaneGeometry(0.7, 0.22)),
      this.mats.createStencilPlateMaterial('ЩИТОВАЯ', '#2b1815', '#eab308', 192, 64),
    );
    signPlate.rotation.y = -Math.PI / 2;
    signPlate.position.set(1.74, y0 + 2.35, -0.25);
    this.scene.add(signPlate);

    // Composite Diesel Generator (7-part assembly) at X = +3.7, Z = -0.3
    const genGroup = new THREE.Group();
    genGroup.position.set(3.7, y0, -0.3);
    this.scene.add(genGroup);

    const baseSkid = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.5, 0.16, 0.95)),
      this.mats.trimDark,
    );
    baseSkid.position.set(0, 0.08, 0);
    genGroup.add(baseSkid);

    const engineBlock = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.15, 0.78, 0.72)),
      this.mats.generatorMetal,
    );
    engineBlock.position.set(0.05, 0.55, 0);
    genGroup.add(engineBlock);

    const tank = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.22, 0.22, 0.76, 12)),
      this.mats.doorSteel,
    );
    tank.rotation.z = Math.PI / 2;
    tank.position.set(-0.1, 1.08, 0);
    genGroup.add(tank);

    const exhaust = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.05, 0.05, 1.6, 8)),
      this.mats.pipeMetal,
    );
    exhaust.position.set(0.55, 1.5, -0.25);
    genGroup.add(exhaust);

    const controlBox = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.18, 0.52, 0.54)),
      this.mats.fuseBoxMetal,
    );
    controlBox.position.set(-0.62, 0.72, 0);
    genGroup.add(controlBox);

    this.generatorLedMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x111111,
        emissive: 0xef4444,
        emissiveIntensity: 1.3,
      }),
    );
    const statusLed = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.04, 0.08, 0.08)),
      this.generatorLedMat,
    );
    statusLed.position.set(-0.72, 0.88, 0);
    genGroup.add(statusLed);

    this.collision.addCollider({
      minX: 2.9,
      maxX: 4.5,
      minY: y0,
      maxY: y0 + 1.5,
      minZ: -0.85,
      maxZ: 0.25,
    });

    this.interaction.register({
      id: 'basement_generator',
      mesh: genGroup,
      title: 'Дизель-генератор',
      actionText: 'Обслужить генератор',
      category: 'generator',
      maxDistance: 2.5,
      onInteract: () => this.handleGeneratorInteract(),
    });
  }

  private handleGeneratorInteract(): void {
    if (this.generatorRunning) {
      this.sound.playBreakerFlip();
      this.callbacks.onSubtitle(
        'Генератор работает на полной мощности — питание здания восстановлено.',
      );
      return;
    }

    if (!this.generatorFuelAdded && this.inventory.hasItem('fuel')) {
      this.inventory.consumeItem('fuel', 1);
      this.generatorFuelAdded = true;
      this.sound.playBreakerFlip();
      this.callbacks.onSubtitle('Вы залили дизельное топливо в бак генератора.');
      this.callbacks.onStateChanged();
      return;
    }

    if (this.generatorFusesInserted < 3 && this.inventory.hasItem('fuse')) {
      const needed = 3 - this.generatorFusesInserted;
      const available = this.inventory.getCount('fuse');
      const toInsert = Math.min(needed, available);
      this.inventory.consumeItem('fuse', toInsert);
      this.generatorFusesInserted += toInsert;
      this.sound.playBreakerFlip();
      this.callbacks.onSubtitle(
        `Установлено предохранителей: ${this.generatorFusesInserted} / 3.`,
      );
      this.callbacks.onStateChanged();
      return;
    }

    if (this.generatorFuelAdded && this.generatorFusesInserted >= 3) {
      this.activateGenerator();
      return;
    }

    const missing: string[] = [];
    if (!this.generatorFuelAdded) missing.push('канистра топлива');
    if (this.generatorFusesInserted < 3) {
      missing.push(`предохранители (${this.generatorFusesInserted}/3)`);
    }
    this.sound.playDoorLocked();
    this.callbacks.onSubtitle(`Генератор не готов. Требуется: ${missing.join(', ')}.`);
  }

  private activateGenerator(silent = false): void {
    this.generatorRunning = true;
    this.generatorLedMat.emissive.setHex(0x22c55e);

    // Restore all residential & basement/attic lights
    for (let f = 0; f <= 6; f++) {
      this.restoredFloors.add(f);
    }
    for (const rig of this.floorLights) {
      rig.powered = true;
      rig.light.intensity = rig.baseIntensity;
      rig.tubeMat.emissiveIntensity = 1.1;
    }

    if (!silent) {
      this.sound.playGeneratorStart();
      this.callbacks.onNoiseImpulse(
        new THREE.Vector3(3.7, getFloorBaseY(0), -0.3),
        18,
      );
      this.callbacks.onGeneratorStarted();
    }
    this.callbacks.onStateChanged();
  }

  private buildFloor1EntranceAndMailboxes(): void {
    const y = getFloorBaseY(1);

    const exitGroup = new THREE.Group();
    exitGroup.position.set(BUILDING.WEST_X + 0.04, y, -0.35);
    this.scene.add(exitGroup);

    const frame = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.1, 2.25, 1.15)),
      this.mats.trimDark,
    );
    frame.position.set(0, 1.125, 0);
    exitGroup.add(frame);

    const doorLeaf = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.08, 2.15, 1.02)),
      this.mats.doorSteel,
    );
    doorLeaf.position.set(0.02, 1.075, 0);
    exitGroup.add(doorLeaf);

    const pushBar = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.06, 0.06, 0.68)),
      this.mats.brassAccent,
    );
    pushBar.position.set(0.08, 1.02, 0);
    exitGroup.add(pushBar);

    this.interaction.register({
      id: 'exit_door',
      mesh: doorLeaf,
      title: 'Выход из подъезда',
      actionText: 'Открыть выход',
      category: 'door',
      onInteract: () => {
        if (!this.generatorRunning) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(
            'Магнитный замок заблокирован. Запустите главный генератор в подвале.',
          );
          return;
        }
        this.sound.playDoorCreak();
        if (this.atticTransmitterActive && this.secretPanelOpen) {
          this.callbacks.onTriggerEnding('true');
        } else if (this.inventory.hasItem('tape_4')) {
          this.callbacks.onTriggerEnding('secret');
        } else {
          this.callbacks.onTriggerEnding('good');
        }
      },
    });

    const intercomBox = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.06, 0.28, 0.18)),
      this.mats.doorSteel,
    );
    intercomBox.position.set(BUILDING.WEST_X + 0.04, 1.32, 0.42);
    this.scene.add(intercomBox);

    this.interaction.register({
      id: 'intercom_exit',
      mesh: intercomBox,
      title: 'Домофон',
      actionText: 'Проверить панель',
      category: 'intercom',
      onInteract: () => {
        this.sound.playDoorLocked();
        this.callbacks.onSubtitle(
          this.generatorRunning
            ? 'Питание подано — магнитный замок разблокирован!'
            : 'Домофон мёртв. Нужно электричество от подвального генератора.',
        );
      },
    });

    // Mailbox bank
    const mbGroup = new THREE.Group();
    mbGroup.position.set(BUILDING.WEST_X + 0.14, 1.32, 0.96);
    this.scene.add(mbGroup);

    const mbBody = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.24, 0.92, 0.72)),
      this.mats.mailboxMetal,
    );
    mbGroup.add(mbBody);

    for (let i = 0; i < 4; i++) {
      const slot = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.02, 0.16, 0.62)),
        this.mats.trimDark,
      );
      slot.position.set(0.125, -0.3 + i * 0.2, 0);
      mbGroup.add(slot);
    }

    this.interaction.register({
      id: 'mailbox_bank',
      mesh: mbBody,
      title: 'Почтовые ящики (кв. 5–8)',
      actionText: 'Осмотреть ящик №7',
      category: 'mailbox',
      onInteract: () => {
        this.sound.playPaperPickup();
        if (!this.pickedUpItems.has('mailbox_key_apt7')) {
          if (this.inventory.addItem('key_apt7')) {
            this.pickedUpItems.add('mailbox_key_apt7');
            this.callbacks.onStateChanged();
          }
        }
        this.callbacks.onOpenNote(STORY_NOTES.note_mailbox_7);
      },
    });
  }

  private buildResidentialFloorsAndPeepholes(): void {
    const totalH = BUILDING.FLOOR_COUNT * BUILDING.FLOOR_HEIGHT;
    const chuteCol = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.22, 0.22, totalH, 12)),
      this.mats.pipeMetal,
    );
    chuteCol.position.set(1.15, totalH / 2, BUILDING.NORTH_Z + 0.22);
    this.scene.add(chuteCol);
    this.collision.addCollider({
      minX: 0.9,
      maxX: 1.4,
      minY: 0,
      maxY: totalH,
      minZ: BUILDING.NORTH_Z,
      maxZ: BUILDING.NORTH_Z + 0.48,
    });

    let aptNum = 1;
    for (let f = 1; f <= 5; f++) {
      const y = getFloorBaseY(f);
      this.buildFuseBox(f, -0.65, y, BUILDING.NORTH_Z + 0.08);

      const hopper = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.38, 0.42, 0.18)),
        this.mats.doorSteel,
      );
      hopper.position.set(1.15, y + 1.05, BUILDING.NORTH_Z + 0.42);
      this.scene.add(hopper);

      this.interaction.register({
        id: `trash_chute_${f}`,
        mesh: hopper,
        title: `Мусоропровод (${f} этаж)`,
        actionText: 'Приоткрыть ковш',
        category: 'chute',
        onInteract: () => {
          this.sound.playDoorCreak();
          this.callbacks.onNoiseImpulse(hopper.position, 9);
          this.sound.playWhisper(0.15, 0.65);
          this.callbacks.onSubtitle('Из мусоропровода тянет ледяным шёпотом...');
        },
      });

      // North Door (3, 7, 10, 13 -> let's number clearly: F1: 1,2,3; F2: 4,5,6; F3: 7,8,9; F4: 10,11,12; F5: 13,14,15)
      const nApt = aptNum++;
      const eApt = aptNum++;
      const sApt = aptNum++;

      this.buildApartmentDoor(nApt, f, 3.3, y, BUILDING.NORTH_Z + 0.05, 0);
      this.buildApartmentDoor(eApt, f, BUILDING.EAST_X - 0.05, y, -0.3, -Math.PI / 2);
      this.buildApartmentDoor(
        sApt,
        f,
        3.3,
        y,
        BUILDING.LANDING_SOUTH_Z - 0.05,
        Math.PI,
      );
    }
  }

  private buildFuseBox(floor: number, x: number, y: number, z: number): void {
    const group = new THREE.Group();
    group.position.set(x, y + 1.48, z);
    this.scene.add(group);

    const cabinet = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.56, 0.72, 0.14)),
      this.mats.fuseBoxMetal,
    );
    group.add(cabinet);

    const doorPivot = new THREE.Group();
    doorPivot.position.set(-0.26, 0, 0.075);
    group.add(doorPivot);

    const doorPanel = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.52, 0.68, 0.025)),
      this.mats.doorSteel,
    );
    doorPanel.position.set(0.26, 0, 0);
    doorPivot.add(doorPanel);

    const isPowered = this.restoredFloors.has(floor);
    const ledMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x111111,
        emissive: isPowered ? 0x22c55e : 0xef4444,
        emissiveIntensity: 1.4,
      }),
    );
    const indicator = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.06, 0.06, 0.03)),
      ledMat,
    );
    indicator.position.set(0.14, 0.18, 0.06);
    group.add(indicator);

    let isOpen = false;
    this.interaction.register({
      id: `fusebox_${floor}`,
      mesh: cabinet,
      title: `Электрощиток (${floor} этаж)`,
      actionText: isPowered ? 'Открыть щиток' : 'Включить автомат',
      category: 'fusebox',
      onInteract: () => {
        if (!isOpen) {
          isOpen = true;
          doorPivot.rotation.y = -Math.PI * 0.62;
          this.sound.playDoorCreak();
        }
        const rig = this.floorLights.find((l) => l.floor === floor);
        if (!this.restoredFloors.has(floor)) {
          this.restoredFloors.add(floor);
          this.sound.playBreakerFlip();
          ledMat.emissive.setHex(0x22c55e);
          if (rig) {
            rig.powered = true;
            rig.light.intensity = rig.baseIntensity;
            rig.tubeMat.emissiveIntensity = 1.1;
          }
          this.callbacks.onSubtitle(`Свет на ${floor} этаже восстановлен.`);
          this.callbacks.onStateChanged();
        } else {
          this.sound.playBreakerFlip();
          this.callbacks.onSubtitle(`Щиток ${floor} этажа включён.`);
        }
      },
    });
  }

  private buildApartmentDoor(
    aptNumber: number,
    floor: number,
    x: number,
    y: number,
    z: number,
    rotY: number,
  ): void {
    const group = new THREE.Group();
    group.position.set(x, y, z);
    group.rotation.y = rotY;
    this.scene.add(group);

    const frame = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.06, 2.16, 0.1)),
      this.mats.trimDark,
    );
    frame.position.set(0, 1.08, 0);
    group.add(frame);

    const pivot = new THREE.Group();
    pivot.position.set(-0.46, 0, 0.02);
    group.add(pivot);

    const isSteel = aptNumber % 3 === 0;
    const leaf = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.92, 2.06, 0.06)),
      isSteel ? this.mats.doorSteel : this.mats.doorWood,
    );
    leaf.position.set(0.46, 1.03, 0);
    leaf.receiveShadow = true;
    pivot.add(leaf);
    this.occlusionMeshes.push(leaf);

    const handle = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.14, 0.035, 0.08)),
      this.mats.brassAccent,
    );
    handle.position.set(0.82, 1.0, 0.05);
    pivot.add(handle);

    const peephole = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.018, 0.018, 0.08, 8)),
      this.mats.brassAccent,
    );
    peephole.rotation.x = Math.PI / 2;
    peephole.position.set(0.46, 1.52, 0.01);
    pivot.add(peephole);

    const plate = new THREE.Mesh(
      this.trackGeo(new THREE.PlaneGeometry(0.16, 0.1)),
      this.mats.createStencilPlateMaterial(
        String(aptNumber),
        '#26221e',
        '#d6c7a9',
        96,
        64,
      ),
    );
    plate.position.set(0.46, 1.72, 0.035);
    pivot.add(plate);

    const isEnterable =
      aptNumber === 2 ||
      aptNumber === 4 ||
      aptNumber === 5 ||
      aptNumber === 7 ||
      aptNumber === 10 ||
      aptNumber === 11 ||
      aptNumber === 13 ||
      aptNumber === 14;
    const needsKey =
      aptNumber === 7 ||
      aptNumber === 10 ||
      (aptNumber === 11 && !this.callbacks.nightSeed.openApt11);

    let doorCollider: BoxCollider | null = null;
    if (isEnterable) {
      const isEastDoor = Math.abs(Math.sin(rotY)) > 0.7;
      doorCollider = this.collision.addCollider(
        isEastDoor
          ? {
              minX: x - 0.18,
              maxX: x + 0.18,
              minY: y,
              maxY: y + 2.3,
              minZ: z - 0.48,
              maxZ: z + 0.48,
            }
          : {
              minX: x - 0.48,
              maxX: x + 0.48,
              minY: y,
              maxY: y + 2.3,
              minZ: z - 0.18,
              maxZ: z + 0.18,
            },
      );
    }

    const doorId = `apt_door_${aptNumber}`;
    if (!this.floorDoorIds.has(floor)) this.floorDoorIds.set(floor, []);
    this.floorDoorIds.get(floor)!.push(doorId);

    let isOpen = false;
    const setDoorOpen = (open: boolean) => {
      isOpen = open;
      pivot.rotation.y = open ? -Math.PI * 0.48 : 0;
      if (doorCollider) doorCollider.enabled = !open;
      if (isEnterable) {
        this.interaction.updateEntry(doorId, {
          actionText: open ? 'Закрыть дверь' : 'Открыть дверь',
        });
      }
    };

    if (needsKey) {
      this.dynamicUnlockers.set(doorId, () => {
        this.unlockedDoors.add(doorId);
        setDoorOpen(true);
      });
    }

    if (isEnterable) {
      this.callbacks.onRegisterDoorBridge({
        id: doorId,
        pos: new THREE.Vector3(x, y, z),
        isOpen: () => isOpen,
        isLocked: () => needsKey && !this.unlockedDoors.has(doorId),
        forceOpen: () => {
          if (!needsKey || this.unlockedDoors.has(doorId)) {
            setDoorOpen(true);
          }
        },
      });
    }

    // Creak action for random events
    this.doorActions.set(doorId, () => {
      pivot.rotation.y = -0.18;
      this.sound.playDoorCreak();
    });

    // Peephole look direction: points straight through the door!
    const peepholeOffset = new THREE.Vector3(0, 1.52, -0.06).applyAxisAngle(
      new THREE.Vector3(0, 1, 0),
      rotY,
    );
    const peepholeCamPos = new THREE.Vector3(x, y, z).add(peepholeOffset);

    this.interaction.register({
      id: doorId,
      mesh: leaf,
      title: `Квартира №${aptNumber} (${floor} этаж)`,
      actionText: isEnterable ? 'Открыть дверь' : 'Постучать в дверь',
      secondaryActionText: 'Посмотреть в глазок',
      category: 'door',
      onInteract: () => {
        if (aptNumber === 7 && !this.unlockedDoors.has(doorId)) {
          if (!this.inventory.hasItem('key_apt7')) {
            this.sound.playDoorLocked();
            this.callbacks.onSubtitle(
              'Квартира №7 заперта. Ключ может быть в почтовом ящике №7.',
            );
            return;
          }
          this.unlockedDoors.add(doorId);
          setDoorOpen(true);
          this.sound.playDoorCreak();
          this.callbacks.onNoiseImpulse(leaf.getWorldPosition(new THREE.Vector3()), 12);
          this.callbacks.onSubtitle('Латунный ключ открыл квартиру №7.');
          this.callbacks.onStateChanged();
          return;
        }

        if (aptNumber === 10 && !this.unlockedDoors.has(doorId)) {
          if (!this.inventory.hasItem('key_apt10')) {
            this.sound.playDoorLocked();
            this.callbacks.onSubtitle(
              'Заброшенная квартира №10 заперта. Ищите ключ в технической нише 3 этажа.',
            );
            return;
          }
          this.unlockedDoors.add(doorId);
          setDoorOpen(true);
          this.sound.playDoorCreak();
          this.callbacks.onNoiseImpulse(leaf.getWorldPosition(new THREE.Vector3()), 12);
          this.callbacks.onSubtitle('Дверь в заброшенную квартиру №10 открылась.');
          this.callbacks.onStateChanged();
          return;
        }

        if (
          aptNumber === 11 &&
          !this.callbacks.nightSeed.openApt11 &&
          !this.unlockedDoors.has(doorId)
        ) {
          if (!this.inventory.hasItem('screwdriver')) {
            this.sound.playDoorLocked();
            this.callbacks.onSubtitle(
              'Дверь в секретную кв. №11 заклинило. Можно поддеть замок отвёрткой (ищите на 2 этаже).',
            );
            return;
          }
          this.unlockedDoors.add(doorId);
          setDoorOpen(true);
          this.sound.playDoorCreak();
          this.callbacks.onNoiseImpulse(leaf.getWorldPosition(new THREE.Vector3()), 11);
          this.callbacks.onSecretFound();
          this.callbacks.onSubtitle('Вы поддели засов — открылась секретная квартира №11!');
          this.callbacks.onStateChanged();
          return;
        }

        if (isEnterable) {
          setDoorOpen(!isOpen);
          if (aptNumber === 11 && !isOpen) {
            this.callbacks.onSecretFound();
          }
          this.sound.playDoorCreak();
          this.callbacks.onNoiseImpulse(leaf.getWorldPosition(new THREE.Vector3()), 9);
          return;
        }

        this.sound.playDoorKnock(0);
        this.callbacks.onNoiseImpulse(new THREE.Vector3(x, y, z), 9);
        if (aptNumber === 8 || aptNumber === 12) {
          this.sound.playWhisper(0.3, 0.55);
          this.callbacks.onSubtitle(
            `За дверью кв. ${aptNumber} на мгновение послышался тихий вздох...`,
          );
        } else {
          this.callbacks.onSubtitle(`В квартире №${aptNumber} тишина.`);
        }
      },
      onSecondaryInteract: () => {
        this.callbacks.onEnterPeephole({
          label: `Глазок · Квартира №${aptNumber}`,
          camPos: peepholeCamPos,
          lookYaw: rotY,
          lookPitch: 0,
        });
      },
    });

    if (aptNumber === 5 && this.callbacks.nightSeed.openApt5) {
      setDoorOpen(true);
    }
  }

  private buildInteriorDoor(opts: {
    id: string;
    title: string;
    x: number;
    y: number;
    z: number;
    rotY: number;
  }): void {
    const group = new THREE.Group();
    group.position.set(opts.x, opts.y, opts.z);
    group.rotation.y = opts.rotY;
    this.scene.add(group);

    const frame = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.0, 2.12, 0.08)),
      this.mats.trimDark,
    );
    frame.position.set(0, 1.06, 0);
    group.add(frame);

    const pivot = new THREE.Group();
    pivot.position.set(-0.44, 0, 0);
    group.add(pivot);

    const leaf = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.88, 2.04, 0.05)),
      this.mats.doorWood,
    );
    leaf.position.set(0.44, 1.02, 0);
    leaf.receiveShadow = true;
    pivot.add(leaf);
    this.occlusionMeshes.push(leaf);

    const handle = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.12, 0.03, 0.08)),
      this.mats.brassAccent,
    );
    handle.position.set(0.76, 0.98, 0.04);
    pivot.add(handle);

    const isEastAligned = Math.abs(Math.sin(opts.rotY)) > 0.7;
    const col = this.collision.addCollider(
      isEastAligned
        ? {
            minX: opts.x - 0.14,
            maxX: opts.x + 0.14,
            minY: opts.y,
            maxY: opts.y + 2.2,
            minZ: opts.z - 0.45,
            maxZ: opts.z + 0.45,
          }
        : {
            minX: opts.x - 0.45,
            maxX: opts.x + 0.45,
            minY: opts.y,
            maxY: opts.y + 2.2,
            minZ: opts.z - 0.14,
            maxZ: opts.z + 0.14,
          },
    );

    let isOpen = false;
    const setOpen = (open: boolean) => {
      isOpen = open;
      pivot.rotation.y = open ? -Math.PI * 0.48 : 0;
      col.enabled = !open;
      this.interaction.updateEntry(opts.id, {
        actionText: open ? 'Закрыть дверь' : 'Открыть дверь',
      });
    };

    this.callbacks.onRegisterDoorBridge({
      id: opts.id,
      pos: new THREE.Vector3(opts.x, opts.y, opts.z),
      isOpen: () => isOpen,
      isLocked: () => false,
      forceOpen: () => setOpen(true),
    });

    this.interaction.register({
      id: opts.id,
      mesh: leaf,
      title: opts.title,
      actionText: 'Открыть дверь',
      category: 'door',
      onInteract: () => {
        setOpen(!isOpen);
        this.sound.playDoorCreak();
        this.callbacks.onNoiseImpulse(new THREE.Vector3(opts.x, opts.y, opts.z), 8);
      },
    });
  }

  private buildFloor3VentAndSecretNiche(): void {
    const y3 = getFloorBaseY(3);

    // Room behind Floor 3 East Wall: X in [5.2, 7.6], Z in [-0.4, +1.1]
    this.addWallBox(5.2, 7.6, y3, y3 + 3.0, -0.45, -0.35, this.mats.wallBasementBrick);
    this.addWallBox(5.2, 7.6, y3, y3 + 3.0, 1.05, 1.15, this.mats.wallBasementBrick);
    this.addWallBox(7.55, 7.65, y3, y3 + 3.0, -0.45, 1.15, this.mats.wallBasementBrick);

    const floorMesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(2.5, 0.2, 1.6)),
      this.mats.concreteStep,
    );
    floorMesh.position.set(6.4, y3 - 0.1, 0.35);
    this.scene.add(floorMesh);

    const ceilMesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(2.5, 0.2, 1.6)),
      this.mats.ceilingConcrete,
    );
    ceilMesh.position.set(6.4, y3 + 2.9, 0.35);
    this.scene.add(ceilMesh);

    this.collision.addWalkSurface({
      minX: 5.1,
      maxX: 7.55,
      minZ: -0.35,
      maxZ: 1.05,
      getY: () => y3,
    });

    // Ventilation grate blocking entrance at X = 5.25, Z in [-0.2, 0.9]
    const ventGroup = new THREE.Group();
    ventGroup.position.set(5.25, y3 + 1.0, 0.35);
    this.scene.add(ventGroup);

    const grate = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.06, 1.9, 1.05)),
      this.mats.railingMetal,
    );
    ventGroup.add(grate);

    const ventCollider = this.collision.addCollider({
      minX: 5.1,
      maxX: 5.4,
      minY: y3,
      maxY: y3 + 2.5,
      minZ: -0.25,
      maxZ: 0.95,
    });

    const openVentFn = () => {
      this.ventGrateOpen = true;
      ventGroup.visible = false;
      ventCollider.enabled = false;
      this.interaction.updateEntry('floor3_vent_grate', { enabled: false });
    };
    this.dynamicUnlockers.set('floor3_vent_grate', openVentFn);

    this.interaction.register({
      id: 'floor3_vent_grate',
      mesh: grate,
      title: 'Вентиляционная решётка',
      actionText: 'Открутить решётку',
      category: 'secret',
      onInteract: () => {
        if (this.ventGrateOpen) return;
        if (!this.inventory.hasItem('screwdriver')) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(
            'Решётка прикручена винтами. Нужна отвёртка (ищите на 2 этаже).',
          );
          return;
        }
        this.sound.playBreakerFlip();
        this.callbacks.onNoiseImpulse(ventGroup.position, 12);
        openVentFn();
        this.callbacks.onSecretFound();
        this.callbacks.onSubtitle(
          'Вы сняли решётку — открылся проход в техническую нишу!',
        );
        this.callbacks.onStateChanged();
      },
    });
  }

  private buildFloor4Apt10AndSecretRoom(): void {
    const y4 = getFloorBaseY(4);

    // Abandoned Apartment 10: X in [1.6, 5.2], Z in [-6.8, -2.1]
    this.addWallBox(1.5, 1.65, y4, y4 + 3.2, -9.6, -2.1, this.mats.wallApartmentPaper);
    this.addWallBox(5.15, 5.3, y4, y4 + 3.2, -9.6, -2.1, this.mats.wallApartmentPaper);

    // Partition wall at Z = -6.8 with secret doorway cutout at X in [2.8, 3.8]
    this.addWallBox(1.6, 2.8, y4, y4 + 3.2, -6.9, -6.75, this.mats.wallApartmentPaper);
    this.addWallBox(3.8, 5.2, y4, y4 + 3.2, -6.9, -6.75, this.mats.wallApartmentPaper);
    this.addWallBox(
      2.8,
      3.8,
      y4 + 2.1,
      y4 + 3.2,
      -6.9,
      -6.75,
      this.mats.wallApartmentPaper,
      false,
    );

    // Secret Room back wall at Z = -9.6
    this.addWallBox(1.5, 5.3, y4, y4 + 3.2, -9.75, -9.6, this.mats.wallBasementBrick);

    const floorMesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(3.7, 0.2, 7.6)),
      this.mats.wallAtticPlanks,
    );
    floorMesh.position.set(3.4, y4 - 0.1, -5.85);
    floorMesh.receiveShadow = true;
    this.scene.add(floorMesh);

    const ceilMesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(3.7, 0.2, 7.6)),
      this.mats.ceilingConcrete,
    );
    ceilMesh.position.set(3.4, y4 + 3.1, -5.85);
    this.scene.add(ceilMesh);

    this.collision.addWalkSurface({
      minX: 1.65,
      maxX: 5.15,
      minZ: -9.55,
      maxZ: -2.0,
      surfaceKind: 'wood',
      getY: () => y4,
    });

    this.callbacks.onLinkNavEdge(
      'f4_east',
      'f4_apt10',
      new THREE.Vector3(3.3, y4, -4.4),
      4,
      'apt_door_10',
    );

    // Subtle flickering tungsten lamp in Apt 10
    const apt10LampMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xd6cdb8,
        emissive: 0xe6a85c,
        emissiveIntensity: 0.7,
        roughness: 0.35,
      }),
    );
    const apt10Light = new THREE.PointLight(0xe6a85c, 0.72, 7.5, 1.85);
    apt10Light.position.set(3.4, y4 + 2.65, -4.5);
    this.scene.add(apt10Light);
    this.floorLights.push({
      floor: 4,
      light: apt10Light,
      tubeMat: apt10LampMat,
      powered: true,
      baseIntensity: 0.72,
      isApartment: true,
      flickerPhase: 4.2,
    });

    // Dusty Table in Apt 10
    const table = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.1, 0.78, 0.75)),
      this.mats.furnitureWood,
    );
    table.position.set(4.3, y4 + 0.39, -3.4);
    this.scene.add(table);
    this.collision.addCollider({
      minX: 3.7,
      maxX: 4.9,
      minY: y4,
      maxY: y4 + 1.0,
      minZ: -3.85,
      maxZ: -2.95,
    });

    // Secret Movable Bookshelf / False Wall at X = 3.3, Z = -6.72
    const secretPanel = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.1, 2.15, 0.18)),
      this.mats.furnitureWood,
    );
    secretPanel.position.set(3.3, y4 + 1.08, -6.72);
    this.scene.add(secretPanel);

    const secretCollider = this.collision.addCollider({
      minX: 2.75,
      maxX: 3.85,
      minY: y4,
      maxY: y4 + 2.3,
      minZ: -6.9,
      maxZ: -6.6,
    });

    const openSecretFn = () => {
      this.secretPanelOpen = true;
      secretPanel.position.x = 2.1;
      secretCollider.enabled = false;
      this.interaction.updateEntry('apt10_secret_panel', { enabled: false });
    };
    this.dynamicUnlockers.set('apt10_secret_panel', openSecretFn);

    this.interaction.register({
      id: 'apt10_secret_panel',
      mesh: secretPanel,
      title: 'Подозрительная фальшстена',
      actionText: 'Поддеть механизм',
      category: 'secret',
      onInteract: () => {
        if (this.secretPanelOpen) return;
        if (!this.inventory.hasItem('screwdriver')) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle('Панель держится на потайном фиксаторе. Нужна отвёртка.');
          return;
        }
        this.sound.playDoorCreak();
        this.callbacks.onNoiseImpulse(secretPanel.position, 14);
        openSecretFn();
        this.callbacks.onSecretFound();
        this.callbacks.onSecretRoomDiscovered();
        this.callbacks.onStateChanged();
      },
    });

    // Secret Room Watcher Audio Terminal (triggers Secret Ending!)
    const desk = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(1.2, 0.85, 0.6)),
      this.mats.doorSteel,
    );
    desk.position.set(3.4, y4 + 0.425, -9.1);
    this.scene.add(desk);

    const recorder = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.45, 0.2, 0.35)),
      this.mats.trimDark,
    );
    recorder.position.set(3.4, y4 + 0.95, -9.1);
    this.scene.add(recorder);

    const secretBlueLight = new THREE.PointLight(0x38bdf8, 0.85, 5.5, 1.8);
    secretBlueLight.position.set(3.4, y4 + 2.4, -8.3);
    this.scene.add(secretBlueLight);

    this.interaction.register({
      id: 'secret_room_terminal',
      mesh: recorder,
      title: 'Терминал наблюдения №0',
      actionText: 'Замкнуть контур кассетой',
      category: 'radio',
      onInteract: () => {
        if (!this.generatorRunning) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(
            'Терминал обесточен. Сначала запустите генератор в подвале.',
          );
          return;
        }
        if (!this.inventory.hasItem('tape_4')) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle('Возьмите магнитную кассету №4 рядом со столом.');
          return;
        }
        this.sound.playWhisper(0, 0.9);
        this.callbacks.onTriggerEnding('secret');
      },
    });
  }

  private buildAtticAndTransmitter(): void {
    const y6 = getFloorBaseY(6);

    // Attic wooden ceiling rafters
    for (let x = -3.4; x <= 4.4; x += 1.9) {
      const beam = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.18, 0.24, 3.6)),
        this.mats.handrailWood,
      );
      beam.position.set(x, y6 + 2.95, -0.3);
      this.scene.add(beam);
    }

    // Attic Radio Transmitter for True Ending
    const radioRack = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.85, 1.65, 0.55)),
      this.mats.doorSteel,
    );
    radioRack.position.set(4.1, y6 + 0.825, -0.3);
    this.scene.add(radioRack);

    const radioLedMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x111111,
        emissive: 0xdc2626,
        emissiveIntensity: 1.4,
      }),
    );
    const radioLed = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.1, 0.1, 0.05)),
      radioLedMat,
    );
    radioLed.position.set(3.66, y6 + 1.32, -0.3);
    this.scene.add(radioLed);

    this.collision.addCollider({
      minX: 3.6,
      maxX: 4.6,
      minY: y6,
      maxY: y6 + 1.9,
      minZ: -0.65,
      maxZ: 0.05,
    });

    const activateTx = () => {
      this.atticTransmitterActive = true;
      radioLedMat.emissive.setHex(0x22c55e);
    };
    this.dynamicUnlockers.set('attic_transmitter', activateTx);

    this.interaction.register({
      id: 'attic_transmitter',
      mesh: radioRack,
      title: 'Антенный передатчик дома',
      actionText: 'Заглушить сигнал',
      category: 'radio',
      onInteract: () => {
        if (this.atticTransmitterActive) {
          this.callbacks.onSubtitle('Передатчик заглушён. Спускайтесь к выходу на 1 этаж.');
          return;
        }
        if (!this.generatorRunning) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(
            'Блок не реагирует без питания от подвального генератора.',
          );
          return;
        }
        if (!this.inventory.hasItem('tape_4')) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(
            'Для сброса частоты нужна магнитная кассета №4 из секретной комнаты кв. 10.',
          );
          return;
        }
        this.inventory.consumeItem('tape_4', 1);
        activateTx();
        this.sound.playBreakerFlip();
        this.callbacks.onStoryRevelation();
        this.callbacks.onStateChanged();
      },
    });
  }

  private buildHidingSpots(): void {
    // 1. Basement Pipe Alcove (Floor 0)
    this.registerHidingSpot({
      id: 'hide_basement_pipes',
      name: 'Ниша за трубами',
      pos: new THREE.Vector3(-3.6, getFloorBaseY(0), 0.85),
      size: new THREE.Vector3(0.85, 1.9, 0.85),
      camOffset: new THREE.Vector3(0.05, 1.15, -0.05),
      lookYaw: -Math.PI * 0.65,
      returnOffset: new THREE.Vector3(0.95, 0, 0),
      meshMat: this.mats.pipeMetal,
    });

    // 2. Floor 2 Corridor Wardrobe/Cabinet
    this.registerHidingSpot({
      id: 'hide_f2_cabinet',
      name: 'Шкаф на 2 этаже',
      pos: new THREE.Vector3(4.65, getFloorBaseY(2), 0.95),
      size: new THREE.Vector3(0.75, 2.05, 0.85),
      camOffset: new THREE.Vector3(-0.08, 1.42, 0),
      lookYaw: Math.PI * 0.5,
      returnOffset: new THREE.Vector3(-0.95, 0, -0.1),
      meshMat: this.mats.furnitureWood,
    });

    // 3. Floor 4 Apt 10 Wardrobe
    this.registerHidingSpot({
      id: 'hide_apt10_wardrobe',
      name: 'Шкаф в кв. 10',
      pos: new THREE.Vector3(2.05, getFloorBaseY(4), -4.1),
      size: new THREE.Vector3(0.7, 2.1, 1.1),
      camOffset: new THREE.Vector3(0.08, 1.44, 0),
      lookYaw: -Math.PI * 0.5,
      returnOffset: new THREE.Vector3(0.95, 0, 0),
      meshMat: this.mats.furnitureWood,
    });

    // 4. Floor 4 Apt 10 Bed (Hide Underneath!)
    this.registerHidingSpot({
      id: 'hide_apt10_bed',
      name: 'Под кроватью в кв. 10',
      pos: new THREE.Vector3(4.45, getFloorBaseY(4), -5.45),
      size: new THREE.Vector3(1.15, 0.62, 1.85),
      camOffset: new THREE.Vector3(-0.2, 0.34, 0.1),
      lookYaw: Math.PI * 0.55,
      returnOffset: new THREE.Vector3(-1.1, 0, 0),
      meshMat: this.mats.fabricDark,
    });

    // 5. Floor 4 Apt 10 Sofa (Hide Behind!)
    this.registerHidingSpot({
      id: 'hide_apt10_sofa',
      name: 'За диваном в кв. 10',
      pos: new THREE.Vector3(2.15, getFloorBaseY(4), -5.8),
      size: new THREE.Vector3(0.85, 0.95, 1.65),
      camOffset: new THREE.Vector3(0.15, 0.72, 0),
      lookYaw: -Math.PI * 0.45,
      returnOffset: new THREE.Vector3(1.0, 0, 0),
      meshMat: this.mats.fabricDark,
    });

    // 6. Attic Rafter Niche (Floor 6)
    this.registerHidingSpot({
      id: 'hide_attic_nook',
      name: 'Ниша за балками чердака',
      pos: new THREE.Vector3(-3.6, getFloorBaseY(6), 0.95),
      size: new THREE.Vector3(0.85, 1.75, 0.85),
      camOffset: new THREE.Vector3(0.05, 1.05, -0.05),
      lookYaw: -Math.PI * 0.7,
      returnOffset: new THREE.Vector3(0.95, 0, 0),
      meshMat: this.mats.wallAtticPlanks,
    });

    // 7. Basement Switchboard Steel Locker (Floor 0)
    this.registerHidingSpot({
      id: 'hide_basement_locker',
      name: 'Шкаф в электрощитовой',
      pos: new THREE.Vector3(4.45, getFloorBaseY(0), 1.05),
      size: new THREE.Vector3(0.75, 1.95, 0.75),
      camOffset: new THREE.Vector3(-0.08, 1.35, -0.05),
      lookYaw: Math.PI * 0.65,
      returnOffset: new THREE.Vector3(-0.95, 0, -0.1),
      meshMat: this.mats.fuseBoxMetal,
    });

    // 8. Attic Wooden Trunk (Floor 6 East)
    this.registerHidingSpot({
      id: 'hide_attic_crate',
      name: 'За ящиками на чердаке',
      pos: new THREE.Vector3(4.45, getFloorBaseY(6), 0.95),
      size: new THREE.Vector3(0.85, 1.45, 0.85),
      camOffset: new THREE.Vector3(-0.08, 1.0, -0.05),
      lookYaw: Math.PI * 0.7,
      returnOffset: new THREE.Vector3(-0.95, 0, -0.1),
      meshMat: this.mats.furnitureWood,
    });
  }

  private registerHidingSpot(cfg: {
    id: string;
    name: string;
    pos: THREE.Vector3;
    size: THREE.Vector3;
    camOffset: THREE.Vector3;
    lookYaw: number;
    returnOffset: THREE.Vector3;
    meshMat: THREE.Material;
  }): void {
    const mesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(cfg.size.x, cfg.size.y, cfg.size.z)),
      cfg.meshMat,
    );
    mesh.position.set(cfg.pos.x, cfg.pos.y + cfg.size.y / 2, cfg.pos.z);
    this.scene.add(mesh);

    this.collision.addCollider({
      minX: cfg.pos.x - cfg.size.x / 2,
      maxX: cfg.pos.x + cfg.size.x / 2,
      minY: cfg.pos.y,
      maxY: cfg.pos.y + cfg.size.y,
      minZ: cfg.pos.z - cfg.size.z / 2,
      maxZ: cfg.pos.z + cfg.size.z / 2,
    });

    const camPos = cfg.pos.clone().add(cfg.camOffset);
    const returnPos = cfg.pos.clone().add(cfg.returnOffset);

    this.hidingZones.push({
      id: cfg.id,
      name: cfg.name,
      spotPos: returnPos.clone(),
    });

    this.interaction.register({
      id: cfg.id,
      mesh,
      title: cfg.name,
      actionText: 'Спрятаться',
      category: 'hide',
      onInteract: () => {
        this.callbacks.onEnterHide({
          id: cfg.id,
          name: cfg.name,
          camPos,
          lookYaw: cfg.lookYaw,
          lookPitch: 0,
          returnPos,
        });
      },
    });
  }

  private buildWorldItemsAndNotes(): void {
    // 1. Floor 1 Utility Shelf: Battery (shifts slightly across Random Nights)
    const itemVar = this.callbacks.nightSeed.itemVariant;
    this.spawnWorldItem({
      id: 'item_f1_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos:
        itemVar === 2
          ? new THREE.Vector3(-0.95, getFloorBaseY(1) + 0.08, 1.15)
          : new THREE.Vector3(1.75, getFloorBaseY(1) + 0.08, -1.75),
      color: 0xeab308,
    });

    // 2. Floor 2 Corridor Crate: Screwdriver + Medkit (Medkit position varies by nightSeed)
    const crate = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.65, 0.55, 0.65)),
      this.mats.furnitureWood,
    );
    crate.position.set(4.5, getFloorBaseY(2) + 0.275, -1.5);
    this.scene.add(crate);

    this.spawnWorldItem({
      id: 'item_f2_screwdriver',
      itemId: 'screwdriver',
      label: 'Отвёртка',
      pos: new THREE.Vector3(4.4, getFloorBaseY(2) + 0.6, -1.45),
      color: 0xef4444,
    });
    this.spawnWorldItem({
      id: 'item_f2_medkit',
      itemId: 'medkit',
      label: 'Аптечка',
      pos:
        itemVar === 1
          ? new THREE.Vector3(-3.75, getFloorBaseY(1) + 0.08, 1.05)
          : new THREE.Vector3(4.65, getFloorBaseY(2) + 0.62, -1.6),
      color: 0xdc2626,
    });

    // 3. Floor 2 Half-Landing Windowsill: Note 4 + Fuse #1
    const sill2Y = getFloorBaseY(2) + BUILDING.HALF_HEIGHT + 0.77;
    this.spawnWorldNote(
      'note_2_sill',
      STORY_NOTES.note_windowsill_2,
      new THREE.Vector3(-0.7, sill2Y, BUILDING.STAIR_SOUTH_Z - 0.07),
    );
    this.spawnWorldItem({
      id: 'item_hl2_fuse1',
      itemId: 'fuse',
      label: 'Предохранитель №1',
      pos: new THREE.Vector3(-1.1, sill2Y + 0.04, BUILDING.STAIR_SOUTH_Z - 0.07),
      color: 0x38bdf8,
    });

    // 4. Floor 3 Apartment 7 note/items are placed inside ApartmentBuilder.buildApartment7()

    // 5. Floor 3 Secret Maintenance Niche: Note 6 + Fuse #2 + Key Apt 10 + Key Attic
    const y3 = getFloorBaseY(3);
    this.spawnWorldNote(
      'note_secret_niche',
      STORY_NOTES.note_secret_niche,
      new THREE.Vector3(6.6, y3 + 0.02, 0.2),
    );
    this.spawnWorldItem({
      id: 'item_niche_fuse2',
      itemId: 'fuse',
      label: 'Предохранитель №2',
      pos: new THREE.Vector3(6.9, y3 + 0.06, -0.05),
      color: 0x38bdf8,
    });
    this.spawnWorldItem({
      id: 'item_niche_key_apt10',
      itemId: 'key_apt10',
      label: 'Ключ от кв. 10',
      pos: new THREE.Vector3(6.9, y3 + 0.04, 0.45),
      color: 0xf59e0b,
    });
    this.spawnWorldItem({
      id: 'item_niche_key_attic',
      itemId: 'key_attic',
      label: 'Ключ от чердака',
      pos: new THREE.Vector3(7.1, y3 + 0.04, 0.7),
      color: 0x94a3b8,
    });

    // 6. Basement (Floor 0): Note 2, Note 3 (Switchboard), Fuel Canister
    const y0 = getFloorBaseY(0);
    this.spawnWorldNote(
      'note_basement_log',
      STORY_NOTES.note_basement_log,
      new THREE.Vector3(-2.4, y0 + 0.02, -1.3),
    );
    this.spawnWorldNote(
      'note_switchboard',
      STORY_NOTES.note_switchboard,
      new THREE.Vector3(2.4, y0 + 0.02, -1.5),
    );
    this.spawnWorldItem({
      id: 'item_basement_fuel',
      itemId: 'fuel',
      label: 'Канистра топлива',
      pos: new THREE.Vector3(-3.4, y0 + 0.16, -1.6),
      color: 0xb91c1c,
      size: new THREE.Vector3(0.28, 0.32, 0.2),
    });

    // 7. Floor 4 Apt 10: Note 7 + Fuse #3 + Medkit
    const y4 = getFloorBaseY(4);
    this.spawnWorldNote(
      'note_apt10_diary',
      STORY_NOTES.note_apt_10_diary,
      new THREE.Vector3(4.3, y4 + 0.79, -3.4),
    );
    this.spawnWorldItem({
      id: 'item_apt10_fuse3',
      itemId: 'fuse',
      label: 'Предохранитель №3',
      pos: new THREE.Vector3(4.0, y4 + 0.82, -3.25),
      color: 0x38bdf8,
    });
    this.spawnWorldItem({
      id: 'item_apt10_medkit',
      itemId: 'medkit',
      label: 'Аптечка',
      pos: new THREE.Vector3(4.55, y4 + 0.84, -3.6),
      color: 0xdc2626,
    });

    // 8. Floor 4 Secret Room: Note 8 + Tape #4 + Battery
    this.spawnWorldNote(
      'note_secret_room',
      STORY_NOTES.note_secret_room,
      new THREE.Vector3(3.1, y4 + 0.86, -9.1),
    );
    this.spawnWorldItem({
      id: 'item_secret_tape4',
      itemId: 'tape_4',
      label: 'Магнитная кассета №4',
      pos: new THREE.Vector3(3.7, y4 + 0.88, -9.1),
      color: 0x22d3ee,
    });
    this.spawnWorldItem({
      id: 'item_secret_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(2.4, y4 + 0.06, -8.5),
      color: 0xeab308,
    });

    // 9. Floor 5 Landing: Note 9
    this.spawnWorldNote(
      'note_floor5_wall',
      STORY_NOTES.note_floor5_wall,
      new THREE.Vector3(0.4, getFloorBaseY(5) + 0.02, -1.4),
    );

    // 10. Attic (Floor 6): Note 10 + Battery
    const y6 = getFloorBaseY(6);
    this.spawnWorldNote(
      'note_attic_journal',
      STORY_NOTES.note_attic_journal,
      new THREE.Vector3(2.8, y6 + 0.02, -0.5),
    );
    this.spawnWorldItem({
      id: 'item_attic_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(-2.5, y6 + 0.06, -1.4),
      color: 0xeab308,
    });
  }

  private spawnWorldNote(
    id: string,
    note: ReadableNote,
    pos: THREE.Vector3,
  ): void {
    const mesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.24, 0.014, 0.18)),
      this.mats.paperNote,
    );
    mesh.position.copy(pos);
    mesh.rotation.y = (Math.random() - 0.5) * 0.6;
    this.scene.add(mesh);

    this.interaction.register({
      id,
      mesh,
      title: note.title,
      actionText: 'Прочитать записку',
      category: 'note',
      onInteract: () => {
        this.sound.playPaperPickup();
        this.callbacks.onOpenNote(note);
      },
    });
  }

  private spawnWorldItem(cfg: {
    id: string;
    itemId: string;
    label: string;
    pos: THREE.Vector3;
    color: number;
    size?: THREE.Vector3;
  }): void {
    const sz = cfg.size ?? new THREE.Vector3(0.16, 0.08, 0.12);
    const mat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: cfg.color,
        emissive: cfg.color,
        emissiveIntensity: 0.25,
        roughness: 0.35,
        metalness: 0.45,
      }),
    );
    const mesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(sz.x, sz.y, sz.z)),
      mat,
    );
    mesh.position.copy(cfg.pos);
    this.scene.add(mesh);

    const handle: WorldItemHandle = { id: cfg.id, mesh, pickedUp: false };
    this.worldItems.set(cfg.id, handle);

    this.interaction.register({
      id: cfg.id,
      mesh,
      title: cfg.label,
      actionText: 'Подобрать',
      category: 'item',
      onInteract: () => {
        if (handle.pickedUp) return;
        if (!this.inventory.addItem(cfg.itemId)) {
          this.sound.playDoorLocked();
          this.callbacks.onSubtitle(
            'Инвентарь переполнен (макс. 8 слотов)! Используйте или освободите место.',
          );
          return;
        }
        handle.pickedUp = true;
        mesh.visible = false;
        this.pickedUpItems.add(cfg.id);
        this.interaction.updateEntry(cfg.id, { enabled: false });
        this.sound.playItemPickup();
        this.callbacks.onSubtitle(`Подобрано: ${cfg.label}`);
        this.callbacks.onStateChanged();
      },
    });
  }

  private buildFloorLights(): void {
    for (let f = BUILDING.MIN_FLOOR; f <= BUILDING.MAX_FLOOR; f++) {
      const y = getFloorBaseY(f);
      const powered = this.restoredFloors.has(f);
      const baseIntensity = f === 0 ? 1.15 : f === 6 ? 1.2 : f === 1 ? 1.85 : 1.5;
      const colorHex = f === 0 ? 0xd9534f : f === 6 ? 0x9bb8d3 : 0xcddbb8;

      const tubeMat = this.mats.trackMat(
        new THREE.MeshStandardMaterial({
          color: 0xb7c2b0,
          emissive: colorHex,
          emissiveIntensity: powered ? 1.1 : 0.04,
          roughness: 0.3,
        }),
      );

      const housing = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.95, 0.08, 0.22)),
        this.mats.trimDark,
      );
      housing.position.set(0.15, y + BUILDING.FLOOR_HEIGHT - 0.26, -0.35);
      this.scene.add(housing);

      const tube = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.86, 0.04, 0.12)),
        tubeMat,
      );
      tube.position.set(0.15, y + BUILDING.FLOOR_HEIGHT - 0.3, -0.35);
      this.scene.add(tube);

      const light = new THREE.PointLight(
        colorHex,
        powered ? baseIntensity : 0,
        9.5,
        1.75,
      );
      light.position.set(0.15, y + BUILDING.FLOOR_HEIGHT - 0.55, -0.35);
      this.scene.add(light);

      this.floorLights.push({
        floor: f,
        light,
        tubeMat,
        powered,
        baseIntensity,
      });
    }
  }

  private buildSecurityCameras(
    specs: { pos: THREE.Vector3; yaw: number; floor: number }[],
  ): void {
    const camLedMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x111111,
        emissive: 0x22c55e,
        emissiveIntensity: 1.4,
      }),
    );

    for (const spec of specs) {
      const camGroup = new THREE.Group();
      camGroup.position.copy(spec.pos);
      camGroup.rotation.y = spec.yaw;
      this.scene.add(camGroup);

      const housing = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.14, 0.11, 0.24)),
        this.mats.doorSteel,
      );
      camGroup.add(housing);

      const lens = new THREE.Mesh(
        this.trackGeo(new THREE.CylinderGeometry(0.036, 0.042, 0.08, 8)),
        this.mats.trimDark,
      );
      lens.rotation.x = Math.PI / 2;
      lens.position.set(0, -0.01, 0.14);
      camGroup.add(lens);

      const led = new THREE.Mesh(
        this.trackGeo(new THREE.BoxGeometry(0.025, 0.025, 0.02)),
        camLedMat,
      );
      led.position.set(0.04, 0.03, 0.125);
      camGroup.add(led);
    }
  }

  private creakNearestDoor(floor: number): void {
    const ids = this.floorDoorIds.get(floor);
    if (!ids || ids.length === 0) return;
    const id = ids[Math.floor(Math.random() * ids.length)];
    this.doorActions.get(id)?.();
    this.callbacks.onSubtitle('Рядом со скрипом приоткрылась дверь...');
  }

  private flickerFloorLight(floor: number): void {
    const rig = this.floorLights.find((r) => r.floor === floor);
    if (rig && rig.powered) {
      rig.light.intensity = 0.05;
      rig.tubeMat.emissiveIntensity = 0.05;
      this.sound.playBreakerFlip();
    }
  }

  private applySavedState(s: {
    restoredFloors: number[];
    unlockedDoors: string[];
    unlockedKeypads?: string[];
    pickedUpWorldItems: string[];
    generatorFuelAdded: boolean;
    generatorFusesInserted: number;
    generatorRunning: boolean;
    secretPanelOpen: boolean;
    ventGrateOpen: boolean;
    atticTransmitterActive: boolean;
  }): void {
    this.restoredFloors = new Set(s.restoredFloors);
    for (const rig of this.floorLights) {
      rig.powered = this.restoredFloors.has(rig.floor);
      rig.light.intensity = rig.powered ? rig.baseIntensity : 0;
      rig.tubeMat.emissiveIntensity = rig.powered ? 1.05 : 0.04;
    }

    for (const d of s.unlockedDoors) {
      this.dynamicUnlockers.get(d)?.();
    }
    if (s.unlockedKeypads) {
      for (const kp of s.unlockedKeypads) {
        this.dynamicUnlockers.get(kp)?.();
      }
    }
    if (s.secretPanelOpen) this.dynamicUnlockers.get('apt10_secret_panel')?.();
    if (s.ventGrateOpen) this.dynamicUnlockers.get('floor3_vent_grate')?.();
    if (s.atticTransmitterActive) {
      this.dynamicUnlockers.get('attic_transmitter')?.();
    }

    for (const itemId of s.pickedUpWorldItems) {
      this.pickedUpItems.add(itemId);
      const handle = this.worldItems.get(itemId);
      if (handle) {
        handle.pickedUp = true;
        handle.mesh.visible = false;
        this.interaction.updateEntry(itemId, { enabled: false });
      }
    }

    this.generatorFuelAdded = s.generatorFuelAdded;
    this.generatorFusesInserted = s.generatorFusesInserted;
    if (s.generatorRunning) {
      this.activateGenerator(true);
    }
  }
}
