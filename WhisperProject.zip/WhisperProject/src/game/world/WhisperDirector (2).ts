import * as THREE from 'three';
import { FloorLightRig } from './BuildingBuilder';
import { DIFFICULTY_PROFILES, getFloorBaseY } from './BuildingConfig';
import { SoundEngine } from '../audio/SoundEngine';
import { ElevatorSystem } from './ElevatorSystem';
import { DifficultyLevel, PhoneMessage } from '../types';

export interface RandomEventCallbacks {
  onSubtitle: (text: string) => void;
  onFlickerPower: (floor: number) => void;
  onCreakNearestDoor: (playerFloor: number) => void;
  onPhoneMessage: (msg: PhoneMessage) => void;
  onPhantomSeen?: () => void;
  onWhisperHeard?: () => void;
}

export class WhisperDirector {
  public tension = 0.15;

  private ghostGroup = new THREE.Group();
  private ghostActive = false;
  private ghostTimer = 0;
  private nextEventTimer = 18;
  private lastEventKind = -1;
  private flickerTimer = 0;
  private eventIntervalScale = 1.0;
  private isNewGamePlus = false;
  private smsCounter = 0;

  constructor(
    scene: THREE.Scene,
    private sound: SoundEngine,
    private elevator: ElevatorSystem,
    private callbacks: RandomEventCallbacks,
  ) {
    this.buildGhostSilhouette();
    scene.add(this.ghostGroup);
    this.ghostGroup.visible = false;
  }

  public setDifficulty(diff: DifficultyLevel, isNewGamePlus = false): void {
    this.eventIntervalScale = DIFFICULTY_PROFILES[diff].eventIntervalScale;
    this.isNewGamePlus = isNewGamePlus;
  }

  private buildGhostSilhouette(): void {
    const mat = new THREE.MeshStandardMaterial({
      color: 0x050507,
      roughness: 0.95,
      metalness: 0.05,
    });

    const torso = new THREE.Mesh(
      new THREE.CylinderGeometry(0.19, 0.13, 1.45, 8),
      mat,
    );
    torso.position.set(0, 0.9, 0);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 8), mat);
    head.position.set(0, 1.78, 0.02);
    this.ghostGroup.add(torso, head);
  }

  public reset(): void {
    this.tension = 0.15;
    this.ghostActive = false;
    this.ghostGroup.visible = false;
    this.nextEventTimer = 16 * this.eventIntervalScale;
    this.lastEventKind = -1;
    this.flickerTimer = 0;
  }

  public update(
    delta: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    playerFloor: number,
    monsterDistance: number,
    generatorRunning: boolean,
    floorLights: FloorLightRig[],
    setFlashlightFlicker: (scale: number) => void,
  ): void {
    const proximityTension = Math.max(0, 1 - monsterDistance / 16) * 0.75;
    const floorTension = playerFloor === 0 || playerFloor === 6 ? 0.55 : 0.25;
    const targetTension = Math.min(1, Math.max(floorTension, proximityTension));
    this.tension = THREE.MathUtils.damp(this.tension, targetTension, 0.6, delta);
    this.sound.updateAtmosphere(this.tension, playerFloor, generatorRunning);

    for (let i = 0; i < floorLights.length; i++) {
      const rig = floorLights[i];
      const nearPlayer = rig.isApartment
        ? rig.floor === playerFloor
        : Math.abs(rig.floor - playerFloor) <= 1;
      if (!rig.powered || !nearPlayer) {
        rig.light.intensity = 0;
        rig.tubeMat.emissiveIntensity = rig.powered ? 0.8 : 0.03;
        continue;
      }

      if (this.flickerTimer > 0) {
        const strobe = Math.sin(elapsed * 58) > 0.15 ? 0.18 : 1.15;
        rig.light.intensity = rig.baseIntensity * strobe;
        rig.tubeMat.emissiveIntensity = strobe;
      } else if (rig.isApartment) {
        const phase = rig.flickerPhase ?? rig.floor * 1.7;
        const wobble =
          Math.sin(elapsed * 21 + phase) * 0.5 +
          Math.sin(elapsed * 4.7 + phase * 1.3) * 0.5;
        const dip = wobble < -0.78 ? 0.24 : 0.88 + wobble * 0.14;
        rig.light.intensity = rig.baseIntensity * dip;
        rig.tubeMat.emissiveIntensity = Math.max(0.15, dip);
      } else {
        const subtle = 1 + Math.sin(elapsed * 19 + rig.floor) * 0.03;
        rig.light.intensity = rig.baseIntensity * subtle;
        rig.tubeMat.emissiveIntensity = 1.05 * subtle;
      }
    }

    if (this.flickerTimer > 0) {
      this.flickerTimer -= delta;
      setFlashlightFlicker(Math.sin(elapsed * 64) > 0 ? 1.0 : 0.35);
    } else {
      setFlashlightFlicker(1.0);
    }

    // 12 distinct non-repeating random horror + phone SMS/Call events
    this.nextEventTimer -= delta;
    if (this.nextEventTimer <= 0) {
      this.nextEventTimer = (16 + Math.random() * 14) * this.eventIntervalScale;
      let kind = Math.floor(Math.random() * 12);
      if (kind === this.lastEventKind) kind = (kind + 1) % 12;
      this.lastEventKind = kind;
      this.triggerRandomEvent(kind, playerFloor, monsterDistance, generatorRunning);
    }

    if (this.ghostActive) {
      this.ghostTimer -= delta;
      if (
        this.ghostTimer <= 0 ||
        this.ghostGroup.position.distanceTo(playerPos) < 3.4
      ) {
        this.ghostActive = false;
        this.ghostGroup.visible = false;
      }
    }
  }

  private buildTimestamp(): string {
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
  }

  private triggerRandomEvent(
    kind: number,
    playerFloor: number,
    monsterDistance: number,
    generatorRunning: boolean,
  ): void {
    const pan = Math.random() * 1.4 - 0.7;
    switch (kind) {
      case 0:
        this.sound.playDoorKnock(pan);
        this.callbacks.onSubtitle('Кто-то глухо постучал в соседнюю дверь...');
        break;
      case 1:
        if (this.elevator.powerEnabled && this.elevator.state === 'idle') {
          const target = Math.max(1, Math.min(5, playerFloor === 3 ? 2 : 3));
          this.elevator.callToFloor(target, true);
          this.sound.playElevatorChime();
          this.callbacks.onSubtitle(`Лифт сам поехал на ${target} этаж...`);
        } else {
          this.sound.playElevatorChime();
        }
        break;
      case 2:
        this.flickerTimer = 2.2;
        this.callbacks.onFlickerPower(playerFloor);
        break;
      case 3:
        this.sound.playMonsterFootstep(6, pan);
        window.setTimeout(() => this.sound.playMonsterFootstep(7, pan * 0.8), 380);
        window.setTimeout(() => this.sound.playMonsterFootstep(8.5, pan * 0.6), 760);
        break;
      case 4:
        this.sound.playWhisper(pan, 0.75);
        this.callbacks.onWhisperHeard?.();
        this.callbacks.onSubtitle('Из вентиляционной решётки донёсся шёпот...');
        break;
      case 5:
        this.callbacks.onCreakNearestDoor(playerFloor);
        break;
      case 6:
        this.sound.playDistantBang(pan);
        this.callbacks.onSubtitle('За стеной что-то тяжело упало на пол.');
        break;
      case 7:
        if (playerFloor >= 1 && playerFloor <= 4) {
          this.ghostGroup.position.set(
            -0.7,
            getFloorBaseY(playerFloor) + 1.6,
            5.35,
          );
          this.ghostGroup.visible = true;
          this.ghostActive = true;
          this.ghostTimer = 2.6;
          this.sound.playWhisper(0, 0.55);
          this.callbacks.onPhantomSeen?.();
        }
        break;
      case 8:
        this.sound.playMuffledFootstepsBehindDoor(pan);
        this.callbacks.onSubtitle('За одной из закрытых дверей прошелестели шаги...');
        break;
      case 9:
        this.sound.playFloorCreak(pan, 0.7);
        this.callbacks.onSubtitle(
          'Где-то в соседней квартире жалобно скрипнула половица...',
        );
        break;
      case 10: {
        // Mysterious SMS with contextual hint / photo
        this.smsCounter += 1;
        this.sound.playPhoneBuzz();
        const pool: Omit<PhoneMessage, 'id' | 'timestamp'>[] = [
          {
            sender: 'Неизвестный номер',
            text:
              monsterDistance < 10
                ? 'Он совсем рядом с твоим этажом. Гаси свет и замри!'
                : `Ты на ${playerFloor} этаже? Пост охраны в кв. №5 покажет камеры подъезда.`,
            photoTitle: 'Снимок из шахты лифта',
            photoCaption: 'Тёмная фигура у дверей шахты (архив, 02:14)',
            photoScene: 'shaft',
          },
          {
            sender: 'Диспетчер #04',
            text: generatorRunning
              ? 'Питание запущено. Если нашёл кассету №4 — поднимайся на чердак.'
              : 'Дизель в подвале запустит лифт и откроет магнитный замок на 1-м этаже.',
            photoTitle: 'Фото щитовой подвала',
            photoCaption: 'Три высоковольтных предохранителя отмечены на схеме.',
            photoScene: 'basement',
          },
          {
            sender: 'Жилец из 10-й',
            text: this.isNewGamePlus
              ? 'Новый круг начался. Код сейфа в кв. 5 разделён между 2-й и 5-й квартирами.'
              : 'В квартире №2 оставили первую часть кода от шкафа поста охраны в кв. №5.',
            photoTitle: 'Коридор 4 этажа (1998)',
            photoCaption: 'Фальшстена в конце заброшенной квартиры.',
            photoScene: 'corridor',
          },
        ];
        const pick = pool[this.smsCounter % pool.length];
        this.callbacks.onPhoneMessage({
          id: `sms_dir_${Date.now()}_${this.smsCounter}`,
          timestamp: this.buildTimestamp(),
          ...pick,
        });
        break;
      }
      case 11: {
        // Eerie incoming call notification
        this.smsCounter += 1;
        this.sound.playIncomingCallRing();
        this.callbacks.onPhoneMessage({
          id: `call_dir_${Date.now()}_${this.smsCounter}`,
          sender: 'Скрытый вызов',
          text:
            playerFloor >= 4
              ? 'В трубке слышно прерывистое дыхание и треск радиопередатчика над потолком...'
              : 'Голос в динамике шепчет: «Не выходи на пролёт... он уже спускается по лестнице...»',
          timestamp: this.buildTimestamp(),
          isCall: true,
          photoTitle: 'Антенна чердака',
          photoCaption: 'Перехваченный кадр с верхнего перекрытия.',
          photoScene: 'attic',
        });
        break;
      }
    }
  }
}
