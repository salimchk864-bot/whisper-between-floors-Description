import * as THREE from 'three';
import { BUILDING, getFloorBaseY } from './BuildingConfig';
import { MaterialLibrary } from './MaterialLibrary';
import { BoxCollider, CollisionWorld } from '../engine/CollisionWorld';
import { InteractionManager } from '../engine/InteractionManager';
import { SoundEngine } from '../audio/SoundEngine';

export type ElevatorState = 'idle' | 'closing' | 'moving' | 'opening' | 'stalled';

interface FloorShaftRig {
  floor: number;
  leftDoor: THREE.Mesh;
  rightDoor: THREE.Mesh;
  doorCollider: BoxCollider;
  callLedMat: THREE.MeshStandardMaterial;
  displayMat: THREE.MeshStandardMaterial;
}

export class ElevatorSystem {
  public currentFloor = 1;
  public targetFloor = 1;
  public currentY = 0;
  public state: ElevatorState = 'idle';
  public doorsOpenAmount = 1;
  public powerEnabled = true; // Emergency backup initially active until stall, then requires generator!
  public emergencyTripsLeft = 1;

  private cabinGroup = new THREE.Group();
  private cabinLeftDoor!: THREE.Mesh;
  private cabinRightDoor!: THREE.Mesh;
  private cabinLight!: THREE.PointLight;
  private cabinBulbMat!: THREE.MeshStandardMaterial;
  private cabinFloorDisplayMat!: THREE.MeshStandardMaterial;

  private floorRigs: FloorShaftRig[] = [];
  private cabinColliders: BoxCollider[] = [];
  private innerDoorCollider!: BoxCollider;
  private numberTextures: THREE.CanvasTexture[] = [];
  private buttonLedMats = new Map<number, THREE.MeshStandardMaterial>();

  private stateTimer = 0;
  private stallTriggered = false;
  private hasPlayedStallEvent = false;
  private onSubtitle?: (text: string) => void;
  private onStallCutscene?: () => void;

  constructor(
    private scene: THREE.Scene,
    private mats: MaterialLibrary,
    private collision: CollisionWorld,
    private interaction: InteractionManager,
    private sound: SoundEngine,
    callbacks?: {
      onSubtitle?: (text: string) => void;
      onStallCutscene?: () => void;
    },
  ) {
    this.onSubtitle = callbacks?.onSubtitle;
    this.onStallCutscene = callbacks?.onStallCutscene;
    this.createNumberTextures();
    this.buildShaftShell();
    this.buildCabin();
    this.buildFloorShaftDoors();
    this.syncDisplays(1);
    this.syncDoorPositions();
  }

  private createNumberTextures(): void {
    for (let f = 1; f <= BUILDING.FLOOR_COUNT; f++) {
      const canvas = document.createElement('canvas');
      canvas.width = 64;
      canvas.height = 64;
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = '#090a0c';
      ctx.fillRect(0, 0, 64, 64);
      ctx.fillStyle = '#e86830';
      ctx.font = 'bold 42px monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(String(f), 32, 34);

      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      this.numberTextures.push(tex);
    }
  }

  private buildShaftShell(): void {
    const minY = getFloorBaseY(0);
    const maxY = getFloorBaseY(BUILDING.MAX_FLOOR) + 2.8;
    const totalHeight = maxY - minY;
    const centerY = (minY + maxY) / 2;

    const minX = BUILDING.ELEVATOR_MIN_X - 0.1;
    const maxX = BUILDING.ELEVATOR_MAX_X + 0.1;
    const minZ = BUILDING.ELEVATOR_MIN_Z - 0.15;
    const maxZ = BUILDING.ELEVATOR_MAX_Z;
    const w = maxX - minX;
    const d = maxZ - minZ;

    const shaftMat = new THREE.MeshStandardMaterial({
      color: 0x151719,
      roughness: 0.92,
      metalness: 0.25,
    });
    this.mats.trackMat(shaftMat);

    const backWall = new THREE.Mesh(
      new THREE.BoxGeometry(w, totalHeight, 0.16),
      shaftMat,
    );
    backWall.position.set(BUILDING.ELEVATOR_CENTER_X, centerY, minZ);
    this.scene.add(backWall);

    const leftWall = new THREE.Mesh(
      new THREE.BoxGeometry(0.16, totalHeight, d),
      shaftMat,
    );
    leftWall.position.set(minX, centerY, (minZ + maxZ) / 2);
    this.scene.add(leftWall);

    const rightWall = new THREE.Mesh(
      new THREE.BoxGeometry(0.16, totalHeight, d),
      shaftMat,
    );
    rightWall.position.set(maxX, centerY, (minZ + maxZ) / 2);
    this.scene.add(rightWall);

    for (const rx of [BUILDING.ELEVATOR_MIN_X + 0.05, BUILDING.ELEVATOR_MAX_X - 0.05]) {
      const rail = new THREE.Mesh(
        new THREE.BoxGeometry(0.06, totalHeight, 0.08),
        this.mats.railingMetal,
      );
      rail.position.set(rx, centerY, BUILDING.ELEVATOR_CENTER_Z);
      this.scene.add(rail);
    }
  }

  private buildCabin(): void {
    const cx = BUILDING.ELEVATOR_CENTER_X;
    const cz = BUILDING.ELEVATOR_CENTER_Z;
    const cw = BUILDING.ELEVATOR_MAX_X - BUILDING.ELEVATOR_MIN_X - 0.08;
    const cd = BUILDING.ELEVATOR_MAX_Z - BUILDING.ELEVATOR_MIN_Z - 0.12;
    const ch = BUILDING.ELEVATOR_CABIN_HEIGHT;

    this.cabinGroup.position.set(cx, 0, cz);
    this.scene.add(this.cabinGroup);

    const floorMesh = new THREE.Mesh(
      new THREE.BoxGeometry(cw, 0.12, cd),
      this.mats.elevatorFloor,
    );
    floorMesh.position.set(0, -0.06, 0);
    floorMesh.receiveShadow = true;
    this.cabinGroup.add(floorMesh);

    this.collision.addWalkSurface({
      id: 'elevator_cabin_floor',
      minX: BUILDING.ELEVATOR_MIN_X,
      maxX: BUILDING.ELEVATOR_MAX_X,
      minZ: BUILDING.ELEVATOR_MIN_Z,
      maxZ: BUILDING.ELEVATOR_MAX_Z,
      onMetal: true,
      getY: () => this.currentY,
    });

    const wallT = 0.08;
    const back = new THREE.Mesh(
      new THREE.BoxGeometry(cw, ch, wallT),
      this.mats.elevatorSteel,
    );
    back.position.set(0, ch / 2, -cd / 2 + wallT / 2);
    back.receiveShadow = true;
    this.cabinGroup.add(back);

    const left = new THREE.Mesh(
      new THREE.BoxGeometry(wallT, ch, cd),
      this.mats.elevatorSteel,
    );
    left.position.set(-cw / 2 + wallT / 2, ch / 2, 0);
    left.receiveShadow = true;
    this.cabinGroup.add(left);

    const right = new THREE.Mesh(
      new THREE.BoxGeometry(wallT, ch, cd),
      this.mats.elevatorSteel,
    );
    right.position.set(cw / 2 - wallT / 2, ch / 2, 0);
    right.receiveShadow = true;
    this.cabinGroup.add(right);

    const rail = new THREE.Mesh(
      new THREE.CylinderGeometry(0.022, 0.022, cw - 0.35, 10),
      this.mats.brassAccent,
    );
    rail.rotation.z = Math.PI / 2;
    rail.position.set(0, 0.96, -cd / 2 + 0.15);
    this.cabinGroup.add(rail);

    const jambW = (cw - BUILDING.ELEVATOR_DOOR_WIDTH) / 2;
    const leftJamb = new THREE.Mesh(
      new THREE.BoxGeometry(jambW, ch, 0.09),
      this.mats.elevatorSteel,
    );
    leftJamb.position.set(-cw / 2 + jambW / 2, ch / 2, cd / 2 - 0.04);
    this.cabinGroup.add(leftJamb);

    const rightJamb = new THREE.Mesh(
      new THREE.BoxGeometry(jambW, ch, 0.09),
      this.mats.elevatorSteel,
    );
    rightJamb.position.set(cw / 2 - jambW / 2, ch / 2, cd / 2 - 0.04);
    this.cabinGroup.add(rightJamb);

    const transomH = ch - BUILDING.ELEVATOR_DOOR_HEIGHT;
    const transom = new THREE.Mesh(
      new THREE.BoxGeometry(BUILDING.ELEVATOR_DOOR_WIDTH, transomH, 0.09),
      this.mats.elevatorSteel,
    );
    transom.position.set(0, ch - transomH / 2, cd / 2 - 0.04);
    this.cabinGroup.add(transom);

    const halfDoorW = BUILDING.ELEVATOR_DOOR_WIDTH / 2 + 0.02;
    const doorGeo = new THREE.BoxGeometry(
      halfDoorW,
      BUILDING.ELEVATOR_DOOR_HEIGHT,
      0.04,
    );
    this.cabinLeftDoor = new THREE.Mesh(doorGeo, this.mats.elevatorSteel);
    this.cabinLeftDoor.position.set(
      -halfDoorW / 2,
      BUILDING.ELEVATOR_DOOR_HEIGHT / 2,
      cd / 2 - 0.09,
    );
    this.cabinGroup.add(this.cabinLeftDoor);

    this.cabinRightDoor = new THREE.Mesh(doorGeo, this.mats.elevatorSteel);
    this.cabinRightDoor.position.set(
      halfDoorW / 2,
      BUILDING.ELEVATOR_DOOR_HEIGHT / 2,
      cd / 2 - 0.09,
    );
    this.cabinGroup.add(this.cabinRightDoor);

    const roof = new THREE.Mesh(
      new THREE.BoxGeometry(cw, 0.1, cd),
      this.mats.ceilingConcrete,
    );
    roof.position.set(0, ch + 0.05, 0);
    this.cabinGroup.add(roof);

    this.cabinBulbMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xffdfaa,
        emissive: 0xffb860,
        emissiveIntensity: 1.5,
        roughness: 0.25,
      }),
    );
    const fixture = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.06, 0.22),
      this.cabinBulbMat,
    );
    fixture.position.set(0, ch - 0.03, 0);
    this.cabinGroup.add(fixture);

    this.cabinLight = new THREE.PointLight(0xffcb80, 1.4, 5.5, 1.8);
    this.cabinLight.position.set(0, ch - 0.22, 0);
    this.cabinGroup.add(this.cabinLight);

    this.cabinFloorDisplayMat = this.mats.trackMat(
      new THREE.MeshStandardMaterial({
        map: this.numberTextures[0],
        emissive: 0xff6a2a,
        emissiveMap: this.numberTextures[0],
        emissiveIntensity: 0.9,
        roughness: 0.3,
      }),
    );
    const innerDisp = new THREE.Mesh(
      new THREE.PlaneGeometry(0.18, 0.18),
      this.cabinFloorDisplayMat,
    );
    innerDisp.rotation.y = Math.PI;
    innerDisp.position.set(0, ch - 0.11, cd / 2 - 0.095);
    this.cabinGroup.add(innerDisp);

    // Interior floor buttons 1..5
    const panelPlate = new THREE.Mesh(
      new THREE.BoxGeometry(0.24, 0.72, 0.04),
      this.mats.doorSteel,
    );
    panelPlate.position.set(cw / 2 - 0.24, 1.25, cd / 2 - 0.11);
    this.cabinGroup.add(panelPlate);

    for (let f = 1; f <= BUILDING.FLOOR_COUNT; f++) {
      const btnY = 0.98 + (f - 1) * 0.12;
      const ledMat = this.mats.trackMat(
        new THREE.MeshStandardMaterial({
          color: 0x3b2a1c,
          emissive: 0xe67e22,
          emissiveIntensity: f === 1 ? 0.8 : 0.0,
          roughness: 0.35,
          metalness: 0.4,
        }),
      );
      this.buttonLedMats.set(f, ledMat);

      const btnMesh = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, 0.075, 0.045),
        ledMat,
      );
      btnMesh.position.set(cw / 2 - 0.24, btnY, cd / 2 - 0.125);
      this.cabinGroup.add(btnMesh);

      const lblPlane = new THREE.Mesh(
        new THREE.PlaneGeometry(0.055, 0.055),
        this.mats.createStencilPlateMaterial(String(f), '#1c2024', '#f0ede6', 64, 64),
      );
      lblPlane.rotation.y = Math.PI;
      lblPlane.position.set(cw / 2 - 0.24, btnY, cd / 2 - 0.15);
      this.cabinGroup.add(lblPlane);

      this.interaction.register({
        id: `elevator_btn_${f}`,
        mesh: btnMesh,
        title: `Лифт — Этаж ${f}`,
        actionText: `Поехать на ${f} этаж`,
        category: 'elevator_button',
        maxDistance: 2.2,
        onInteract: () => this.requestFloor(f),
      });
    }

    const wallMinX = BUILDING.ELEVATOR_MIN_X;
    const wallMaxX = BUILDING.ELEVATOR_MAX_X;
    const wallMinZ = BUILDING.ELEVATOR_MIN_Z;
    const wallMaxZ = BUILDING.ELEVATOR_MAX_Z;

    this.cabinColliders.push(
      this.collision.addCollider({
        id: 'cabin_back',
        minX: wallMinX,
        maxX: wallMaxX,
        minY: 0,
        maxY: ch,
        minZ: wallMinZ - 0.12,
        maxZ: wallMinZ + 0.12,
      }),
      this.collision.addCollider({
        id: 'cabin_left',
        minX: wallMinX - 0.12,
        maxX: wallMinX + 0.12,
        minY: 0,
        maxY: ch,
        minZ: wallMinZ,
        maxZ: wallMaxZ,
      }),
      this.collision.addCollider({
        id: 'cabin_right',
        minX: wallMaxX - 0.12,
        maxX: wallMaxX + 0.12,
        minY: 0,
        maxY: ch,
        minZ: wallMinZ,
        maxZ: wallMaxZ,
      }),
    );

    this.innerDoorCollider = this.collision.addCollider({
      id: 'cabin_inner_door',
      minX: BUILDING.ELEVATOR_CENTER_X - BUILDING.ELEVATOR_DOOR_WIDTH / 2,
      maxX: BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2,
      minY: 0,
      maxY: ch,
      minZ: BUILDING.ELEVATOR_MAX_Z - 0.18,
      maxZ: BUILDING.ELEVATOR_MAX_Z + 0.05,
      enabled: false,
    });
  }

  private buildFloorShaftDoors(): void {
    const halfDoorW = BUILDING.ELEVATOR_DOOR_WIDTH / 2 + 0.02;
    const doorH = BUILDING.ELEVATOR_DOOR_HEIGHT;
    const doorGeo = new THREE.BoxGeometry(halfDoorW, doorH, 0.06);

    for (let f = 1; f <= BUILDING.FLOOR_COUNT; f++) {
      const baseY = getFloorBaseY(f);

      const leftDoor = new THREE.Mesh(doorGeo, this.mats.elevatorSteel);
      leftDoor.position.set(
        BUILDING.ELEVATOR_CENTER_X - halfDoorW / 2,
        baseY + doorH / 2,
        BUILDING.ELEVATOR_MAX_Z - 0.02,
      );
      this.scene.add(leftDoor);

      const rightDoor = new THREE.Mesh(doorGeo, this.mats.elevatorSteel);
      rightDoor.position.set(
        BUILDING.ELEVATOR_CENTER_X + halfDoorW / 2,
        baseY + doorH / 2,
        BUILDING.ELEVATOR_MAX_Z - 0.02,
      );
      this.scene.add(rightDoor);

      const frameLeft = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, doorH + 0.1, 0.16),
        this.mats.trimDark,
      );
      frameLeft.position.set(
        BUILDING.ELEVATOR_CENTER_X - BUILDING.ELEVATOR_DOOR_WIDTH / 2 - 0.06,
        baseY + doorH / 2,
        BUILDING.ELEVATOR_MAX_Z,
      );
      this.scene.add(frameLeft);

      const frameRight = new THREE.Mesh(
        new THREE.BoxGeometry(0.12, doorH + 0.1, 0.16),
        this.mats.trimDark,
      );
      frameRight.position.set(
        BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2 + 0.06,
        baseY + doorH / 2,
        BUILDING.ELEVATOR_MAX_Z,
      );
      this.scene.add(frameRight);

      const displayMat = this.mats.trackMat(
        new THREE.MeshStandardMaterial({
          map: this.numberTextures[0],
          emissive: 0xe86830,
          emissiveMap: this.numberTextures[0],
          emissiveIntensity: 0.75,
          roughness: 0.3,
        }),
      );
      const display = new THREE.Mesh(
        new THREE.PlaneGeometry(0.22, 0.22),
        displayMat,
      );
      display.position.set(
        BUILDING.ELEVATOR_CENTER_X,
        baseY + doorH + 0.24,
        BUILDING.ELEVATOR_MAX_Z + 0.09,
      );
      this.scene.add(display);

      const callBox = new THREE.Mesh(
        new THREE.BoxGeometry(0.14, 0.22, 0.05),
        this.mats.doorSteel,
      );
      callBox.position.set(
        BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2 + 0.26,
        baseY + 1.25,
        BUILDING.ELEVATOR_MAX_Z + 0.09,
      );
      this.scene.add(callBox);

      const callLedMat = this.mats.trackMat(
        new THREE.MeshStandardMaterial({
          color: 0x2c2218,
          emissive: 0xf59e0b,
          emissiveIntensity: 0,
          roughness: 0.35,
        }),
      );
      const callBtn = new THREE.Mesh(
        new THREE.BoxGeometry(0.065, 0.065, 0.03),
        callLedMat,
      );
      callBtn.position.set(
        BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2 + 0.26,
        baseY + 1.25,
        BUILDING.ELEVATOR_MAX_Z + 0.115,
      );
      this.scene.add(callBtn);

      this.interaction.register({
        id: `elevator_call_${f}`,
        mesh: callBox,
        title: `Лифт (${f} этаж)`,
        actionText: 'Вызвать лифт',
        category: 'elevator_call',
        maxDistance: 2.35,
        onInteract: () => this.callToFloor(f, false),
      });

      const doorCollider = this.collision.addCollider({
        id: `elevator_outer_door_${f}`,
        minX: BUILDING.ELEVATOR_CENTER_X - BUILDING.ELEVATOR_DOOR_WIDTH / 2,
        maxX: BUILDING.ELEVATOR_CENTER_X + BUILDING.ELEVATOR_DOOR_WIDTH / 2,
        minY: baseY,
        maxY: baseY + BUILDING.FLOOR_HEIGHT,
        minZ: BUILDING.ELEVATOR_MAX_Z - 0.12,
        maxZ: BUILDING.ELEVATOR_MAX_Z + 0.08,
        enabled: f !== 1,
      });

      this.floorRigs.push({
        floor: f,
        leftDoor,
        rightDoor,
        doorCollider,
        callLedMat,
        displayMat,
      });
    }
  }

  public setPowerEnabled(on: boolean): void {
    this.powerEnabled = on;
    if (on) {
      this.cabinBulbMat.emissiveIntensity = 1.6;
      this.cabinLight.intensity = 1.45;
    } else {
      this.cabinBulbMat.emissiveIntensity = 0.05;
      this.cabinLight.intensity = 0.15;
    }
  }

  public setAtFloorImmediate(floor: number): void {
    this.currentFloor = Math.max(1, Math.min(BUILDING.FLOOR_COUNT, floor));
    this.targetFloor = this.currentFloor;
    this.currentY = getFloorBaseY(this.currentFloor);
    this.state = 'idle';
    this.doorsOpenAmount = 1;
    this.cabinGroup.position.y = this.currentY;
    this.syncDisplays(this.currentFloor);
    this.syncDoorPositions();
    this.syncCabinColliders();
  }

  public callToFloor(floor: number, silent = false): void {
    if (!silent) this.sound.playElevatorButton();
    if (!this.powerEnabled) {
      if (!silent) {
        this.onSubtitle?.(
          'Лифт обесточен. Запустите резервный генератор в электрощитовой подвала.',
        );
      }
      return;
    }
    if (
      this.currentFloor === floor &&
      (this.state === 'idle' || this.state === 'opening')
    ) {
      if (this.doorsOpenAmount < 0.95) {
        this.state = 'opening';
        this.sound.playElevatorDoorSlide();
      }
      return;
    }
    this.targetFloor = floor;
    const rig = this.floorRigs[floor - 1];
    if (rig) rig.callLedMat.emissiveIntensity = 1.4;

    if (this.state === 'idle' || this.state === 'opening') {
      this.state = 'closing';
      this.sound.playElevatorDoorSlide();
    }
  }

  public requestFloor(floor: number): void {
    this.sound.playElevatorButton();
    if (!this.powerEnabled) {
      this.onSubtitle?.(
        'Панель не реагирует: питание лифта отключено. Запустите генератор в подвале.',
      );
      return;
    }
    if (floor === this.currentFloor && this.state === 'idle') {
      this.onSubtitle?.(`Лифт уже на ${floor} этаже.`);
      return;
    }
    this.targetFloor = floor;
    this.buttonLedMats.forEach((mat, f) => {
      mat.emissiveIntensity = f === floor ? 1.5 : 0.05;
    });
    if (this.state === 'idle' || this.state === 'opening') {
      this.state = 'closing';
      this.sound.playElevatorDoorSlide();
    }
  }

  public isPlayerInside(px: number, py: number, pz: number): boolean {
    return (
      px >= BUILDING.ELEVATOR_MIN_X &&
      px <= BUILDING.ELEVATOR_MAX_X &&
      pz >= BUILDING.ELEVATOR_MIN_Z &&
      pz <= BUILDING.ELEVATOR_MAX_Z &&
      Math.abs(py - this.currentY) < 0.7
    );
  }

  public update(delta: number, timeElapsed: number): number {
    const prevY = this.currentY;
    const doorSpeed = 1.35;
    const travelSpeed = 1.65;

    switch (this.state) {
      case 'idle': {
        if (this.powerEnabled) {
          this.cabinLight.intensity = 1.35 + Math.sin(timeElapsed * 4.2) * 0.04;
          this.cabinBulbMat.emissiveIntensity = 1.5;
        }
        break;
      }
      case 'closing': {
        this.doorsOpenAmount = Math.max(
          0,
          this.doorsOpenAmount - doorSpeed * delta,
        );
        this.syncDoorPositions();
        if (this.doorsOpenAmount <= 0) {
          this.state = 'moving';
          this.stallTriggered = false;
          this.sound.setElevatorMotor(true, 1.0);
        }
        break;
      }
      case 'moving': {
        const targetY = getFloorBaseY(this.targetFloor);
        const dir = Math.sign(targetY - this.currentY);
        const dist = Math.abs(targetY - this.currentY);

        if (
          !this.hasPlayedStallEvent &&
          !this.stallTriggered &&
          this.currentY > 3.9 &&
          this.currentY < 5.3 &&
          this.targetFloor >= 3
        ) {
          this.stallTriggered = true;
          this.hasPlayedStallEvent = true;
          this.state = 'stalled';
          this.stateTimer = 2.6;
          this.sound.setElevatorMotor(false);
          this.sound.playDistantBang(0.25);
          this.sound.playWhisper(-0.4, 0.85);
          this.onStallCutscene?.();
          break;
        }

        if (dist <= travelSpeed * delta) {
          this.currentY = targetY;
          this.currentFloor = this.targetFloor;
          this.sound.setElevatorMotor(false);
          this.sound.playElevatorChime();
          this.sound.playElevatorDoorSlide();
          this.state = 'opening';
          this.syncDisplays(this.currentFloor);
          const rig = this.floorRigs[this.currentFloor - 1];
          if (rig) rig.callLedMat.emissiveIntensity = 0;

          if (this.emergencyTripsLeft > 0) {
            this.emergencyTripsLeft -= 1;
            if (this.emergencyTripsLeft === 0 && this.hasPlayedStallEvent) {
              this.setPowerEnabled(false);
              this.onSubtitle?.(
                'Аварийный аккумулятор лифта сел. Запустите генератор в подвале.',
              );
            }
          }
        } else {
          this.currentY += dir * travelSpeed * delta;
          const approxFloor = Math.max(
            1,
            Math.min(
              BUILDING.FLOOR_COUNT,
              Math.round(this.currentY / BUILDING.FLOOR_HEIGHT) + 1,
            ),
          );
          if (approxFloor !== this.currentFloor) {
            this.currentFloor = approxFloor;
            this.syncDisplays(this.currentFloor);
          }
        }
        this.cabinLight.intensity = 1.25 + Math.sin(timeElapsed * 28) * 0.12;
        break;
      }
      case 'stalled': {
        this.stateTimer -= delta;
        const flicker = Math.sin(timeElapsed * 47) > 0.2 ? 0.25 : 1.4;
        this.cabinLight.intensity = flicker;
        this.cabinBulbMat.emissiveIntensity = flicker * 1.1;
        if (this.stateTimer <= 0) {
          this.state = 'moving';
          this.sound.setElevatorMotor(true, 1.05);
        }
        break;
      }
      case 'opening': {
        this.doorsOpenAmount = Math.min(
          1,
          this.doorsOpenAmount + doorSpeed * delta,
        );
        this.syncDoorPositions();
        if (this.doorsOpenAmount >= 1) {
          this.state = 'idle';
          this.buttonLedMats.forEach((mat, f) => {
            mat.emissiveIntensity = f === this.currentFloor ? 0.75 : 0;
          });
        }
        break;
      }
    }

    this.cabinGroup.position.y = this.currentY;
    this.syncCabinColliders();
    return this.currentY - prevY;
  }

  private syncCabinColliders(): void {
    const ch = BUILDING.ELEVATOR_CABIN_HEIGHT;
    for (const c of this.cabinColliders) {
      c.minY = this.currentY;
      c.maxY = this.currentY + ch;
    }
    this.innerDoorCollider.minY = this.currentY;
    this.innerDoorCollider.maxY = this.currentY + ch;
    this.innerDoorCollider.enabled = this.doorsOpenAmount < 0.75;
  }

  private syncDoorPositions(): void {
    const halfDoorW = BUILDING.ELEVATOR_DOOR_WIDTH / 2 + 0.02;
    const slideOffset = this.doorsOpenAmount * 0.62;

    this.cabinLeftDoor.position.x = -halfDoorW / 2 - slideOffset;
    this.cabinRightDoor.position.x = halfDoorW / 2 + slideOffset;

    for (const rig of this.floorRigs) {
      const isCabinHere =
        Math.abs(this.currentY - getFloorBaseY(rig.floor)) < 0.08 &&
        (this.state === 'idle' ||
          this.state === 'opening' ||
          this.state === 'closing');
      const openAmt = isCabinHere ? this.doorsOpenAmount : 0;
      const offset = openAmt * 0.62;
      rig.leftDoor.position.x =
        BUILDING.ELEVATOR_CENTER_X - halfDoorW / 2 - offset;
      rig.rightDoor.position.x =
        BUILDING.ELEVATOR_CENTER_X + halfDoorW / 2 + offset;
      rig.doorCollider.enabled = openAmt < 0.75;
    }
  }

  private syncDisplays(floor: number): void {
    const tex = this.numberTextures[floor - 1] ?? this.numberTextures[0];
    this.cabinFloorDisplayMat.map = tex;
    this.cabinFloorDisplayMat.emissiveMap = tex;
    this.cabinFloorDisplayMat.needsUpdate = true;
    for (const rig of this.floorRigs) {
      rig.displayMat.map = tex;
      rig.displayMat.emissiveMap = tex;
      rig.displayMat.needsUpdate = true;
    }
  }

  public dispose(): void {
    this.numberTextures.forEach((t) => t.dispose());
  }
}
