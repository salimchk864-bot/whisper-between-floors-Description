import * as THREE from 'three';
import { DIFFICULTY_PROFILES, getFloorBaseY } from './BuildingConfig';
import { DifficultyLevel, MonsterState } from '../types';
import { SoundEngine } from '../audio/SoundEngine';
import { CollisionWorld } from '../engine/CollisionWorld';
import { MaterialLibrary } from './MaterialLibrary';

export interface NavEdge {
  to: string;
  doorId?: string;
}

export interface NavNode {
  id: string;
  pos: THREE.Vector3;
  edges: NavEdge[];
  floor: number;
}

export interface HidingCheckZone {
  id: string;
  name: string;
  spotPos: THREE.Vector3;
}

export interface DoorNavBridge {
  id: string;
  pos: THREE.Vector3;
  isOpen: () => boolean;
  isLocked: () => boolean;
  forceOpen: () => void;
}

const MONSTER_RADIUS = 0.33;
const MONSTER_HEIGHT = 1.92;

const _dir = new THREE.Vector3();
const _rayOrigin = new THREE.Vector3();
const _rayTarget = new THREE.Vector3();
const _toPlayer = new THREE.Vector3();
const _probeDir = new THREE.Vector3();

export class MonsterAI {
  public group = new THREE.Group();
  public state: MonsterState = 'PATROL';
  public position = new THREE.Vector3(-1.8, getFloorBaseY(4), -0.3);
  public currentDistance = 20;

  private nodes = new Map<string, NavNode>();
  private doorBridges = new Map<string, DoorNavBridge>();
  private patrolPool: string[] = [];
  private currentPath: string[] = [];
  private targetNodeId: string | null = null;
  private lastKnownPlayerPos: THREE.Vector3 | null = null;

  public isWindingUp = false;
  public dangerLevel = 0;

  private stateTimer = 0;
  private observeTimer = 0;
  private stepAccum = 0;
  private attackCooldown = 0;
  private attackWindupTimer = 0;
  private chaseMomentum = 0;
  private wasChasingPlayer = false;
  private patrolBias = 0;
  private doorPoundTimer = 0;
  private poundingDoorId: string | null = null;
  private searchChecksLeft = 0;
  private checkedHideIds = new Set<string>();
  private sawPlayerHideId: string | null = null;
  private alertedOnce = false;
  private verticalVel = 0;

  // Emergence from darkness animation state
  private emergeProgress = 1;
  private wasInDarkness = true;
  private speedScale = 1.0;
  private sightScale = 1.0;
  private damageScale = 1.0;
  private isNewGamePlus = false;

  // Articulated rig pivots
  private pelvisGroup = new THREE.Group();
  private spinePivot = new THREE.Group();
  private neckPivot = new THREE.Group();
  private leftShoulder = new THREE.Group();
  private leftElbow = new THREE.Group();
  private rightShoulder = new THREE.Group();
  private rightElbow = new THREE.Group();
  private leftHip = new THREE.Group();
  private leftKnee = new THREE.Group();
  private rightHip = new THREE.Group();
  private rightKnee = new THREE.Group();
  private coatLeftFlap!: THREE.Mesh;
  private coatRightFlap!: THREE.Mesh;

  // Smoothed locomotion variables
  private walkCycle = 0;
  private smoothedMoveSpeed = 0;

  private raycaster = new THREE.Raycaster();
  private geos: THREE.BufferGeometry[] = [];
  private localMats: THREE.Material[] = [];

  constructor(
    scene: THREE.Scene,
    private mats: MaterialLibrary,
    private collision: CollisionWorld,
    private sound: SoundEngine,
    private callbacks: {
      onPlayerHit: (damage: number, pullOutFromHide: boolean) => void;
      onFirstSighting: () => void;
      onSpottedPlayer?: () => void;
      onEscapedChase: () => void;
      onSubtitle: (msg: string) => void;
    },
  ) {
    this.buildDetailedModel();
    this.buildNavGraph();
    this.validateSpawnPosition();
    this.group.position.copy(this.position);
    scene.add(this.group);
    this.pickNextPatrolRoute();
  }

  public setDifficulty(diff: DifficultyLevel, isNewGamePlus = false): void {
    const profile = DIFFICULTY_PROFILES[diff];
    this.speedScale = profile.monsterSpeedScale;
    this.sightScale = profile.monsterSightScale;
    this.damageScale = profile.monsterDamageScale;
    this.isNewGamePlus = isNewGamePlus;
  }

  public configureNight(startFloor: number, patrolBias: number): void {
    this.patrolBias = patrolBias;
    const clampedFloor = Math.max(1, Math.min(5, startFloor));
    this.position.set(-1.8, getFloorBaseY(clampedFloor), -0.3);
    this.state = 'PATROL';
    this.stateTimer = 0;
    this.attackCooldown = 0;
    this.attackWindupTimer = 0;
    this.isWindingUp = false;
    this.chaseMomentum = 0;
    this.wasChasingPlayer = false;
    this.lastKnownPlayerPos = null;
    this.sawPlayerHideId = null;
    this.poundingDoorId = null;
    this.doorPoundTimer = 0;
    this.validateSpawnPosition();
    this.group.position.copy(this.position);
    this.pickNextPatrolRoute();
  }

  public registerDoorBridge(bridge: DoorNavBridge): void {
    this.doorBridges.set(bridge.id, bridge);
  }

  public linkApartmentDoorEdge(
    corridorNodeId: string,
    roomNodeId: string,
    roomPos: THREE.Vector3,
    floor: number,
    doorId: string,
    addToPatrol = true,
  ): void {
    if (!this.nodes.has(roomNodeId)) {
      this.addNode(roomNodeId, roomPos.x, roomPos.y, roomPos.z, floor);
    }
    this.link(corridorNodeId, roomNodeId, doorId);
    if (addToPatrol && !this.patrolPool.includes(roomNodeId)) {
      this.patrolPool.push(roomNodeId);
    }
  }

  private trackGeo<T extends THREE.BufferGeometry>(g: T): T {
    this.geos.push(g);
    return g;
  }

  private buildDetailedModel(): void {
    // Use cloned coat/skin instances so emergence-from-darkness shading can smoothly fade contrast
    const coatMat = this.mats.monsterCoat.clone();
    const skinMat = this.mats.monsterSkin.clone();
    const faceMat = this.mats.monsterFace.clone();
    this.localMats.push(coatMat, skinMat, faceMat);

    // Root pelvis (grounded around y = 0.96)
    this.pelvisGroup.position.set(0, 0.96, 0);
    this.group.add(this.pelvisGroup);

    const pelvisMesh = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.32, 0.16, 0.2)),
      coatMat,
    );
    this.pelvisGroup.add(pelvisMesh);

    // Spine & hunched ribcage / tattered coat torso
    this.spinePivot.position.set(0, 0.08, 0);
    this.pelvisGroup.add(this.spinePivot);

    const torsoMesh = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.21, 0.16, 0.56, 12)),
      coatMat,
    );
    torsoMesh.scale.set(1.08, 1, 0.72);
    torsoMesh.position.set(0, 0.28, 0);
    torsoMesh.castShadow = true;
    this.spinePivot.add(torsoMesh);

    // Coat collar & hunched trapezius shoulders
    const shoulderBridge = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.48, 0.13, 0.22)),
      coatMat,
    );
    shoulderBridge.position.set(0, 0.52, 0.01);
    this.spinePivot.add(shoulderBridge);

    const collar = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.11, 0.14, 0.11, 10, 1, true)),
      coatMat,
    );
    collar.position.set(0, 0.59, 0.01);
    this.spinePivot.add(collar);

    // Coat lower flaps swinging with legs
    const flapGeo = this.trackGeo(new THREE.BoxGeometry(0.17, 0.46, 0.05));
    this.coatLeftFlap = new THREE.Mesh(flapGeo, coatMat);
    this.coatLeftFlap.position.set(-0.1, -0.22, -0.09);
    this.pelvisGroup.add(this.coatLeftFlap);

    this.coatRightFlap = new THREE.Mesh(flapGeo, coatMat);
    this.coatRightFlap.position.set(0.1, -0.22, -0.09);
    this.pelvisGroup.add(this.coatRightFlap);

    // Neck & realistic sculpted gaunt head
    this.neckPivot.position.set(0, 0.58, 0.04);
    this.spinePivot.add(this.neckPivot);

    const neckMesh = new THREE.Mesh(
      this.trackGeo(new THREE.CylinderGeometry(0.055, 0.068, 0.14, 8)),
      skinMat,
    );
    neckMesh.position.set(0, 0.05, 0.01);
    neckMesh.rotation.x = 0.22;
    this.neckPivot.add(neckMesh);

    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.17, 0.04);
    this.neckPivot.add(headGroup);

    const cranium = new THREE.Mesh(
      this.trackGeo(new THREE.SphereGeometry(0.118, 14, 14)),
      faceMat,
    );
    cranium.scale.set(0.84, 1.15, 0.96);
    cranium.rotation.y = -Math.PI / 2; // Align UV seam away from front (+Z)
    headGroup.add(cranium);

    const jaw = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.125, 0.11, 0.13)),
      skinMat,
    );
    jaw.position.set(0, -0.09, 0.02);
    headGroup.add(jaw);

    const brow = new THREE.Mesh(
      this.trackGeo(new THREE.BoxGeometry(0.155, 0.032, 0.06)),
      skinMat,
    );
    brow.position.set(0, 0.035, 0.09);
    headGroup.add(brow);

    const nose = new THREE.Mesh(
      this.trackGeo(new THREE.ConeGeometry(0.018, 0.06, 5)),
      skinMat,
    );
    nose.rotation.x = Math.PI * 0.42;
    nose.position.set(0, -0.01, 0.115);
    headGroup.add(nose);

    // Recessed realistic eyes (bloodshot sclera + dark iris/pupil)
    const scleraGeo = this.trackGeo(new THREE.SphereGeometry(0.017, 8, 8));
    const pupilGeo = this.trackGeo(new THREE.SphereGeometry(0.0085, 6, 6));
    for (const ex of [-0.036, 0.036]) {
      const eyeBall = new THREE.Mesh(scleraGeo, this.mats.monsterSclera);
      eyeBall.position.set(ex, 0.012, 0.095);
      const pupil = new THREE.Mesh(pupilGeo, this.mats.monsterPupil);
      pupil.position.set(0, 0, 0.012);
      eyeBall.add(pupil);
      headGroup.add(eyeBall);
    }

    // Articulated Arms (Upper Arm -> Elbow -> Forearm -> Clawed Hand)
    const upperArmGeo = this.trackGeo(new THREE.CylinderGeometry(0.052, 0.042, 0.36, 8));
    const forearmGeo = this.trackGeo(new THREE.CylinderGeometry(0.038, 0.028, 0.36, 8));
    const palmGeo = this.trackGeo(new THREE.BoxGeometry(0.055, 0.09, 0.038));
    const fingerGeo = this.trackGeo(new THREE.CylinderGeometry(0.007, 0.003, 0.09, 5));

    const buildArm = (
      side: -1 | 1,
      shoulderPivot: THREE.Group,
      elbowPivot: THREE.Group,
    ) => {
      shoulderPivot.position.set(side * 0.24, 0.5, 0.01);
      this.spinePivot.add(shoulderPivot);

      const upper = new THREE.Mesh(upperArmGeo, coatMat);
      upper.position.set(0, -0.18, 0);
      shoulderPivot.add(upper);

      elbowPivot.position.set(0, -0.35, 0);
      shoulderPivot.add(elbowPivot);

      const forearm = new THREE.Mesh(forearmGeo, skinMat);
      forearm.position.set(0, -0.18, 0);
      elbowPivot.add(forearm);

      const hand = new THREE.Mesh(palmGeo, skinMat);
      hand.position.set(0, -0.39, 0.01);
      elbowPivot.add(hand);

      for (let f = -1; f <= 1; f++) {
        const finger = new THREE.Mesh(fingerGeo, skinMat);
        finger.position.set(f * 0.016, -0.075, 0.012);
        finger.rotation.x = 0.25;
        hand.add(finger);
      }
    };

    buildArm(-1, this.leftShoulder, this.leftElbow);
    buildArm(1, this.rightShoulder, this.rightElbow);

    // Articulated Legs (Thigh -> Knee -> Shin -> Boot)
    const thighGeo = this.trackGeo(new THREE.CylinderGeometry(0.074, 0.058, 0.48, 8));
    const shinGeo = this.trackGeo(new THREE.CylinderGeometry(0.054, 0.04, 0.46, 8));
    const bootGeo = this.trackGeo(new THREE.BoxGeometry(0.095, 0.08, 0.22));

    const buildLeg = (
      side: -1 | 1,
      hipPivot: THREE.Group,
      kneePivot: THREE.Group,
    ) => {
      hipPivot.position.set(side * 0.11, 0, 0);
      this.pelvisGroup.add(hipPivot);

      const thigh = new THREE.Mesh(thighGeo, coatMat);
      thigh.position.set(0, -0.24, 0);
      hipPivot.add(thigh);

      kneePivot.position.set(0, -0.47, 0);
      hipPivot.add(kneePivot);

      const shin = new THREE.Mesh(shinGeo, coatMat);
      shin.position.set(0, -0.23, 0);
      kneePivot.add(shin);

      const boot = new THREE.Mesh(bootGeo, this.mats.monsterBoots);
      boot.position.set(0, -0.45, 0.05);
      kneePivot.add(boot);
    };

    buildLeg(-1, this.leftHip, this.leftKnee);
    buildLeg(1, this.rightHip, this.rightKnee);
  }

  private addNode(
    id: string,
    x: number,
    y: number,
    z: number,
    floor: number,
  ): void {
    this.nodes.set(id, {
      id,
      pos: new THREE.Vector3(x, y, z),
      edges: [],
      floor,
    });
  }

  private link(a: string, b: string, doorId?: string): void {
    const na = this.nodes.get(a);
    const nb = this.nodes.get(b);
    if (na && nb) {
      if (!na.edges.some((e) => e.to === b)) na.edges.push({ to: b, doorId });
      if (!nb.edges.some((e) => e.to === a)) nb.edges.push({ to: a, doorId });
    }
  }

  private buildNavGraph(): void {
    // Basement (Floor 0)
    const y0 = getFloorBaseY(0);
    this.addNode('f0_stair_bot', 0.35, y0, 1.1, 0);
    this.addNode('f0_lobby', -1.8, y0, -0.3, 0);
    this.addNode('f0_switch_door', 1.25, y0, -0.25, 0);
    this.addNode('f0_east', 2.45, y0, -0.25, 0);
    this.link('f0_stair_bot', 'f0_lobby');
    this.link('f0_lobby', 'f0_switch_door');
    this.link('f0_switch_door', 'f0_east');

    // Half-landing Basement <-> Floor 1
    this.addNode('h0_mid', -0.7, y0 + 1.6, 5.1, 0);
    this.link('f0_stair_bot', 'h0_mid');

    // Residential floors 1..5
    for (let f = 1; f <= 5; f++) {
      const y = getFloorBaseY(f);
      this.addNode(`f${f}_lobby`, -1.8, y, -0.3, f);
      this.addNode(`f${f}_stair_entry`, 0.35, y, 1.0, f);
      this.addNode(`f${f}_east`, 3.3, y, -0.3, f);
      this.addNode(`f${f}_east_edge`, 4.45, y, -0.3, f);
      this.link(`f${f}_lobby`, `f${f}_stair_entry`);
      this.link(`f${f}_stair_entry`, `f${f}_east`);
      this.link(`f${f}_lobby`, `f${f}_east`);
      this.link(`f${f}_east`, `f${f}_east_edge`);

      if (f === 1) {
        this.link('h0_mid', 'f1_lobby', 'door_basement');
      }

      if (f < 6) {
        this.addNode(`h${f}_mid`, -0.7, y + 1.6, 5.1, f);
        this.link(`f${f}_stair_entry`, `h${f}_mid`);
      }

      if (f > 1) {
        this.link(`h${f - 1}_mid`, `f${f}_lobby`);
      }

      if (f >= 2 && f <= 5) {
        this.patrolPool.push(`f${f}_east`, `f${f}_lobby`);
      }
    }

    // Attic (Floor 6) behind door_attic
    const y6 = getFloorBaseY(6);
    this.addNode('f6_lobby', -1.8, y6, -0.3, 6);
    this.addNode('f6_east', 3.0, y6, -0.3, 6);
    this.link('h5_mid', 'f6_lobby', 'door_attic');
    this.link('f6_lobby', 'f6_east');

    this.patrolPool.push('f0_lobby');
  }

  private validateSpawnPosition(): void {
    const res = this.collision.resolveHorizontal(
      this.position.x,
      this.position.z,
      this.position.y,
      MONSTER_HEIGHT,
      MONSTER_RADIUS,
    );
    this.position.x = res.x;
    this.position.z = res.z;
    const hit = this.collision.sampleFloor(
      this.position.x,
      this.position.z,
      this.position.y,
    );
    if (hit) this.position.y = hit.y;
  }

  public notifyNoise(worldPos: THREE.Vector3, radius: number): void {
    const dist = this.position.distanceTo(worldPos);
    if (dist > radius) return;
    if (this.state === 'CHASE') {
      this.lastKnownPlayerPos = worldPos.clone();
      return;
    }
    this.lastKnownPlayerPos = worldPos.clone();
    this.state = 'SUSPICIOUS';
    this.stateTimer = 7.5;
    this.pathToWorldPos(worldPos, true);
  }

  public notifyPlayerEnteredHide(spotId: string, playerPos: THREE.Vector3): void {
    // Monster only knows hiding spot if actively chasing close-by on the same floor
    if (
      this.state === 'CHASE' &&
      Math.abs(this.position.y - playerPos.y) < 1.8 &&
      this.position.distanceTo(playerPos) < 8.5
    ) {
      this.sawPlayerHideId = spotId;
    }
  }

  private findClosestNode(pos: THREE.Vector3): string {
    let bestId = 'f3_lobby';
    let bestDist = Infinity;
    this.nodes.forEach((n) => {
      const dy = Math.abs(n.pos.y - pos.y);
      const d = n.pos.distanceTo(pos) + dy * 1.45;
      if (d < bestDist) {
        bestDist = d;
        bestId = n.id;
      }
    });
    return bestId;
  }

  private isEdgeTraversable(edge: NavEdge, allowClosedUnlocked: boolean): boolean {
    if (!edge.doorId) return true;
    const bridge = this.doorBridges.get(edge.doorId);
    if (!bridge) return true;
    if (bridge.isOpen()) return true;
    if (!allowClosedUnlocked) return false;
    return !bridge.isLocked();
  }

  private computeBfsPath(
    startId: string,
    goalId: string,
    allowClosedUnlocked: boolean,
  ): string[] {
    if (startId === goalId) return [goalId];
    const queue: string[] = [startId];
    const visited = new Set<string>([startId]);
    const parent = new Map<string, string>();

    while (queue.length > 0) {
      const curr = queue.shift()!;
      if (curr === goalId) {
        const path: string[] = [];
        let p: string | undefined = goalId;
        while (p) {
          path.unshift(p);
          p = parent.get(p);
        }
        return path;
      }
      const node = this.nodes.get(curr);
      if (!node) continue;
      for (const edge of node.edges) {
        if (!visited.has(edge.to) && this.isEdgeTraversable(edge, allowClosedUnlocked)) {
          visited.add(edge.to);
          parent.set(edge.to, curr);
          queue.push(edge.to);
        }
      }
    }
    return [];
  }

  private pathToWorldPos(target: THREE.Vector3, allowClosedUnlocked: boolean): void {
    const startId = this.findClosestNode(this.position);
    const goalId = this.findClosestNode(target);
    this.currentPath = this.computeBfsPath(startId, goalId, allowClosedUnlocked);
    this.targetNodeId = this.currentPath.shift() ?? null;
  }

  private pickNextPatrolRoute(): void {
    const startId = this.findClosestNode(this.position);
    for (let tries = 0; tries < 6; tries++) {
      const idx =
        (Math.floor(Math.random() * this.patrolPool.length) +
          (tries === 0 ? this.patrolBias : 0)) %
        Math.max(1, this.patrolPool.length);
      const goal = this.patrolPool[idx] ?? 'f3_lobby';
      const path = this.computeBfsPath(startId, goal, false);
      if (path.length > 0) {
        this.currentPath = path;
        this.targetNodeId = this.currentPath.shift() ?? null;
        return;
      }
    }
    this.currentPath = [];
    this.targetNodeId = null;
  }

  private canSeePlayer(
    playerPos: THREE.Vector3,
    flashlightOn: boolean,
    crouching: boolean,
    isHiding: boolean,
    occlusionMeshes: THREE.Object3D[],
  ): boolean {
    if (isHiding && !flashlightOn) return false;
    const dist = this.position.distanceTo(playerPos);
    const baseSight = flashlightOn ? 14.0 : crouching ? 4.5 : 7.5;
    const maxSight = baseSight * this.sightScale;
    if (dist > maxSight) return false;
    if (Math.abs(this.position.y - playerPos.y) > 2.2) return false;

    _rayOrigin.set(this.position.x, this.position.y + 1.65, this.position.z);
    _rayTarget.set(playerPos.x, playerPos.y + (crouching ? 0.85 : 1.25), playerPos.z);
    _toPlayer.subVectors(_rayTarget, _rayOrigin).normalize();

    if (dist > 2.5 && !flashlightOn) {
      _dir.set(0, 0, 1).applyQuaternion(this.group.quaternion);
      if (_dir.dot(_toPlayer) < 0.14) return false;
    }

    this.raycaster.set(_rayOrigin, _toPlayer);
    this.raycaster.far = dist;
    const hits = this.raycaster.intersectObjects(occlusionMeshes, false);
    return hits.length === 0;
  }

  private findBlockingClosedDoorNear(pos: THREE.Vector3): DoorNavBridge | null {
    let closest: DoorNavBridge | null = null;
    let bestD = 1.28;
    this.doorBridges.forEach((b) => {
      if (b.isOpen()) return;
      if (Math.abs(b.pos.y - pos.y) > 1.5) return;
      const d = Math.hypot(b.pos.x - pos.x, b.pos.z - pos.z);
      if (d < bestD) {
        bestD = d;
        closest = b;
      }
    });
    return closest;
  }

  private moveWithCollision(
    target: THREE.Vector3,
    speed: number,
    dt: number,
    playerPos: THREE.Vector3,
  ): void {
    _dir.set(target.x - this.position.x, 0, target.z - this.position.z);
    const horizDist = _dir.length();
    if (horizDist < 0.04) return;

    _dir.normalize();
    const desiredStep = Math.min(horizDist, speed * dt);

    // Try direct step first
    let nextX = this.position.x + _dir.x * desiredStep;
    let nextZ = this.position.z + _dir.z * desiredStep;
    let resolved = this.collision.resolveHorizontal(
      nextX,
      nextZ,
      this.position.y,
      MONSTER_HEIGHT,
      MONSTER_RADIUS,
    );

    let movedX = resolved.x - this.position.x;
    let movedZ = resolved.z - this.position.z;
    let actualMoved = Math.hypot(movedX, movedZ);

    // Steering around furniture/corners if direct movement is blocked
    if (actualMoved < desiredStep * 0.42) {
      // Check if blocked specifically by a closed door
      const closedDoor = this.findBlockingClosedDoorNear(this.position);
      if (closedDoor) {
        if (closedDoor.isLocked()) {
          // Cannot pass locked doors: pound once and pick another route
          if (this.poundingDoorId !== closedDoor.id) {
            this.poundingDoorId = closedDoor.id;
            this.sound.playDoorPound(
              this.currentDistance,
              this.computeStereoPan(playerPos),
            );
            this.state = 'SEARCH';
            this.stateTimer = 4.5;
            this.pickNextPatrolRoute();
          }
          return;
        }

        // Unlocked closed door: monster pounds on it for 1.6s before forcing open
        if (this.poundingDoorId !== closedDoor.id) {
          this.poundingDoorId = closedDoor.id;
          this.doorPoundTimer = 1.6;
          this.sound.playDoorPound(
            this.currentDistance,
            this.computeStereoPan(playerPos),
          );
          if (this.currentDistance < 12) {
            this.callbacks.onSubtitle('Оно с силой бьёт в закрытую дверь!');
          }
          return;
        }
        return;
      }

      // Probe angled steering directions around solid obstacles (tables/beds/walls)
      const baseAngle = Math.atan2(_dir.x, _dir.z);
      const offsets = [0.75, -0.75, 1.35, -1.35];
      let bestProgress = actualMoved;
      let bestX = resolved.x;
      let bestZ = resolved.z;

      for (const angOff of offsets) {
        const a = baseAngle + angOff;
        _probeDir.set(Math.sin(a), 0, Math.cos(a));
        const px = this.position.x + _probeDir.x * desiredStep;
        const pz = this.position.z + _probeDir.z * desiredStep;
        const probeRes = this.collision.resolveHorizontal(
          px,
          pz,
          this.position.y,
          MONSTER_HEIGHT,
          MONSTER_RADIUS,
        );
        const pDist = Math.hypot(
          probeRes.x - this.position.x,
          probeRes.z - this.position.z,
        );
        if (pDist > bestProgress + 0.002) {
          bestProgress = pDist;
          bestX = probeRes.x;
          bestZ = probeRes.z;
        }
      }

      resolved.x = bestX;
      resolved.z = bestZ;
      actualMoved = bestProgress;
    } else {
      this.poundingDoorId = null;
    }

    this.position.x = resolved.x;
    this.position.z = resolved.z;

    if (actualMoved > 0.002) {
      this.faceToward(target, dt);
      this.stepAccum += actualMoved;
      if (this.stepAccum > 0.78) {
        this.stepAccum = 0;
        this.sound.playMonsterFootstep(
          this.currentDistance,
          this.computeStereoPan(playerPos),
        );
      }
    }
  }

  private applyVerticalGrounding(dt: number): void {
    const floorHit = this.collision.sampleFloor(
      this.position.x,
      this.position.z,
      this.position.y,
    );
    if (floorHit) {
      const diff = floorHit.y - this.position.y;
      if (diff >= -0.35) {
        this.position.y = THREE.MathUtils.damp(this.position.y, floorHit.y, 16, dt);
        this.verticalVel = 0;
      } else {
        this.verticalVel -= 15 * dt;
        this.position.y += this.verticalVel * dt;
        if (this.position.y <= floorHit.y) {
          this.position.y = floorHit.y;
          this.verticalVel = 0;
        }
      }
    } else {
      this.verticalVel -= 15 * dt;
      this.position.y = Math.max(getFloorBaseY(0), this.position.y + this.verticalVel * dt);
    }
  }

  public update(
    delta: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    playerNoise: number,
    flashlightOn: boolean,
    crouching: boolean,
    hidingSpotId: string | null,
    hidingZones: HidingCheckZone[],
    occlusionMeshes: THREE.Object3D[],
    playerInvulnerable = false,
  ): void {
    const dt = Math.min(delta, 0.05);
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.currentDistance = this.position.distanceTo(playerPos);

    // Compute fair HUD danger level (0..1)
    const distFactor = Math.max(0, 1 - this.currentDistance / 13.5);
    const stateBoost =
      this.state === 'CHASE'
        ? 0.45
        : this.state === 'SEARCH' || this.state === 'SUSPICIOUS'
          ? 0.2
          : 0;
    this.dangerLevel = THREE.MathUtils.clamp(
      distFactor * 0.72 + stateBoost,
      0,
      1,
    );

    // Handle active door pounding countdown before movement
    if (this.poundingDoorId && this.doorPoundTimer > 0) {
      this.doorPoundTimer -= dt;
      if (this.doorPoundTimer <= 0) {
        const door = this.doorBridges.get(this.poundingDoorId);
        if (door && !door.isLocked() && !door.isOpen()) {
          door.forceOpen();
          this.sound.playDoorCreak();
        }
        this.poundingDoorId = null;
      }
      this.animateRig(0, elapsed, dt);
      return;
    }

    // Continuous hearing check
    const hearRange = (playerNoise / 100) * 14.5;
    const hearsPlayer =
      playerNoise > 24 &&
      this.currentDistance <= hearRange &&
      Math.abs(this.position.y - playerPos.y) < 3.6;

    const seesPlayer = this.canSeePlayer(
      playerPos,
      flashlightOn,
      crouching,
      Boolean(hidingSpotId),
      occlusionMeshes,
    );

    // Emergence from darkness trigger
    if (this.currentDistance > 14.0 || (!seesPlayer && this.currentDistance > 11.5)) {
      this.wasInDarkness = true;
    }
    if (seesPlayer && this.wasInDarkness) {
      this.wasInDarkness = false;
      this.emergeProgress = 0;
    }
    this.emergeProgress = Math.min(1, this.emergeProgress + dt * 0.85);

    if (seesPlayer) {
      this.callbacks.onSpottedPlayer?.();
      if (!this.alertedOnce && this.currentDistance < 12.5) {
        this.alertedOnce = true;
        this.callbacks.onFirstSighting();
      }

      if (this.state !== 'CHASE') {
        if (
          this.currentDistance > 8.5 &&
          playerNoise < 40 &&
          this.observeTimer <= 0 &&
          Math.random() < 0.35
        ) {
          this.observeTimer = 2.5;
          this.state = 'IDLE';
          this.stateTimer = 2.4;
        } else {
          this.state = 'CHASE';
          this.chaseMomentum = 0;
          this.wasChasingPlayer = true;
          this.sound.playMonsterAlert();
          this.callbacks.onSubtitle('Оно заметило вас! Бегите или прячьтесь!');
        }
      }
      this.lastKnownPlayerPos = playerPos.clone();
    } else if (hearsPlayer && this.state !== 'CHASE') {
      this.lastKnownPlayerPos = playerPos.clone();
      if (this.state !== 'SUSPICIOUS') {
        this.state = 'SUSPICIOUS';
        this.stateTimer = 7.0;
        this.pathToWorldPos(playerPos, true);
      }
    }

    if (this.observeTimer > 0) this.observeTimer -= dt;

    let moveSpeed = 1.65;
    let moveTarget: THREE.Vector3 | null = null;

    switch (this.state) {
      case 'IDLE': {
        moveSpeed = 0;
        this.attackWindupTimer = 0;
        this.isWindingUp = false;
        this.stateTimer -= dt;
        this.faceToward(playerPos, dt);
        if (this.stateTimer <= 0) {
          this.state = 'PATROL';
          this.pickNextPatrolRoute();
        }
        break;
      }

      case 'PATROL':
      case 'RETURN_PATROL': {
        moveSpeed = 1.68 * (this.isNewGamePlus ? 1.06 : 1.0) * this.speedScale;
        this.attackWindupTimer = 0;
        this.isWindingUp = false;
        this.chaseMomentum = Math.max(0, this.chaseMomentum - dt * 0.5);
        moveTarget = this.advancePathTarget();
        if (!moveTarget) {
          this.state = 'IDLE';
          this.stateTimer = 1.8 + Math.random() * 2.2;
        }
        break;
      }

      case 'SUSPICIOUS': {
        moveSpeed = 2.15 * this.speedScale;
        this.attackWindupTimer = 0;
        this.isWindingUp = false;
        this.stateTimer -= dt;
        moveTarget = this.advancePathTarget();
        if (!moveTarget || this.stateTimer <= 0) {
          this.state = 'SEARCH';
          this.stateTimer = 7.5;
          this.searchChecksLeft = this.isNewGamePlus ? 3 : 2;
          this.checkedHideIds.clear();
        }
        break;
      }

      case 'CHASE': {
        // Gradual acceleration during pursuit; always remains slower than player burst sprint (5.4 m/s)
        this.chaseMomentum = Math.min(1, this.chaseMomentum + dt * 0.22);
        moveSpeed = Math.min(4.45, (2.75 + this.chaseMomentum * 1.15) * this.speedScale);

        if (this.attackWindupTimer > 0) {
          this.attackWindupTimer -= dt;
          this.isWindingUp = true;
          moveSpeed = 0.85; // Monster slows during telegraph so player can dodge or sprint away
          moveTarget = playerPos;
          this.faceToward(playerPos, dt * 1.5);

          if (this.attackWindupTimer <= 0) {
            this.isWindingUp = false;
            const canReach =
              !playerInvulnerable &&
              seesPlayer &&
              this.currentDistance <= 1.48 &&
              Math.abs(this.position.y - playerPos.y) < 1.35;
            if (canReach) {
              this.attackCooldown = 4.2;
              this.callbacks.onPlayerHit(
                Math.round(30 * this.damageScale),
                Boolean(hidingSpotId),
              );
              this.sound.playMonsterAlert();
            } else {
              this.attackCooldown = 1.8;
              this.callbacks.onSubtitle('Вы увернулись от выпада!');
            }
          }
          break;
        }

        if (seesPlayer) {
          moveTarget = playerPos;
        } else if (this.lastKnownPlayerPos) {
          const dLast = this.position.distanceTo(this.lastKnownPlayerPos);
          if (dLast > 0.9) {
            if (!this.targetNodeId) {
              this.pathToWorldPos(this.lastKnownPlayerPos, true);
            }
            moveTarget = this.advancePathTarget() ?? this.lastKnownPlayerPos;
          } else {
            this.state = 'LOST_TARGET';
            this.stateTimer = 2.0;
          }
        } else {
          this.state = 'LOST_TARGET';
          this.stateTimer = 2.0;
        }

        if (
          seesPlayer &&
          !playerInvulnerable &&
          this.currentDistance < 1.36 &&
          Math.abs(this.position.y - playerPos.y) < 1.35 &&
          this.attackCooldown <= 0
        ) {
          this.attackWindupTimer = 0.58;
          this.isWindingUp = true;
          this.sound.playAttackWindup(this.computeStereoPan(playerPos));
        }
        break;
      }

      case 'LOST_TARGET': {
        moveSpeed = 0;
        this.attackWindupTimer = 0;
        this.isWindingUp = false;
        this.stateTimer -= dt;
        if (this.stateTimer <= 0) {
          this.state = 'SEARCH';
          this.stateTimer = 7.5;
          this.searchChecksLeft = 2;
          this.checkedHideIds.clear();
        }
        break;
      }

      case 'SEARCH': {
        moveSpeed = 1.95;
        this.attackWindupTimer = 0;
        this.isWindingUp = false;
        this.stateTimer -= dt;

        // Only searches nearby unblocked spots on same floor; never knows hidden spot automatically
        const candidate = hidingZones.find(
          (hz) =>
            !this.checkedHideIds.has(hz.id) &&
            hz.spotPos.distanceTo(this.position) < 5.2 &&
            Math.abs(hz.spotPos.y - this.position.y) < 1.5,
        );

        if (candidate && this.searchChecksLeft > 0) {
          moveTarget = candidate.spotPos;
          if (this.position.distanceTo(candidate.spotPos) < 1.15) {
            this.checkedHideIds.add(candidate.id);
            this.searchChecksLeft -= 1;
            this.sound.playDoorCreak();

            if (
              hidingSpotId === candidate.id &&
              (this.sawPlayerHideId === candidate.id || flashlightOn)
            ) {
              this.sawPlayerHideId = null;
              this.attackCooldown = 4.2;
              this.callbacks.onPlayerHit(30, true);
              this.state = 'CHASE';
            } else if (hidingSpotId === candidate.id) {
              this.sound.playWhisper(0, 0.9);
              this.callbacks.onSubtitle(
                'Существо заглянуло в укрытие, прислушалось... и отступило.',
              );
            }
          }
        } else {
          moveTarget = this.advancePathTarget();
        }

        if (this.stateTimer <= 0) {
          this.sawPlayerHideId = null;
          if (this.wasChasingPlayer) {
            this.wasChasingPlayer = false;
            this.callbacks.onEscapedChase();
          }
          this.state = 'RETURN_PATROL';
          this.pickNextPatrolRoute();
        }
        break;
      }
    }

    if (moveTarget && moveSpeed > 0) {
      this.moveWithCollision(moveTarget, moveSpeed, dt, playerPos);
    }

    this.applyVerticalGrounding(dt);
    this.animateRig(moveTarget ? moveSpeed : 0, elapsed, dt);
    this.group.position.copy(this.position);
  }

  private animateRig(targetSpeed: number, elapsed: number, dt: number): void {
    this.smoothedMoveSpeed = THREE.MathUtils.damp(
      this.smoothedMoveSpeed,
      targetSpeed,
      8,
      dt,
    );

    const speedNorm = Math.min(1, this.smoothedMoveSpeed / 3.5);
    const freq = this.state === 'CHASE' ? 9.5 : 5.2;
    if (speedNorm > 0.05) {
      this.walkCycle += dt * freq * (0.45 + speedNorm * 0.75);
    }

    const stride = Math.sin(this.walkCycle) * (0.12 + speedNorm * 0.45);
    const cosStride = Math.cos(this.walkCycle);

    // Emergence crouch-rise factor (0 = deeply hunched in shadow -> 1 = stalker posture)
    const crouchEmerge = (1 - this.emergeProgress) * 0.45;

    // Pelvis vertical bob + subtle limp asymmetry
    this.pelvisGroup.position.y =
      0.95 - crouchEmerge * 0.28 + Math.abs(cosStride) * 0.035 * speedNorm;
    this.pelvisGroup.rotation.z = Math.sin(this.walkCycle) * 0.045 * speedNorm;

    // Hunched spine lean
    const targetSpinePitch =
      this.state === 'CHASE'
        ? 0.34
        : this.state === 'SUSPICIOUS'
          ? 0.38
          : 0.18 + crouchEmerge;
    this.spinePivot.rotation.x = THREE.MathUtils.damp(
      this.spinePivot.rotation.x,
      targetSpinePitch,
      7,
      dt,
    );
    this.spinePivot.rotation.y = Math.sin(this.walkCycle) * 0.08 * speedNorm;

    // Eerie head scan & twitch
    const headScanYaw =
      this.state === 'LOST_TARGET' || this.state === 'SEARCH'
        ? Math.sin(elapsed * 2.8) * 0.55
        : this.state === 'IDLE'
          ? Math.sin(elapsed * 1.4) * 0.32
          : Math.sin(elapsed * 1.1) * 0.09;
    const headTiltZ =
      this.state === 'SUSPICIOUS'
        ? 0.24
        : Math.sin(elapsed * 2.1) * 0.08;
    this.neckPivot.rotation.y = THREE.MathUtils.damp(
      this.neckPivot.rotation.y,
      headScanYaw,
      6,
      dt,
    );
    this.neckPivot.rotation.z = THREE.MathUtils.damp(
      this.neckPivot.rotation.z,
      headTiltZ,
      6,
      dt,
    );
    this.neckPivot.rotation.x = -this.spinePivot.rotation.x * 0.65;

    // Legs & knees
    this.leftHip.rotation.x = stride;
    this.rightHip.rotation.x = -stride;
    this.leftKnee.rotation.x = Math.max(0, -stride * 1.15);
    this.rightKnee.rotation.x = Math.max(0, stride * 1.15);

    // Coat flaps trail leg motion
    this.coatLeftFlap.rotation.x = Math.max(-0.35, stride * 0.55 - 0.08);
    this.coatRightFlap.rotation.x = Math.max(-0.35, -stride * 0.55 - 0.08);

    // Arms & reaching / attack windup telegraph pose
    if (this.isWindingUp) {
      this.leftShoulder.rotation.x = THREE.MathUtils.damp(
        this.leftShoulder.rotation.x,
        -2.05,
        14,
        dt,
      );
      this.rightShoulder.rotation.x = THREE.MathUtils.damp(
        this.rightShoulder.rotation.x,
        -2.05,
        14,
        dt,
      );
      this.leftElbow.rotation.x = -0.35;
      this.rightElbow.rotation.x = -0.35;
    } else if (this.state === 'CHASE') {
      this.leftShoulder.rotation.x = THREE.MathUtils.damp(
        this.leftShoulder.rotation.x,
        -0.95 - stride * 0.35,
        8,
        dt,
      );
      this.rightShoulder.rotation.x = THREE.MathUtils.damp(
        this.rightShoulder.rotation.x,
        -0.95 + stride * 0.35,
        8,
        dt,
      );
      this.leftElbow.rotation.x = -0.65;
      this.rightElbow.rotation.x = -0.65;
    } else {
      this.leftShoulder.rotation.x = THREE.MathUtils.damp(
        this.leftShoulder.rotation.x,
        -stride * 0.65 + 0.08,
        7,
        dt,
      );
      this.rightShoulder.rotation.x = THREE.MathUtils.damp(
        this.rightShoulder.rotation.x,
        stride * 0.65 + 0.08,
        7,
        dt,
      );
      this.leftElbow.rotation.x = -0.28;
      this.rightElbow.rotation.x = -0.28;
    }

    // Darkness emergence contrast modulation
    const shade = 0.25 + this.emergeProgress * 0.75;
    this.localMats.forEach((m) => {
      const std = m as THREE.MeshStandardMaterial;
      if (std.color) std.color.setScalar(shade);
    });
  }

  private advancePathTarget(): THREE.Vector3 | null {
    if (!this.targetNodeId) {
      if (this.currentPath.length === 0) return null;
      this.targetNodeId = this.currentPath.shift()!;
    }
    const node = this.nodes.get(this.targetNodeId);
    if (!node) {
      this.targetNodeId = null;
      return null;
    }
    if (this.position.distanceTo(node.pos) < 0.48) {
      this.targetNodeId = this.currentPath.shift() ?? null;
      if (!this.targetNodeId) return null;
      return this.nodes.get(this.targetNodeId)?.pos ?? null;
    }
    return node.pos;
  }

  private faceToward(target: THREE.Vector3, dt: number): void {
    const dx = target.x - this.position.x;
    const dz = target.z - this.position.z;
    if (dx * dx + dz * dz < 0.001) return;
    const targetYaw = Math.atan2(dx, dz);
    let diff = targetYaw - this.group.rotation.y;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    this.group.rotation.y += diff * Math.min(1, dt * 8);
  }

  private computeStereoPan(playerPos: THREE.Vector3): number {
    const dx = this.position.x - playerPos.x;
    return THREE.MathUtils.clamp(dx / 6, -0.9, 0.9);
  }

  public dispose(): void {
    this.geos.forEach((g) => g.dispose());
    this.localMats.forEach((m) => m.dispose());
  }
}
