import * as THREE from 'three';
import { CameraFeedInfo, MonsterState } from '../types';
import { getFloorBaseY, getFloorFromY } from './BuildingConfig';

interface InternalCameraDef {
  id: string;
  label: string;
  floor: number;
  pos: THREE.Vector3;
  yaw: number;
  offlineTimer: number;
  anomaly: CameraFeedInfo['anomaly'];
  anomalyTimer: number;
}

export class SecurityCameraSystem {
  private cameras: InternalCameraDef[] = [
    {
      id: 'cam_basement',
      label: 'CAM-01 · Подвал (щитовая)',
      floor: 0,
      pos: new THREE.Vector3(-4.0, getFloorBaseY(0) + 2.65, 1.35),
      yaw: -Math.PI * 0.65,
      offlineTimer: 0,
      anomaly: 'none',
      anomalyTimer: 0,
    },
    {
      id: 'cam_floor1',
      label: 'CAM-02 · 1 этаж (лифт и выход)',
      floor: 1,
      pos: new THREE.Vector3(4.95, getFloorBaseY(1) + 2.65, -1.9),
      yaw: Math.PI * 0.55,
      offlineTimer: 0,
      anomaly: 'none',
      anomalyTimer: 0,
    },
    {
      id: 'cam_floor3',
      label: 'CAM-03 · 3 этаж (коридор)',
      floor: 3,
      pos: new THREE.Vector3(-4.0, getFloorBaseY(3) + 2.65, 1.35),
      yaw: -Math.PI * 0.6,
      offlineTimer: 0,
      anomaly: 'none',
      anomalyTimer: 0,
    },
    {
      id: 'cam_floor4',
      label: 'CAM-04 · 4 этаж (у кв. №10)',
      floor: 4,
      pos: new THREE.Vector3(-4.0, getFloorBaseY(4) + 2.65, -1.9),
      yaw: -Math.PI * 0.35,
      offlineTimer: 0,
      anomaly: 'none',
      anomalyTimer: 0,
    },
    {
      id: 'cam_floor5',
      label: 'CAM-05 · 5 этаж (к чердаку)',
      floor: 5,
      pos: new THREE.Vector3(4.95, getFloorBaseY(5) + 2.65, 1.35),
      yaw: Math.PI * 0.72,
      offlineTimer: 0,
      anomaly: 'none',
      anomalyTimer: 0,
    },
  ];

  private eventAccum = 8;

  public reset(): void {
    this.eventAccum = 8;
    for (const cam of this.cameras) {
      cam.offlineTimer = 0;
      cam.anomaly = 'none';
      cam.anomalyTimer = 0;
    }
  }

  public getMountSpecs(): { pos: THREE.Vector3; yaw: number; floor: number }[] {
    return this.cameras.map((c) => ({ pos: c.pos, yaw: c.yaw, floor: c.floor }));
  }

  public update(delta: number): void {
    for (const cam of this.cameras) {
      if (cam.offlineTimer > 0) {
        cam.offlineTimer = Math.max(0, cam.offlineTimer - delta);
      }
      if (cam.anomalyTimer > 0) {
        cam.anomalyTimer = Math.max(0, cam.anomalyTimer - delta);
        if (cam.anomalyTimer <= 0) {
          cam.anomaly = 'none';
        }
      }
    }

    this.eventAccum -= delta;
    if (this.eventAccum <= 0) {
      this.eventAccum = 10 + Math.random() * 12;
      const target =
        this.cameras[Math.floor(Math.random() * this.cameras.length)];
      if (Math.random() < 0.45) {
        target.offlineTimer = 6 + Math.random() * 5;
      } else {
        const anomalies: CameraFeedInfo['anomaly'][] = [
          'shadow_peek',
          'static_face',
          'light_dip',
        ];
        target.anomaly =
          anomalies[Math.floor(Math.random() * anomalies.length)];
        target.anomalyTimer = 4.5;
      }
    }
  }

  public getFeeds(
    monsterPos: THREE.Vector3,
    monsterState: MonsterState,
  ): CameraFeedInfo[] {
    const monsterFloor = getFloorFromY(monsterPos.y);
    const normX = THREE.MathUtils.clamp((monsterPos.x + 4.2) / 9.4, 0.08, 0.92);
    const normZ = THREE.MathUtils.clamp((monsterPos.z + 2.1) / 3.6, 0.12, 0.88);

    return this.cameras.map((cam) => {
      const online = cam.offlineTimer <= 0;
      const monsterOnFloor = online && monsterFloor === cam.floor;
      return {
        id: cam.id,
        label: cam.label,
        floor: cam.floor,
        online,
        monsterOnFloor,
        monsterNormX: normX,
        monsterNormZ: normZ,
        monsterState,
        anomaly: cam.anomaly,
      };
    });
  }
}
