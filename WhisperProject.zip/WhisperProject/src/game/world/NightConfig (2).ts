import { NightSeedData, WeatherType } from '../types';

const NIGHT_COUNTER_KEY = 'whisper_floors_night_counter_v1';
const KEYPAD_CODES = ['0417', '0724', '0931', '0518'];
const WEATHERS: WeatherType[] = ['rain', 'storm', 'fog'];

export function getNextNightNumber(): number {
  try {
    const raw = localStorage.getItem(NIGHT_COUNTER_KEY);
    const prev = raw ? parseInt(raw, 10) : 0;
    const next = Number.isFinite(prev) && prev >= 0 ? prev + 1 : 1;
    localStorage.setItem(NIGHT_COUNTER_KEY, String(next));
    return next;
  } catch {
    return 1;
  }
}

export function createRandomNightSeed(
  nightNumber?: number,
  isNewGamePlus = false,
): NightSeedData {
  const num = nightNumber ?? getNextNightNumber();
  const monsterFloors = [2, 3, 4, 5];
  const monsterStartFloor =
    monsterFloors[Math.floor(Math.random() * monsterFloors.length)];
  const weather = WEATHERS[Math.floor(Math.random() * WEATHERS.length)];
  const keypadCode =
    KEYPAD_CODES[Math.floor(Math.random() * KEYPAD_CODES.length)];

  return {
    nightNumber: num,
    monsterStartFloor,
    itemVariant: Math.floor(Math.random() * 3), // 0, 1, 2
    secretVariant: Math.floor(Math.random() * 2), // 0, 1
    openApt5: Math.random() < 0.68,
    openApt11: Math.random() < 0.55,
    patrolBias: Math.floor(Math.random() * 4),
    weather,
    isNewGamePlus,
    keypadCode,
  };
}
