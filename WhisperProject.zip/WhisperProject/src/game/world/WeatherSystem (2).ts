import * as THREE from 'three';
import { WeatherType } from '../types';
import { SoundEngine } from '../audio/SoundEngine';

const DROP_COUNT = 140;

export class WeatherSystem {
  public weather: WeatherType = 'rain';

  private rainPoints: THREE.Points;
  private rainGeo: THREE.BufferGeometry;
  private rainMat: THREE.PointsMaterial;
  private rainPositions: Float32Array;
  private stormFlashLight: THREE.PointLight;
  private skyBackdrop: THREE.Mesh;
  private skyMat: THREE.MeshBasicMaterial;

  private lightningCooldown = 9;
  private flashIntensity = 0;
  private thunderDelay = 0;

  constructor(
    private scene: THREE.Scene,
    private sound: SoundEngine,
  ) {
    this.rainPositions = new Float32Array(DROP_COUNT * 3);
    for (let i = 0; i < DROP_COUNT; i++) {
      this.rainPositions[i * 3] = -2.4 + Math.random() * 3.4;
      this.rainPositions[i * 3 + 1] = Math.random() * 20;
      this.rainPositions[i * 3 + 2] = 6.5 + Math.random() * 2.5;
    }

    this.rainGeo = new THREE.BufferGeometry();
    this.rainGeo.setAttribute(
      'position',
      new THREE.BufferAttribute(this.rainPositions, 3),
    );
    this.rainMat = new THREE.PointsMaterial({
      color: 0x8ea4bd,
      size: 0.075,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    this.rainPoints = new THREE.Points(this.rainGeo, this.rainMat);
    scene.add(this.rainPoints);

    // Exterior backdrop behind stairwell windows
    this.skyMat = new THREE.MeshBasicMaterial({
      color: 0x090d14,
      side: THREE.DoubleSide,
    });
    this.skyBackdrop = new THREE.Mesh(
      new THREE.PlaneGeometry(8.5, 24),
      this.skyMat,
    );
    this.skyBackdrop.position.set(-0.7, 9.5, 9.6);
    scene.add(this.skyBackdrop);

    // Exterior lightning flash light illuminating stairwell windows
    this.stormFlashLight = new THREE.PointLight(0x9bc4ff, 0, 26, 1.4);
    this.stormFlashLight.position.set(-0.7, 9.2, 7.6);
    scene.add(this.stormFlashLight);
  }

  public setWeather(weather: WeatherType): void {
    this.weather = weather;
    this.flashIntensity = 0;
    this.thunderDelay = 0;
    this.lightningCooldown = weather === 'storm' ? 6 + Math.random() * 7 : 999;

    if (weather === 'fog') {
      this.rainPoints.visible = false;
      this.scene.background = new THREE.Color(0x090c10);
      this.scene.fog = new THREE.FogExp2(0x090c10, 0.096);
      this.skyMat.color.setHex(0x11171f);
    } else if (weather === 'storm') {
      this.rainPoints.visible = true;
      this.rainMat.opacity = 0.72;
      this.scene.background = new THREE.Color(0x05070b);
      this.scene.fog = new THREE.FogExp2(0x05070b, 0.086);
      this.skyMat.color.setHex(0x070a10);
    } else {
      this.rainPoints.visible = true;
      this.rainMat.opacity = 0.48;
      this.scene.background = new THREE.Color(0x06080b);
      this.scene.fog = new THREE.FogExp2(0x06080b, 0.082);
      this.skyMat.color.setHex(0x090d14);
    }
  }

  public update(delta: number, playerFloor: number, playerZ: number): void {
    const dt = Math.min(delta, 0.05);

    if (this.rainPoints.visible) {
      const fallSpeed = this.weather === 'storm' ? 14.5 : 10.2;
      const windX = this.weather === 'storm' ? -1.4 : -0.45;
      for (let i = 0; i < DROP_COUNT; i++) {
        const idx = i * 3;
        this.rainPositions[idx] += windX * dt;
        this.rainPositions[idx + 1] -= fallSpeed * dt;
        if (this.rainPositions[idx + 1] < -1.5) {
          this.rainPositions[idx] = -2.4 + Math.random() * 3.4;
          this.rainPositions[idx + 1] = 19.5;
        }
      }
      this.rainGeo.attributes.position.needsUpdate = true;
    }

    if (this.weather === 'storm') {
      this.lightningCooldown -= dt;
      if (this.lightningCooldown <= 0) {
        this.lightningCooldown = 11 + Math.random() * 14;
        this.flashIntensity = 4.6;
        this.thunderDelay = 0.45 + Math.random() * 0.65;
        this.stormFlashLight.position.y = Math.max(2, playerFloor * 3.2);
      }
    }

    if (this.flashIntensity > 0.02) {
      this.flashIntensity = Math.max(0, this.flashIntensity - dt * 11.5);
      this.stormFlashLight.intensity = this.flashIntensity;
      const flashFactor = Math.min(1, this.flashIntensity / 4.2);
      this.skyMat.color.setRGB(
        0.03 + flashFactor * 0.35,
        0.04 + flashFactor * 0.42,
        0.07 + flashFactor * 0.56,
      );
    } else if (this.stormFlashLight.intensity !== 0) {
      this.stormFlashLight.intensity = 0;
      this.skyMat.color.setHex(0x070a10);
    }

    if (this.thunderDelay > 0) {
      this.thunderDelay -= dt;
      if (this.thunderDelay <= 0) {
        const nearWindow = playerZ > 2.0 || playerFloor === 6 ? 1.0 : 0.62;
        this.sound.playThunder(nearWindow);
      }
    }
  }

  public dispose(): void {
    this.rainGeo.dispose();
    this.rainMat.dispose();
    this.skyBackdrop.geometry.dispose();
    this.skyMat.dispose();
  }
}
