import { DifficultyLevel } from '../types';

export const GAME_VERSION = '0.5.0';
export const GAME_UPDATE_LABEL = 'Update 0.4 + 0.5 — Ultimate Horror Expansion';

export interface DifficultyProfile {
  id: DifficultyLevel;
  label: string;
  description: string;
  monsterSpeedScale: number;
  monsterSightScale: number;
  monsterDamageScale: number;
  staminaDrainScale: number;
  eventIntervalScale: number;
  batteryDrainScale: number;
}

export const DIFFICULTY_PROFILES: Record<DifficultyLevel, DifficultyProfile> = {
  easy: {
    id: 'easy',
    label: 'Лёгкий',
    description: 'Выносливость тратится медленнее, существо слабее бьёт и реже замечает.',
    monsterSpeedScale: 0.88,
    monsterSightScale: 0.82,
    monsterDamageScale: 0.72,
    staminaDrainScale: 0.76,
    eventIntervalScale: 1.35,
    batteryDrainScale: 0.78,
  },
  normal: {
    id: 'normal',
    label: 'Нормальный',
    description: 'Сбалансированное напряжение: честная погоня и стандартные ресурсы.',
    monsterSpeedScale: 1.0,
    monsterSightScale: 1.0,
    monsterDamageScale: 1.0,
    staminaDrainScale: 1.0,
    eventIntervalScale: 1.0,
    batteryDrainScale: 1.0,
  },
  hard: {
    id: 'hard',
    label: 'Сложный',
    description: 'Острое чутьё охотника, быстрее разряд фонаря и чаще события в доме.',
    monsterSpeedScale: 1.08,
    monsterSightScale: 1.14,
    monsterDamageScale: 1.2,
    staminaDrainScale: 1.1,
    eventIntervalScale: 0.8,
    batteryDrainScale: 1.18,
  },
  nightmare: {
    id: 'nightmare',
    label: 'Кошмар',
    description: 'Максимальное напряжение, тяжёлый урон и суровая проверка слуха и реакции.',
    monsterSpeedScale: 1.14,
    monsterSightScale: 1.24,
    monsterDamageScale: 1.42,
    staminaDrainScale: 1.18,
    eventIntervalScale: 0.68,
    batteryDrainScale: 1.32,
  },
};

export const BUILDING = {
  MIN_FLOOR: 0, // 0 = Подвал
  MAX_FLOOR: 6, // 6 = Чердак
  RESIDENTIAL_MIN: 1,
  RESIDENTIAL_MAX: 5,
  FLOOR_COUNT: 5, // Residential floors 1..5 served by elevator
  FLOOR_HEIGHT: 3.2,
  HALF_HEIGHT: 1.6,
  SLAB_THICKNESS: 0.22,
  WALL_THICKNESS: 0.2,

  // Player dimensions & movement (sprint clearly outruns stalker burst on every difficulty)
  PLAYER_RADIUS: 0.34,
  EYE_STANDING: 1.62,
  EYE_CROUCHING: 0.96,
  WALK_SPEED: 3.05,
  EXHAUSTED_SPEED: 2.15,
  SPRINT_SPEED: 5.4,
  ADRENALINE_SPEED: 5.75,
  CROUCH_SPEED: 1.68,

  // Main landing & corridor footprint
  WEST_X: -4.2,
  EAST_X: 5.2,
  NORTH_Z: -2.1,
  LANDING_SOUTH_Z: 1.5,

  // Elevator shaft (north of NORTH_Z)
  ELEVATOR_MIN_X: -3.95,
  ELEVATOR_MAX_X: -1.65,
  ELEVATOR_CENTER_X: -2.8,
  ELEVATOR_MIN_Z: -4.4,
  ELEVATOR_MAX_Z: -2.1,
  ELEVATOR_CENTER_Z: -3.25,
  ELEVATOR_DOOR_WIDTH: 1.3,
  ELEVATOR_DOOR_HEIGHT: 2.18,
  ELEVATOR_CABIN_HEIGHT: 2.38,

  // Stairwell shaft south of LANDING_SOUTH_Z (+1.5)
  STAIR_WEST_X: -2.9,
  STAIR_EAST_X: 1.4,
  STAIR_SOUTH_Z: 6.2,

  FLIGHT_A_MIN_X: -0.5,
  FLIGHT_A_MAX_X: 1.25,
  FLIGHT_B_MIN_X: -2.8,
  FLIGHT_B_MAX_X: -1.05,

  STAIR_START_Z: 1.5,
  STAIR_END_Z: 4.3,
  STEPS_PER_FLIGHT: 8,

  HALF_LANDING_MIN_Z: 4.3,
  HALF_LANDING_MAX_Z: 6.2,
} as const;

export function getFloorBaseY(floor: number): number {
  return (floor - 1) * BUILDING.FLOOR_HEIGHT;
}

export function getFloorFromY(y: number): number {
  const raw = Math.round(y / BUILDING.FLOOR_HEIGHT) + 1;
  return Math.max(BUILDING.MIN_FLOOR, Math.min(BUILDING.MAX_FLOOR, raw));
}

export function getLocationLabel(floor: number, x: number, z: number): string {
  if (floor === 0) {
    return x > 1.5 ? 'Электрощитовая' : 'Подвал';
  }
  if (floor === 6) {
    return z < -1.8 ? 'Машинное отделение' : 'Чердак';
  }
  if (floor === 1 && x > 5.2) {
    return 'Кв. №2 · 1 этаж';
  }
  if (floor === 2 && z < -2.2) {
    return 'Кв. №4 · 2 этаж';
  }
  if (floor === 2 && x > 5.2) {
    return 'Пост охраны (кв. №5)';
  }
  if (floor === 3 && z < -2.2) {
    return 'Кв. №7 · 3 этаж';
  }
  if (floor === 3 && x > 5.2) {
    return 'Техническая ниша';
  }
  if (floor === 4 && z < -2.2) {
    return z < -6.7 ? 'Секретная комната' : 'Заброшенная кв. №10';
  }
  if (floor === 4 && x > 5.2) {
    return 'Секретная кв. №11';
  }
  if (floor === 5 && z < -2.2) {
    return 'Кв. №13 · 5 этаж';
  }
  if (floor === 5 && x > 5.2) {
    return 'Кв. №14 · 5 этаж';
  }
  return `${floor} этаж · Подъезд`;
}
