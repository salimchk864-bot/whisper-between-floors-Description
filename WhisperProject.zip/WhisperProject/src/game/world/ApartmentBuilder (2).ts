import * as THREE from 'three';
import { getFloorBaseY } from './BuildingConfig';
import { MaterialLibrary } from './MaterialLibrary';
import { CollisionWorld, SurfaceKind } from '../engine/CollisionWorld';
import { InteractionManager } from '../engine/InteractionManager';
import { STORY_NOTES } from '../story/NotesData';
import { NightSeedData, ReadableNote } from '../types';
import { SoundEngine } from '../audio/SoundEngine';
import type { FloorLightRig } from './BuildingBuilder';

export interface ApartmentBuildContext {
  scene: THREE.Scene;
  mats: MaterialLibrary;
  collision: CollisionWorld;
  interaction: InteractionManager;
  sound: SoundEngine;
  nightSeed: NightSeedData;
  unlockedKeypads: Set<string>;
  dynamicUnlockers: Map<string, () => void>;
  occlusionMeshes: THREE.Object3D[];
  floorLights: FloorLightRig[];
  trackGeo: <T extends THREE.BufferGeometry>(g: T) => T;
  addWallBox: (
    x1: number,
    x2: number,
    y1: number,
    y2: number,
    z1: number,
    z2: number,
    mat: THREE.Material,
    collide?: boolean,
    occlude?: boolean,
  ) => THREE.Mesh;
  buildInteriorDoor: (opts: {
    id: string;
    title: string;
    x: number;
    y: number;
    z: number;
    rotY: number;
  }) => void;
  registerHidingSpot: (cfg: {
    id: string;
    name: string;
    pos: THREE.Vector3;
    size: THREE.Vector3;
    camOffset: THREE.Vector3;
    lookYaw: number;
    returnOffset: THREE.Vector3;
    meshMat: THREE.Material;
  }) => void;
  spawnWorldItem: (cfg: {
    id: string;
    itemId: string;
    label: string;
    pos: THREE.Vector3;
    color: number;
    size?: THREE.Vector3;
  }) => void;
  spawnWorldNote: (id: string, note: ReadableNote, pos: THREE.Vector3) => void;
  linkNavEdge: (
    corridorNodeId: string,
    roomNodeId: string,
    roomPos: THREE.Vector3,
    floor: number,
    doorId: string,
  ) => void;
  onOpenCCTV: () => void;
  onSecretFound: () => void;
  onSubtitle: (msg: string) => void;
  onNoiseImpulse: (pos: THREE.Vector3, radius: number) => void;
  onRadioTriggered?: () => void;
  onOpenKeypad: (opts: {
    id: string;
    title: string;
    hint: string;
    expectedCode: string;
    onUnlocked: () => void;
  }) => void;
}

export class ApartmentBuilder {
  constructor(private ctx: ApartmentBuildContext) {}

  private addRoomShell(opts: {
    minX: number;
    maxX: number;
    y: number;
    minZ: number;
    maxZ: number;
    floorMat: THREE.Material;
    surfaceKind: SurfaceKind;
  }): void {
    const w = opts.maxX - opts.minX;
    const d = opts.maxZ - opts.minZ;
    const cx = (opts.minX + opts.maxX) / 2;
    const cz = (opts.minZ + opts.maxZ) / 2;

    const floorMesh = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(w, 0.2, d)),
      opts.floorMat,
    );
    floorMesh.position.set(cx, opts.y - 0.1, cz);
    floorMesh.receiveShadow = true;
    this.ctx.scene.add(floorMesh);
    this.ctx.occlusionMeshes.push(floorMesh);

    const ceilMesh = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(w, 0.2, d)),
      this.ctx.mats.ceilingConcrete,
    );
    ceilMesh.position.set(cx, opts.y + 3.1, cz);
    this.ctx.scene.add(ceilMesh);

    this.ctx.collision.addWalkSurface({
      minX: opts.minX - 0.08,
      maxX: opts.maxX + 0.08,
      minZ: opts.minZ - 0.08,
      maxZ: opts.maxZ + 0.08,
      surfaceKind: opts.surfaceKind,
      getY: () => opts.y,
    });
  }

  private addApartmentLamp(
    floor: number,
    x: number,
    y: number,
    z: number,
    colorHex: number,
    intensity: number,
    flickerMode: 'steady' | 'flicker' = 'flicker',
  ): void {
    const tubeMat = this.ctx.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xd6cdb8,
        emissive: colorHex,
        emissiveIntensity: 0.75,
        roughness: 0.35,
      }),
    );

    const bulb = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.SphereGeometry(0.08, 8, 8)),
      tubeMat,
    );
    bulb.position.set(x, y + 2.92, z);
    this.ctx.scene.add(bulb);

    const light = new THREE.PointLight(colorHex, intensity, 8.0, 1.85);
    light.position.set(x, y + 2.7, z);
    this.ctx.scene.add(light);

    this.ctx.floorLights.push({
      floor,
      light,
      tubeMat,
      powered: true,
      baseIntensity: intensity,
      isApartment: flickerMode === 'flicker',
      flickerPhase: (x * 1.7 + z * 2.3 + floor * 3.1) % 10,
    });
  }

  private addFurnitureBox(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    d: number,
    mat: THREE.Material,
    occlude = false,
  ): void {
    const mesh = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(w, h, d)),
      mat,
    );
    mesh.position.set(x, y + h / 2, z);
    mesh.receiveShadow = true;
    this.ctx.scene.add(mesh);
    if (occlude) this.ctx.occlusionMeshes.push(mesh);

    this.ctx.collision.addCollider({
      minX: x - w / 2,
      maxX: x + w / 2,
      minY: y,
      maxY: y + h + 0.1,
      minZ: z - d / 2,
      maxZ: z + d / 2,
    });
  }

  private addInteractiveAudioDevice(opts: {
    id: string;
    kind: 'tv' | 'radio';
    title: string;
    x: number;
    y: number;
    z: number;
    rotY: number;
    broadcastText: string;
  }): void {
    const group = new THREE.Group();
    group.position.set(opts.x, opts.y, opts.z);
    group.rotation.y = opts.rotY;
    this.ctx.scene.add(group);

    let poweredOn = false;
    const glowMat = this.ctx.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x0e1316,
        emissive: opts.kind === 'tv' ? 0x67e8f9 : 0x4ade80,
        emissiveIntensity: 0.02,
        roughness: 0.35,
      }),
    );

    const body = new THREE.Mesh(
      this.ctx.trackGeo(
        opts.kind === 'tv'
          ? new THREE.BoxGeometry(0.52, 0.42, 0.38)
          : new THREE.BoxGeometry(0.32, 0.2, 0.16),
      ),
      this.ctx.mats.doorSteel,
    );
    body.position.set(0, opts.kind === 'tv' ? 0.21 : 0.1, 0);
    group.add(body);

    const screen = new THREE.Mesh(
      this.ctx.trackGeo(
        opts.kind === 'tv'
          ? new THREE.PlaneGeometry(0.4, 0.3)
          : new THREE.PlaneGeometry(0.18, 0.06),
      ),
      glowMat,
    );
    screen.position.set(0, opts.kind === 'tv' ? 0.22 : 0.11, opts.kind === 'tv' ? 0.195 : 0.085);
    group.add(screen);

    this.ctx.interaction.register({
      id: opts.id,
      mesh: body,
      title: opts.title,
      actionText: 'Включить / переключить',
      category: 'radio',
      onInteract: () => {
        poweredOn = !poweredOn;
        glowMat.emissiveIntensity = poweredOn ? 0.85 : 0.02;
        if (poweredOn) {
          this.ctx.sound.playRadioStatic(0);
          this.ctx.onNoiseImpulse(new THREE.Vector3(opts.x, opts.y, opts.z), 8.5);
          this.ctx.onRadioTriggered?.();
          this.ctx.onSubtitle(opts.broadcastText);
        } else {
          this.ctx.sound.playBreakerFlip();
          this.ctx.onSubtitle(`${opts.title}: питание отключено.`);
        }
      },
    });
  }

  public buildAllApartments(): void {
    this.buildApartment2();
    this.buildApartment4();
    this.buildApartment5();
    this.buildApartment7();
    this.buildApartment11();
    this.buildApartment13();
    this.buildApartment14();
  }

  // Floor 1 East: Квартира №2 (Кухня-гостиная + отдельная ванная)
  private buildApartment2(): void {
    const y = getFloorBaseY(1);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;
    const tileWall = this.ctx.mats.tileBathroom;

    // Living/Hallway floor + South hallway floor (wood)
    this.addRoomShell({
      minX: 5.2,
      maxX: 8.0,
      y,
      minZ: -2.6,
      maxZ: 1.5,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });
    this.addRoomShell({
      minX: 8.0,
      maxX: 10.2,
      y,
      minZ: -0.5,
      maxZ: 1.5,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });
    // Bathroom floor (ceramic tile)
    this.addRoomShell({
      minX: 8.0,
      maxX: 10.2,
      y,
      minZ: -2.6,
      maxZ: -0.5,
      floorMat: this.ctx.mats.tileBathroom,
      surfaceKind: 'concrete',
    });

    // Outer apartment perimeter walls (North Z=-2.6, South Z=1.5, East X=10.2)
    this.ctx.addWallBox(5.2, 10.35, y, yTop, -2.75, -2.6, wall);
    this.ctx.addWallBox(5.2, 10.35, y, yTop, 1.5, 1.65, wall);
    this.ctx.addWallBox(10.2, 10.35, y, yTop, -2.6, 1.5, wall);

    // Interior Bathroom Partition (Z = -0.5 solid, X = 8.0 with doorway Z in [-1.8, -0.9])
    this.ctx.addWallBox(8.0, 10.2, y, yTop, -0.55, -0.45, tileWall);
    this.ctx.addWallBox(7.92, 8.08, y, yTop, -2.6, -1.8, tileWall);
    this.ctx.addWallBox(7.92, 8.08, y, yTop, -0.9, -0.5, tileWall);
    this.ctx.addWallBox(7.92, 8.08, y + 2.1, yTop, -1.8, -0.9, tileWall, false);

    this.ctx.buildInteriorDoor({
      id: 'apt2_bath_door',
      title: 'Дверь в ванную (кв. 2)',
      x: 8.0,
      y,
      z: -1.35,
      rotY: -Math.PI / 2,
    });

    // Furniture
    this.addFurnitureBox(6.7, y, -1.85, 1.05, 0.76, 0.72, this.ctx.mats.furnitureWood);
    this.addFurnitureBox(6.8, y, 0.7, 1.55, 0.75, 0.72, this.ctx.mats.fabricDark, true);
    this.addFurnitureBox(8.6, y, -2.35, 0.65, 0.84, 0.45, this.ctx.mats.lampGlassOff);
    this.addFurnitureBox(9.55, y, -1.1, 0.75, 0.52, 1.15, this.ctx.mats.lampGlassOff);

    // Hiding Spots (Wardrobe, Dark Corner behind Sofa, Bathroom Corner)
    this.ctx.registerHidingSpot({
      id: 'hide_apt2_wardrobe',
      name: 'Шкаф в прихожей кв. 2',
      pos: new THREE.Vector3(5.85, y, -2.15),
      size: new THREE.Vector3(0.85, 2.05, 0.7),
      camOffset: new THREE.Vector3(0, 1.42, 0.08),
      lookYaw: Math.PI,
      returnOffset: new THREE.Vector3(0, 0, 0.9),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt2_dark_corner',
      name: 'Тёмный угол за диваном (кв. 2)',
      pos: new THREE.Vector3(8.5, y, 1.1),
      size: new THREE.Vector3(0.75, 1.65, 0.65),
      camOffset: new THREE.Vector3(-0.08, 0.95, -0.05),
      lookYaw: -Math.PI * 0.65,
      returnOffset: new THREE.Vector3(-0.9, 0, -0.25),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt2_bathroom',
      name: 'Укрытие в ванной кв. 2',
      pos: new THREE.Vector3(9.7, y, -2.15),
      size: new THREE.Vector3(0.75, 1.9, 0.75),
      camOffset: new THREE.Vector3(-0.08, 1.25, 0.05),
      lookYaw: Math.PI * 0.35,
      returnOffset: new THREE.Vector3(-0.9, 0, 0.1),
      meshMat: this.ctx.mats.fabricDark,
    });

    // Flickering warm apartment lamp
    this.addApartmentLamp(1, 6.6, y, -0.35, 0xf2b872, 0.95, 'flicker');

    // Items & Lore
    this.ctx.spawnWorldNote(
      'note_apt_2',
      STORY_NOTES.note_apt_2,
      new THREE.Vector3(6.7, y + 0.77, -1.85),
    );
    this.ctx.spawnWorldItem({
      id: 'item_apt2_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(8.6, y + 0.88, -2.35),
      color: 0xeab308,
    });

    // Old CRT TV + Code Clue Part 1 (first 2 digits of Apt 5 code locker)
    this.addFurnitureBox(9.45, y, 0.9, 0.56, 0.54, 0.62, this.ctx.mats.furnitureWood);
    this.addInteractiveAudioDevice({
      id: 'apt2_old_tv',
      kind: 'tv',
      title: 'Старый телевизор (кв. 2)',
      x: 9.45,
      y: y + 0.54,
      z: 0.9,
      rotY: -Math.PI / 2,
      broadcastText: 'Экран зашипел: «...вход в подвал остаётся под наблюдением...»',
    });

    const firstTwo = this.ctx.nightSeed.keypadCode.slice(0, 2);
    const scrapMesh = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(0.18, 0.015, 0.14)),
      this.ctx.mats.paperNote,
    );
    scrapMesh.position.set(6.35, y + 0.77, -1.85);
    this.ctx.scene.add(scrapMesh);
    this.ctx.interaction.register({
      id: 'apt2_code_scrap',
      mesh: scrapMesh,
      title: 'Обрывок кода охраны',
      actionText: 'Осмотреть цифры',
      category: 'note',
      onInteract: () => {
        this.ctx.sound.playPaperPickup();
        this.ctx.onSubtitle(
          `На листке обведены первые две цифры сейфа поста охраны (кв. 5): «${firstTwo}--».`,
        );
      },
    });

    // Nav links for Monster AI
    this.ctx.linkNavEdge(
      'f1_east_edge',
      'apt2_main',
      new THREE.Vector3(6.5, y, -0.3),
      1,
      'apt_door_2',
    );
    this.ctx.linkNavEdge(
      'apt2_main',
      'apt2_bath',
      new THREE.Vector3(8.8, y, -1.45),
      1,
      'apt2_bath_door',
    );
  }

  // Floor 2 North: Квартира №4 (Гостиная + Спальня + Ванная)
  private buildApartment4(): void {
    const y = getFloorBaseY(2);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;
    const tileWall = this.ctx.mats.tileBathroom;

    // Living + Bedroom (wood)
    this.addRoomShell({
      minX: -1.2,
      maxX: 1.9,
      y,
      minZ: -8.2,
      maxZ: -2.1,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });
    this.addRoomShell({
      minX: 1.9,
      maxX: 5.2,
      y,
      minZ: -5.2,
      maxZ: -2.1,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });
    // Bathroom (ceramic tile)
    this.addRoomShell({
      minX: 1.9,
      maxX: 5.2,
      y,
      minZ: -8.2,
      maxZ: -5.2,
      floorMat: this.ctx.mats.tileBathroom,
      surfaceKind: 'concrete',
    });

    // Outer perimeter walls (West X=-1.2, East X=5.2, Back North Z=-8.2)
    this.ctx.addWallBox(-1.35, -1.2, y, yTop, -8.35, -2.1, wall);
    this.ctx.addWallBox(5.2, 5.35, y, yTop, -8.35, -2.1, wall);
    this.ctx.addWallBox(-1.35, 5.35, y, yTop, -8.35, -8.2, wall);

    // Interior wall between Living & Bedroom at X = 1.9 (doorway Z in [-3.9, -3.0])
    this.ctx.addWallBox(1.82, 1.98, y, yTop, -8.2, -3.9, wall);
    this.ctx.addWallBox(1.82, 1.98, y, yTop, -3.0, -2.1, wall);
    this.ctx.addWallBox(1.82, 1.98, y + 2.1, yTop, -3.9, -3.0, wall, false);
    this.ctx.buildInteriorDoor({
      id: 'apt4_bed_door',
      title: 'Дверь в спальню (кв. 4)',
      x: 1.9,
      y,
      z: -3.45,
      rotY: Math.PI / 2,
    });

    // Interior wall between Living & Bathroom at Z = -5.2 (doorway X in [2.85, 3.75])
    this.ctx.addWallBox(1.9, 2.85, y, yTop, -5.28, -5.12, tileWall);
    this.ctx.addWallBox(3.75, 5.2, y, yTop, -5.28, -5.12, tileWall);
    this.ctx.addWallBox(2.85, 3.75, y + 2.1, yTop, -5.28, -5.12, tileWall, false);
    this.ctx.buildInteriorDoor({
      id: 'apt4_bath_door',
      title: 'Дверь в ванную (кв. 4)',
      x: 3.3,
      y,
      z: -5.2,
      rotY: 0,
    });

    // Furniture
    this.addFurnitureBox(4.3, y, -3.55, 0.95, 0.78, 0.85, this.ctx.mats.furnitureWood);
    this.addFurnitureBox(2.55, y, -4.4, 0.72, 0.78, 1.25, this.ctx.mats.fabricDark, true);
    this.addFurnitureBox(0.85, y, -7.6, 0.55, 0.62, 0.55, this.ctx.mats.furnitureWood);
    this.addFurnitureBox(2.55, y, -7.6, 0.75, 0.54, 1.4, this.ctx.mats.lampGlassOff);

    // Hiding spots
    this.ctx.registerHidingSpot({
      id: 'hide_apt4_wardrobe',
      name: 'Шкаф в спальне кв. 4',
      pos: new THREE.Vector3(-0.75, y, -2.75),
      size: new THREE.Vector3(0.75, 2.08, 1.05),
      camOffset: new THREE.Vector3(0.08, 1.44, 0),
      lookYaw: -Math.PI * 0.5,
      returnOffset: new THREE.Vector3(0.95, 0, 0),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt4_under_bed',
      name: 'Под кроватью в кв. 4',
      pos: new THREE.Vector3(-0.3, y, -6.75),
      size: new THREE.Vector3(1.25, 0.62, 1.85),
      camOffset: new THREE.Vector3(0.2, 0.34, 0.1),
      lookYaw: -Math.PI * 0.55,
      returnOffset: new THREE.Vector3(1.15, 0, 0),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt4_bathroom',
      name: 'Тёмный угол в ванной кв. 4',
      pos: new THREE.Vector3(4.65, y, -7.65),
      size: new THREE.Vector3(0.8, 1.85, 0.75),
      camOffset: new THREE.Vector3(-0.1, 1.25, 0.08),
      lookYaw: Math.PI * 0.25,
      returnOffset: new THREE.Vector3(-0.95, 0, 0.15),
      meshMat: this.ctx.mats.fabricDark,
    });

    // Lighting
    this.addApartmentLamp(2, 3.4, y, -3.5, 0xe8b574, 0.9, 'flicker');
    this.addApartmentLamp(2, 0.4, y, -5.2, 0x9ab0c4, 0.45, 'flicker');

    // Notes & items + Radio
    this.ctx.spawnWorldNote(
      'note_apt_4',
      STORY_NOTES.note_apt_4,
      new THREE.Vector3(0.85, y + 0.63, -7.6),
    );
    this.ctx.spawnWorldItem({
      id: 'item_apt4_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(4.3, y + 0.82, -3.55),
      color: 0xeab308,
    });
    this.addInteractiveAudioDevice({
      id: 'apt4_radio',
      kind: 'radio',
      title: 'Радиоприёмник (кв. 4)',
      x: 2.55,
      y: y + 0.78,
      z: -4.4,
      rotY: Math.PI / 2,
      broadcastText: 'Сквозь помехи: «...приём, антенна на чердаке снова несёт шёпот...»',
    });

    // Monster nav links
    this.ctx.linkNavEdge(
      'f2_east',
      'apt4_living',
      new THREE.Vector3(3.3, y, -3.45),
      2,
      'apt_door_4',
    );
    this.ctx.linkNavEdge(
      'apt4_living',
      'apt4_bed',
      new THREE.Vector3(0.6, y, -4.4),
      2,
      'apt4_bed_door',
    );
    this.ctx.linkNavEdge(
      'apt4_living',
      'apt4_bath',
      new THREE.Vector3(3.3, y, -6.4),
      2,
      'apt4_bath_door',
    );
  }

  // Floor 3 North: Расширенная Квартира №7 (ключ в почтовом ящике №7)
  private buildApartment7(): void {
    const y = getFloorBaseY(3);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;

    this.addRoomShell({
      minX: 2.3,
      maxX: 5.2,
      y,
      minZ: -6.0,
      maxZ: -2.1,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });

    this.ctx.addWallBox(2.15, 2.3, y, yTop, -6.15, -2.1, wall);
    this.ctx.addWallBox(5.2, 5.35, y, yTop, -6.15, -2.1, wall);
    this.ctx.addWallBox(2.15, 5.35, y, yTop, -6.15, -6.0, wall);

    // Table with basement key & note
    this.addFurnitureBox(4.5, y, -3.4, 0.85, 0.76, 1.05, this.ctx.mats.furnitureWood);

    // Hiding Spots
    this.ctx.registerHidingSpot({
      id: 'hide_apt7_wardrobe',
      name: 'Шкаф в кв. 7',
      pos: new THREE.Vector3(2.75, y, -3.65),
      size: new THREE.Vector3(0.75, 2.05, 1.05),
      camOffset: new THREE.Vector3(0.08, 1.42, 0),
      lookYaw: -Math.PI * 0.5,
      returnOffset: new THREE.Vector3(0.95, 0, 0),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt7_under_bed',
      name: 'Под кроватью в кв. 7',
      pos: new THREE.Vector3(4.4, y, -5.05),
      size: new THREE.Vector3(1.15, 0.62, 1.65),
      camOffset: new THREE.Vector3(-0.2, 0.34, 0.05),
      lookYaw: Math.PI * 0.55,
      returnOffset: new THREE.Vector3(-1.05, 0, 0),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.addApartmentLamp(3, 3.6, y, -3.9, 0xd8a66c, 0.8, 'flicker');

    // Keep exact Update 0.2 item/note IDs for save compatibility
    this.ctx.spawnWorldNote(
      'note_apt_7',
      STORY_NOTES.note_apt_7,
      new THREE.Vector3(4.45, y + 0.77, -3.15),
    );
    this.ctx.spawnWorldItem({
      id: 'item_apt7_key_basement',
      itemId: 'key_basement',
      label: 'Ключ от подвала',
      pos: new THREE.Vector3(4.55, y + 0.8, -3.55),
      color: 0xd97706,
    });
    this.ctx.spawnWorldItem({
      id: 'item_apt7_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(4.35, y + 0.81, -3.75),
      color: 0xeab308,
    });

    this.addFurnitureBox(3.6, y, -5.55, 0.56, 0.52, 0.45, this.ctx.mats.furnitureWood);
    this.addInteractiveAudioDevice({
      id: 'apt7_old_tv',
      kind: 'tv',
      title: 'Телевизор в кв. 7',
      x: 3.6,
      y: y + 0.52,
      z: -5.55,
      rotY: 0,
      broadcastText: 'На чёрно-белом экране промелькнул пустой лестничный марш.',
    });

    this.ctx.linkNavEdge(
      'f3_east',
      'apt7_main',
      new THREE.Vector3(3.4, y, -3.8),
      3,
      'apt_door_7',
    );
  }

  // Floor 5 East: Квартира №14 (Студия радиста + тёмная ванная)
  private buildApartment14(): void {
    const y = getFloorBaseY(5);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;
    const tileWall = this.ctx.mats.tileBathroom;

    this.addRoomShell({
      minX: 5.2,
      maxX: 8.0,
      y,
      minZ: -3.0,
      maxZ: 1.5,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });
    this.addRoomShell({
      minX: 8.0,
      maxX: 10.4,
      y,
      minZ: -0.6,
      maxZ: 1.5,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });
    this.addRoomShell({
      minX: 8.0,
      maxX: 10.4,
      y,
      minZ: -3.0,
      maxZ: -0.6,
      floorMat: this.ctx.mats.tileBathroom,
      surfaceKind: 'concrete',
    });

    // Outer walls
    this.ctx.addWallBox(5.2, 10.55, y, yTop, -3.15, -3.0, wall);
    this.ctx.addWallBox(5.2, 10.55, y, yTop, 1.5, 1.65, wall);
    this.ctx.addWallBox(10.4, 10.55, y, yTop, -3.0, 1.5, wall);

    // Bathroom wall Z = -0.6 solid, X = 8.0 with doorway Z in [-2.05, -1.15]
    this.ctx.addWallBox(8.0, 10.4, y, yTop, -0.65, -0.55, tileWall);
    this.ctx.addWallBox(7.92, 8.08, y, yTop, -3.0, -2.05, tileWall);
    this.ctx.addWallBox(7.92, 8.08, y, yTop, -1.15, -0.6, tileWall);
    this.ctx.addWallBox(7.92, 8.08, y + 2.1, yTop, -2.05, -1.15, tileWall, false);

    this.ctx.buildInteriorDoor({
      id: 'apt14_bath_door',
      title: 'Дверь в ванную (кв. 14)',
      x: 8.0,
      y,
      z: -1.6,
      rotY: -Math.PI / 2,
    });

    // Radio Workbench Table + Bathroom sink
    this.addFurnitureBox(6.85, y, -2.25, 1.15, 0.78, 0.65, this.ctx.mats.furnitureWood);
    this.addFurnitureBox(9.0, y, -2.75, 0.7, 0.84, 0.45, this.ctx.mats.lampGlassOff);

    // Hiding Spots
    this.ctx.registerHidingSpot({
      id: 'hide_apt14_wardrobe',
      name: 'Шкаф в кв. 14',
      pos: new THREE.Vector3(5.75, y, -2.5),
      size: new THREE.Vector3(0.85, 2.08, 0.72),
      camOffset: new THREE.Vector3(0, 1.44, 0.08),
      lookYaw: Math.PI,
      returnOffset: new THREE.Vector3(0, 0, 0.95),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt14_under_bed',
      name: 'Под кроватью в кв. 14',
      pos: new THREE.Vector3(7.15, y, 0.8),
      size: new THREE.Vector3(1.6, 0.62, 1.1),
      camOffset: new THREE.Vector3(-0.05, 0.34, -0.2),
      lookYaw: 0,
      returnOffset: new THREE.Vector3(-0.2, 0, -1.05),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt14_bathroom',
      name: 'Тёмный угол в ванной кв. 14',
      pos: new THREE.Vector3(9.85, y, -2.45),
      size: new THREE.Vector3(0.75, 1.9, 0.75),
      camOffset: new THREE.Vector3(-0.1, 1.25, 0.08),
      lookYaw: Math.PI * 0.3,
      returnOffset: new THREE.Vector3(-0.95, 0, 0.15),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.addApartmentLamp(5, 6.7, y, -0.35, 0xd8a866, 0.82, 'flicker');

    this.ctx.spawnWorldNote(
      'note_apt_14',
      STORY_NOTES.note_apt_14,
      new THREE.Vector3(6.65, y + 0.79, -2.2),
    );
    this.ctx.spawnWorldItem({
      id: 'item_apt14_medkit',
      itemId: 'medkit',
      label: 'Аптечка',
      pos: new THREE.Vector3(7.1, y + 0.84, -2.3),
      color: 0xdc2626,
    });
    this.ctx.spawnWorldItem({
      id: 'item_apt14_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(9.0, y + 0.88, -2.75),
      color: 0xeab308,
    });
    this.addInteractiveAudioDevice({
      id: 'apt14_radio',
      kind: 'radio',
      title: 'Коротковолновый приёмник (кв. 14)',
      x: 6.42,
      y: y + 0.78,
      z: -2.25,
      rotY: 0,
      broadcastText: 'Радиоприёмник шипит на частоте чердака. Звук отпугнул бы тишину, но может привлечь охотника!',
    });

    this.ctx.linkNavEdge(
      'f5_east_edge',
      'apt14_main',
      new THREE.Vector3(6.5, y, -0.3),
      5,
      'apt_door_14',
    );
    this.ctx.linkNavEdge(
      'apt14_main',
      'apt14_bath',
      new THREE.Vector3(9.0, y, -1.6),
      5,
      'apt14_bath_door',
    );
  }

  // Floor 2 East: Квартира №5 — Пост охраны с монитором камер видеонаблюдения
  private buildApartment5(): void {
    const y = getFloorBaseY(2);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;

    this.addRoomShell({
      minX: 5.2,
      maxX: 9.8,
      y,
      minZ: -2.6,
      maxZ: 1.5,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });

    this.ctx.addWallBox(5.2, 9.95, y, yTop, -2.75, -2.6, wall);
    this.ctx.addWallBox(5.2, 9.95, y, yTop, 1.5, 1.65, wall);
    this.ctx.addWallBox(9.8, 9.95, y, yTop, -2.6, 1.5, wall);

    // Interior divider at X = 7.5 with open doorway Z in [-0.95, -0.05]
    this.ctx.addWallBox(7.42, 7.58, y, yTop, -2.6, -0.95, wall);
    this.ctx.addWallBox(7.42, 7.58, y, yTop, -0.05, 1.5, wall);
    this.ctx.addWallBox(7.42, 7.58, y + 2.1, yTop, -0.95, -0.05, wall, false);
    this.ctx.buildInteriorDoor({
      id: 'apt5_inner_door',
      title: 'Дверь в комнату охраны (кв. 5)',
      x: 7.5,
      y,
      z: -0.5,
      rotY: -Math.PI / 2,
    });

    // Security Monitor Desk & CRT Screen prop
    this.addFurnitureBox(8.95, y, -1.75, 1.2, 0.78, 0.72, this.ctx.mats.furnitureWood);

    const crtCase = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(0.56, 0.44, 0.4)),
      this.ctx.mats.doorSteel,
    );
    crtCase.position.set(8.95, y + 1.0, -1.85);
    this.ctx.scene.add(crtCase);

    const crtScreenMat = this.ctx.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x0c1c14,
        emissive: 0x22c55e,
        emissiveIntensity: 0.72,
        roughness: 0.25,
      }),
    );
    const crtScreen = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.PlaneGeometry(0.46, 0.34)),
      crtScreenMat,
    );
    crtScreen.position.set(8.95, y + 1.0, -1.645);
    this.ctx.scene.add(crtScreen);

    this.ctx.interaction.register({
      id: 'cctv_monitor_apt5',
      mesh: crtCase,
      title: 'Монитор видеонаблюдения',
      actionText: 'Смотреть камеры подъезда',
      category: 'cctv',
      onInteract: () => {
        this.ctx.onOpenCCTV();
      },
    });

    // Hiding Spots in Apt 5
    this.ctx.registerHidingSpot({
      id: 'hide_apt5_wardrobe',
      name: 'Шкаф в прихожей кв. 5',
      pos: new THREE.Vector3(5.85, y, -2.15),
      size: new THREE.Vector3(0.85, 2.05, 0.7),
      camOffset: new THREE.Vector3(0, 1.42, 0.08),
      lookYaw: Math.PI,
      returnOffset: new THREE.Vector3(0, 0, 0.9),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt5_corner',
      name: 'За шкафом охраны (кв. 5)',
      pos: new THREE.Vector3(9.25, y, 0.95),
      size: new THREE.Vector3(0.8, 1.9, 0.75),
      camOffset: new THREE.Vector3(-0.08, 1.2, -0.05),
      lookYaw: -Math.PI * 0.7,
      returnOffset: new THREE.Vector3(-0.95, 0, -0.15),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.addApartmentLamp(2, 6.4, y, -0.35, 0xc4e0b8, 0.75, 'flicker');
    this.addApartmentLamp(2, 8.6, y, -0.6, 0x86efac, 0.65, 'flicker');

    this.ctx.spawnWorldNote(
      'note_apt_5',
      STORY_NOTES.note_apt_5,
      new THREE.Vector3(8.55, y + 0.79, -1.65),
    );

    if (this.ctx.nightSeed.itemVariant === 1) {
      this.ctx.spawnWorldItem({
        id: 'item_apt5_battery',
        itemId: 'battery',
        label: 'Батарейка',
        pos: new THREE.Vector3(9.3, y + 0.79, -1.65),
        color: 0xeab308,
      });
    } else {
      this.ctx.spawnWorldItem({
        id: 'item_apt5_medkit',
        itemId: 'medkit',
        label: 'Аптечка',
        pos: new THREE.Vector3(9.3, y + 0.82, -1.65),
        color: 0xdc2626,
      });
    }

    // Code Clue Part 2 on Guard Wall Board + Code Lock Safe Cabinet in Apt 5
    const lastTwo = this.ctx.nightSeed.keypadCode.slice(2, 4);
    const boardPlaque = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.PlaneGeometry(0.46, 0.28)),
      this.ctx.mats.createStencilPlateMaterial(
        `КОД: --${lastTwo}`,
        '#182026',
        '#93c5fd',
        160,
        96,
      ),
    );
    boardPlaque.position.set(8.95, y + 1.56, -2.58);
    this.ctx.scene.add(boardPlaque);
    this.ctx.interaction.register({
      id: 'apt5_code_scrap',
      mesh: boardPlaque,
      title: 'Табличка смены охраны',
      actionText: 'Прочитать запись',
      category: 'note',
      onInteract: () => {
        this.ctx.sound.playPaperPickup();
        this.ctx.onSubtitle(
          `Запись на посту: последние две цифры кодового шкафа «--${lastTwo}» (начало — в кв. 2).`,
        );
      },
    });

    const safeBox = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(0.42, 0.88, 0.56)),
      this.ctx.mats.fuseBoxMetal,
    );
    safeBox.position.set(9.56, y + 0.44, -0.35);
    this.ctx.scene.add(safeBox);

    const safeLedMat = this.ctx.mats.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x111111,
        emissive: 0xef4444,
        emissiveIntensity: 1.3,
      }),
    );
    const safeLed = new THREE.Mesh(
      this.ctx.trackGeo(new THREE.BoxGeometry(0.04, 0.06, 0.06)),
      safeLedMat,
    );
    safeLed.position.set(9.34, y + 0.65, -0.35);
    this.ctx.scene.add(safeLed);

    const unlockSafe = (silent = false) => {
      this.ctx.unlockedKeypads.add('apt5_code_locker');
      safeLedMat.emissive.setHex(0x22c55e);
      if (!silent) {
        this.ctx.onSecretFound();
      }
    };
    this.ctx.dynamicUnlockers.set('apt5_code_locker', () => unlockSafe(true));

    this.ctx.interaction.register({
      id: 'apt5_code_locker',
      mesh: safeBox,
      title: 'Кодовый шкаф охраны',
      actionText: 'Ввести 4-значный код',
      category: 'keypad',
      onInteract: () => {
        if (this.ctx.unlockedKeypads.has('apt5_code_locker')) {
          this.ctx.onSubtitle('Шкаф охраны уже открыт и осмотрен.');
          return;
        }
        this.ctx.onOpenKeypad({
          id: 'apt5_code_locker',
          title: 'Кодовый шкаф поста охраны (кв. 5)',
          hint: 'Первые 2 цифры — на обрывке в кв. 2, последние 2 — на табличке прямо у стола охраны.',
          expectedCode: this.ctx.nightSeed.keypadCode,
          onUnlocked: () => {
            unlockSafe(false);
            this.ctx.spawnWorldItem({
              id: 'item_safe5_battery',
              itemId: 'battery',
              label: 'Батарейка из сейфа',
              pos: new THREE.Vector3(9.12, y + 0.1, -0.35),
              color: 0xeab308,
            });
            this.ctx.spawnWorldItem({
              id: 'item_safe5_medkit',
              itemId: 'medkit',
              label: 'Аптечка из сейфа',
              pos: new THREE.Vector3(9.12, y + 0.1, -0.05),
              color: 0xdc2626,
            });
            if (this.ctx.nightSeed.isNewGamePlus) {
              this.ctx.spawnWorldNote(
                'note_ng_plus_manifest',
                STORY_NOTES.note_ng_plus_manifest,
                new THREE.Vector3(9.12, y + 0.04, -0.65),
              );
            }
            this.ctx.onSubtitle(
              'Код подошёл! Дверца шкафа щёлкнула — внутри лежат припасы.',
            );
          },
        });
      },
    });

    this.ctx.linkNavEdge(
      'f2_east_edge',
      'apt5_main',
      new THREE.Vector3(6.4, y, -0.35),
      2,
      'apt_door_5',
    );
    this.ctx.linkNavEdge(
      'apt5_main',
      'apt5_security',
      new THREE.Vector3(8.4, y, -0.5),
      2,
      'apt5_inner_door',
    );
  }

  // Floor 4 East: Секретная квартира №11 (Архив прежних жильцов)
  private buildApartment11(): void {
    const y = getFloorBaseY(4);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;

    this.addRoomShell({
      minX: 5.2,
      maxX: 10.0,
      y,
      minZ: -2.8,
      maxZ: 1.5,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });

    this.ctx.addWallBox(5.2, 10.15, y, yTop, -2.95, -2.8, wall);
    this.ctx.addWallBox(5.2, 10.15, y, yTop, 1.5, 1.65, wall);
    this.ctx.addWallBox(10.0, 10.15, y, yTop, -2.8, 1.5, wall);

    // Interior partition X = 7.7 (doorway Z in [-1.4, -0.5])
    this.ctx.addWallBox(7.62, 7.78, y, yTop, -2.8, -1.4, wall);
    this.ctx.addWallBox(7.62, 7.78, y, yTop, -0.5, 1.5, wall);
    this.ctx.addWallBox(7.62, 7.78, y + 2.1, yTop, -1.4, -0.5, wall, false);
    this.ctx.buildInteriorDoor({
      id: 'apt11_archive_door',
      title: 'Дверь в архивную кладовую (кв. 11)',
      x: 7.7,
      y,
      z: -0.95,
      rotY: -Math.PI / 2,
    });

    // Archive table & dusty shelving
    this.addFurnitureBox(6.6, y, 0.85, 1.3, 0.76, 0.72, this.ctx.mats.furnitureWood);
    this.addFurnitureBox(9.2, y, -2.2, 0.9, 1.85, 0.55, this.ctx.mats.furnitureWood, true);

    this.ctx.registerHidingSpot({
      id: 'hide_apt11_wardrobe',
      name: 'Старый шифоньер (кв. 11)',
      pos: new THREE.Vector3(5.85, y, -2.3),
      size: new THREE.Vector3(0.85, 2.08, 0.72),
      camOffset: new THREE.Vector3(0, 1.44, 0.08),
      lookYaw: Math.PI,
      returnOffset: new THREE.Vector3(0, 0, 0.95),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt11_archive_nook',
      name: 'Тёмный угол за стеллажом (кв. 11)',
      pos: new THREE.Vector3(9.45, y, 0.95),
      size: new THREE.Vector3(0.75, 1.85, 0.75),
      camOffset: new THREE.Vector3(-0.08, 1.2, -0.05),
      lookYaw: -Math.PI * 0.7,
      returnOffset: new THREE.Vector3(-0.95, 0, -0.15),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.addApartmentLamp(4, 6.5, y, -0.35, 0xd8a668, 0.78, 'flicker');

    this.ctx.spawnWorldNote(
      'note_apt_11',
      STORY_NOTES.note_apt_11,
      new THREE.Vector3(6.6, y + 0.77, 0.85),
    );

    if (this.ctx.nightSeed.secretVariant === 1) {
      this.ctx.spawnWorldNote(
        'note_night_dossier',
        STORY_NOTES.note_night_dossier,
        new THREE.Vector3(8.7, y + 0.02, -0.95),
      );
    }

    this.ctx.spawnWorldItem({
      id: 'item_apt11_medkit',
      itemId: 'medkit',
      label: 'Аптечка',
      pos: new THREE.Vector3(6.95, y + 0.8, 0.85),
      color: 0xdc2626,
    });

    this.ctx.linkNavEdge(
      'f4_east_edge',
      'apt11_main',
      new THREE.Vector3(6.4, y, -0.35),
      4,
      'apt_door_11',
    );
    this.ctx.linkNavEdge(
      'apt11_main',
      'apt11_archive',
      new THREE.Vector3(8.7, y, -0.95),
      4,
      'apt11_archive_door',
    );
  }

  // Floor 5 North: Квартира №13 (Старая спальня)
  private buildApartment13(): void {
    const y = getFloorBaseY(5);
    const yTop = y + 3.2;
    const wall = this.ctx.mats.wallApartmentPaper;

    this.addRoomShell({
      minX: 1.4,
      maxX: 5.2,
      y,
      minZ: -6.4,
      maxZ: -2.1,
      floorMat: this.ctx.mats.floorWoodParquet,
      surfaceKind: 'wood',
    });

    this.ctx.addWallBox(1.25, 1.4, y, yTop, -6.55, -2.1, wall);
    this.ctx.addWallBox(5.2, 5.35, y, yTop, -6.55, -2.1, wall);
    this.ctx.addWallBox(1.25, 5.35, y, yTop, -6.55, -6.4, wall);

    // Interior wall Z = -4.05 (doorway X in [2.35, 3.25])
    this.ctx.addWallBox(1.4, 2.35, y, yTop, -4.12, -3.98, wall);
    this.ctx.addWallBox(3.25, 5.2, y, yTop, -4.12, -3.98, wall);
    this.ctx.addWallBox(2.35, 3.25, y + 2.1, yTop, -4.12, -3.98, wall, false);
    this.ctx.buildInteriorDoor({
      id: 'apt13_bed_door',
      title: 'Дверь в дальнюю комнату (кв. 13)',
      x: 2.8,
      y,
      z: -4.05,
      rotY: 0,
    });

    this.addFurnitureBox(4.4, y, -3.2, 0.85, 0.76, 0.9, this.ctx.mats.furnitureWood);

    this.ctx.registerHidingSpot({
      id: 'hide_apt13_wardrobe',
      name: 'Шкаф в кв. 13',
      pos: new THREE.Vector3(1.85, y, -3.35),
      size: new THREE.Vector3(0.75, 2.05, 1.0),
      camOffset: new THREE.Vector3(0.08, 1.42, 0),
      lookYaw: -Math.PI * 0.5,
      returnOffset: new THREE.Vector3(0.95, 0, 0),
      meshMat: this.ctx.mats.furnitureWood,
    });

    this.ctx.registerHidingSpot({
      id: 'hide_apt13_under_bed',
      name: 'Под кроватью в кв. 13',
      pos: new THREE.Vector3(4.35, y, -5.45),
      size: new THREE.Vector3(1.15, 0.62, 1.65),
      camOffset: new THREE.Vector3(-0.2, 0.34, 0.05),
      lookYaw: Math.PI * 0.55,
      returnOffset: new THREE.Vector3(-1.05, 0, 0),
      meshMat: this.ctx.mats.fabricDark,
    });

    this.addApartmentLamp(5, 3.3, y, -3.1, 0xd8a86a, 0.72, 'flicker');

    this.ctx.spawnWorldNote(
      'note_apt_13',
      STORY_NOTES.note_apt_13,
      new THREE.Vector3(4.4, y + 0.77, -3.2),
    );
    this.ctx.spawnWorldItem({
      id: 'item_apt13_battery',
      itemId: 'battery',
      label: 'Батарейка',
      pos: new THREE.Vector3(4.2, y + 0.81, -3.05),
      color: 0xeab308,
    });
    this.addFurnitureBox(2.0, y, -5.8, 0.56, 0.5, 0.44, this.ctx.mats.furnitureWood);
    this.addInteractiveAudioDevice({
      id: 'apt13_old_tv',
      kind: 'tv',
      title: 'Старый телевизор (кв. 13)',
      x: 2.0,
      y: y + 0.5,
      z: -5.8,
      rotY: Math.PI / 4,
      broadcastText: 'Сквозь белый шум телевизора проступил тихий шёпот...',
    });

    this.ctx.linkNavEdge(
      'f5_east',
      'apt13_main',
      new THREE.Vector3(3.3, y, -3.1),
      5,
      'apt_door_13',
    );
    this.ctx.linkNavEdge(
      'apt13_main',
      'apt13_bed',
      new THREE.Vector3(2.8, y, -5.2),
      5,
      'apt13_bed_door',
    );
  }
}
