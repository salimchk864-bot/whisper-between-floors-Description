import * as THREE from 'three';

export class MaterialLibrary {
  private textures: THREE.Texture[] = [];
  private materials: THREE.Material[] = [];

  public readonly wallStairwell: THREE.MeshStandardMaterial;
  public readonly wallBasementBrick: THREE.MeshStandardMaterial;
  public readonly wallAtticPlanks: THREE.MeshStandardMaterial;
  public readonly wallApartmentPaper: THREE.MeshStandardMaterial;
  public readonly ceilingConcrete: THREE.MeshStandardMaterial;
  public readonly floorTile: THREE.MeshStandardMaterial;
  public readonly concreteStep: THREE.MeshStandardMaterial;
  public readonly stairNosing: THREE.MeshStandardMaterial;
  public readonly railingMetal: THREE.MeshStandardMaterial;
  public readonly handrailWood: THREE.MeshStandardMaterial;
  public readonly elevatorSteel: THREE.MeshStandardMaterial;
  public readonly elevatorFloor: THREE.MeshStandardMaterial;
  public readonly doorWood: THREE.MeshStandardMaterial;
  public readonly doorSteel: THREE.MeshStandardMaterial;
  public readonly trimDark: THREE.MeshStandardMaterial;
  public readonly brassAccent: THREE.MeshStandardMaterial;
  public readonly fuseBoxMetal: THREE.MeshStandardMaterial;
  public readonly mailboxMetal: THREE.MeshStandardMaterial;
  public readonly pipeMetal: THREE.MeshStandardMaterial;
  public readonly generatorMetal: THREE.MeshStandardMaterial;
  public readonly furnitureWood: THREE.MeshStandardMaterial;
  public readonly fabricDark: THREE.MeshStandardMaterial;
  public readonly windowGlass: THREE.MeshStandardMaterial;
  public readonly lampGlassOff: THREE.MeshStandardMaterial;
  public readonly paperNote: THREE.MeshStandardMaterial;
  public readonly floorWoodParquet: THREE.MeshStandardMaterial;
  public readonly tileBathroom: THREE.MeshStandardMaterial;
  public readonly monsterSkin: THREE.MeshStandardMaterial;
  public readonly monsterFace: THREE.MeshStandardMaterial;
  public readonly monsterCoat: THREE.MeshStandardMaterial;
  public readonly monsterBoots: THREE.MeshStandardMaterial;
  public readonly monsterSclera: THREE.MeshStandardMaterial;
  public readonly monsterPupil: THREE.MeshStandardMaterial;

  constructor(maxAnisotropy: number, isSoftwareGl: boolean) {
    const wallTex = this.createWallTexture(maxAnisotropy);
    const plasterBump = this.createNoiseBumpTexture(256, 26, maxAnisotropy);
    this.wallStairwell = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: wallTex,
        bumpMap: plasterBump,
        bumpScale: 0.015,
        roughness: 0.88,
        metalness: 0.04,
      }),
    );

    const brickTex = this.createBrickTexture(maxAnisotropy);
    this.wallBasementBrick = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: brickTex,
        bumpMap: plasterBump,
        bumpScale: 0.024,
        roughness: 0.94,
        metalness: 0.03,
      }),
    );

    const atticWoodTex = this.createPlankTexture('#33261c', '#211711', maxAnisotropy);
    this.wallAtticPlanks = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: atticWoodTex,
        roughness: 0.86,
        metalness: 0.04,
      }),
    );

    const aptWallpaperTex = this.createWallpaperTexture(maxAnisotropy);
    this.wallApartmentPaper = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: aptWallpaperTex,
        roughness: 0.85,
        metalness: 0.02,
      }),
    );

    const ceilingTex = this.createConcreteTexture('#323438', '#25272b', 256, maxAnisotropy, 3);
    this.ceilingConcrete = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: ceilingTex,
        roughness: 0.94,
        metalness: 0.02,
      }),
    );

    const tileTex = this.createFloorTileTexture(maxAnisotropy);
    this.floorTile = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: tileTex,
        bumpMap: plasterBump,
        bumpScale: 0.008,
        roughness: 0.72,
        metalness: 0.06,
      }),
    );

    const stepTex = this.createConcreteTexture('#4f514f', '#383a39', 256, maxAnisotropy, 2);
    this.concreteStep = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: stepTex,
        roughness: 0.9,
        metalness: 0.04,
      }),
    );

    this.stairNosing = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x222526,
        roughness: 0.65,
        metalness: 0.35,
      }),
    );

    this.railingMetal = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x2b3330,
        roughness: 0.58,
        metalness: 0.62,
      }),
    );

    this.handrailWood = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x3b2318,
        roughness: 0.52,
        metalness: 0.08,
      }),
    );

    const steelTex = this.createBrushedSteelTexture(maxAnisotropy);
    this.elevatorSteel = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: steelTex,
        roughness: 0.38,
        metalness: 0.78,
      }),
    );

    const rubberTex = this.createConcreteTexture('#1e2024', '#131518', 128, maxAnisotropy, 2);
    this.elevatorFloor = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: rubberTex,
        roughness: 0.82,
        metalness: 0.1,
      }),
    );

    const woodTex = this.createWoodDoorTexture(maxAnisotropy);
    this.doorWood = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: woodTex,
        roughness: 0.64,
        metalness: 0.06,
      }),
    );

    this.doorSteel = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x282b2e,
        roughness: 0.48,
        metalness: 0.68,
      }),
    );

    this.trimDark = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x1e1a18,
        roughness: 0.75,
        metalness: 0.12,
      }),
    );

    this.brassAccent = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x9c7c3e,
        roughness: 0.34,
        metalness: 0.85,
      }),
    );

    this.fuseBoxMetal = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x454d4a,
        roughness: 0.56,
        metalness: 0.54,
      }),
    );

    this.mailboxMetal = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x3a4854,
        roughness: 0.52,
        metalness: 0.62,
      }),
    );

    this.pipeMetal = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x363b38,
        roughness: 0.48,
        metalness: 0.72,
      }),
    );

    this.generatorMetal = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x4d3726,
        roughness: 0.54,
        metalness: 0.65,
      }),
    );

    this.furnitureWood = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x382419,
        roughness: 0.68,
        metalness: 0.05,
      }),
    );

    this.fabricDark = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x2d2424,
        roughness: 0.92,
        metalness: 0.02,
      }),
    );

    this.windowGlass = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x22303c,
        emissive: 0x0b141e,
        emissiveIntensity: 0.45,
        roughness: isSoftwareGl ? 0.45 : 0.25,
        metalness: 0.1,
        transparent: true,
        opacity: 0.62,
        depthWrite: false,
      }),
    );

    this.lampGlassOff = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x62655d,
        roughness: 0.4,
        metalness: 0.1,
      }),
    );

    this.paperNote = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xc9bfa8,
        roughness: 0.92,
        metalness: 0.0,
      }),
    );

    const parquetTex = this.createPlankTexture('#3e2a1d', '#24170f', maxAnisotropy);
    this.floorWoodParquet = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: parquetTex,
        bumpMap: plasterBump,
        bumpScale: 0.01,
        roughness: 0.72,
        metalness: 0.04,
      }),
    );

    const bathTex = this.createBathroomTileTexture(maxAnisotropy);
    this.tileBathroom = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: bathTex,
        roughness: 0.42,
        metalness: 0.08,
      }),
    );

    const mSkinTex = this.createMonsterSkinTexture(maxAnisotropy);
    const mFaceTex = this.createMonsterFaceTexture(maxAnisotropy);
    const mCoatTex = this.createMonsterCoatTexture(maxAnisotropy);

    this.monsterSkin = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: mSkinTex,
        bumpMap: plasterBump,
        bumpScale: 0.016,
        roughness: 0.74,
        metalness: 0.02,
      }),
    );

    this.monsterFace = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: mFaceTex,
        bumpMap: plasterBump,
        bumpScale: 0.018,
        roughness: 0.68,
        metalness: 0.03,
      }),
    );

    this.monsterCoat = this.trackMat(
      new THREE.MeshStandardMaterial({
        map: mCoatTex,
        bumpMap: plasterBump,
        bumpScale: 0.02,
        roughness: 0.91,
        metalness: 0.04,
      }),
    );

    this.monsterBoots = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x111010,
        roughness: 0.56,
        metalness: 0.14,
      }),
    );

    this.monsterSclera = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0xcfc4b4,
        emissive: 0x2b241d,
        emissiveIntensity: 0.22,
        roughness: 0.22,
        metalness: 0.05,
      }),
    );

    this.monsterPupil = this.trackMat(
      new THREE.MeshStandardMaterial({
        color: 0x050506,
        roughness: 0.08,
        metalness: 0.15,
      }),
    );
  }

  public createStencilPlateMaterial(
    text: string,
    bgColor = '#3f5247',
    fgColor = '#cfd4cc',
    width = 128,
    height = 128,
  ): THREE.MeshStandardMaterial {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);

    for (let i = 0; i < 160; i++) {
      ctx.fillStyle = `rgba(10,12,10,${Math.random() * 0.12})`;
      ctx.fillRect(Math.random() * width, Math.random() * height, 4, 4);
    }

    ctx.fillStyle = fgColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `bold ${Math.floor(height * 0.5)}px monospace`;
    ctx.fillText(text, width / 2, height / 2);

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.textures.push(tex);

    return this.trackMat(
      new THREE.MeshStandardMaterial({
        map: tex,
        roughness: 0.72,
        metalness: 0.15,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      }),
    );
  }

  private createWallTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#6f7069';
    ctx.fillRect(0, 0, 512, 246);
    ctx.fillStyle = '#31443a';
    ctx.fillRect(0, 246, 512, 266);
    ctx.fillStyle = '#1e2722';
    ctx.fillRect(0, 244, 512, 8);

    for (let i = 0; i < 520; i++) {
      const x = Math.random() * 512;
      const y = Math.random() * 512;
      const r = 2 + Math.random() * 14;
      ctx.fillStyle =
        y < 246
          ? `rgba(38, 40, 36, ${Math.random() * 0.14})`
          : `rgba(15, 22, 18, ${Math.random() * 0.18})`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    for (let i = 0; i < 24; i++) {
      const x = Math.random() * 512;
      const y = 80 + Math.random() * 200;
      const h = 40 + Math.random() * 140;
      const grad = ctx.createLinearGradient(x, y, x, y + h);
      grad.addColorStop(0, 'rgba(18, 22, 18, 0.25)');
      grad.addColorStop(1, 'rgba(18, 22, 18, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(x, y, 3 + Math.random() * 6, h);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.repeat.set(2, 1);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createBrickTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#2c2522';
    ctx.fillRect(0, 0, 256, 256);

    const rows = 8;
    const cols = 4;
    const bh = 256 / rows;
    const bw = 256 / cols;

    for (let r = 0; r < rows; r++) {
      const offset = (r % 2) * (bw / 2);
      for (let c = -1; c <= cols; c++) {
        const shade = 48 + Math.random() * 26;
        ctx.fillStyle = `rgb(${shade + 12}, ${shade}, ${shade - 4})`;
        ctx.fillRect(c * bw + offset + 2, r * bh + 2, bw - 4, bh - 4);
      }
    }

    // Damp mold patches
    for (let i = 0; i < 65; i++) {
      ctx.fillStyle = `rgba(10, 14, 10, ${Math.random() * 0.25})`;
      ctx.beginPath();
      ctx.arc(Math.random() * 256, Math.random() * 256, 6 + Math.random() * 18, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(3, 2);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createPlankTexture(base: string, line: string, anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);

    ctx.fillStyle = line;
    for (let y = 0; y < 256; y += 32) {
      ctx.fillRect(0, y, 256, 3);
    }
    for (let i = 0; i < 200; i++) {
      ctx.fillStyle = `rgba(0,0,0,${Math.random() * 0.2})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 30, 2);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 2);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createWallpaperTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#4e483d';
    ctx.fillRect(0, 0, 256, 256);

    for (let x = 0; x < 256; x += 24) {
      ctx.fillStyle = 'rgba(32, 28, 22, 0.28)';
      ctx.fillRect(x, 0, 6, 256);
    }
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = `rgba(25, 22, 18, ${Math.random() * 0.3})`;
      ctx.fillRect(Math.random() * 256, Math.random() * 256, 16, 26);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(3, 1);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createFloorTileTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#3b3d3c';
    ctx.fillRect(0, 0, 512, 512);

    const tiles = 4;
    const size = 512 / tiles;
    for (let gx = 0; gx < tiles; gx++) {
      for (let gy = 0; gy < tiles; gy++) {
        const shade = 52 + ((gx + gy) % 2) * 8 + (Math.random() * 8 - 4);
        ctx.fillStyle = `rgb(${shade}, ${shade + 1}, ${shade - 1})`;
        ctx.fillRect(gx * size + 2, gy * size + 2, size - 4, size - 4);
      }
    }

    for (let i = 0; i < 1400; i++) {
      ctx.fillStyle =
        Math.random() > 0.5 ? 'rgba(20,20,20,0.22)' : 'rgba(130,130,125,0.12)';
      ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 2);
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 3);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createConcreteTexture(
    baseHex: string,
    speckHex: string,
    size: number,
    anisotropy: number,
    repeat = 2,
  ): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = baseHex;
    ctx.fillRect(0, 0, size, size);

    ctx.fillStyle = speckHex;
    for (let i = 0; i < 700; i++) {
      ctx.globalAlpha = Math.random() * 0.35;
      ctx.fillRect(
        Math.random() * size,
        Math.random() * size,
        1 + Math.random() * 4,
        1 + Math.random() * 4,
      );
    }
    ctx.globalAlpha = 1;

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(repeat, repeat);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createBrushedSteelTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#4e5458';
    ctx.fillRect(0, 0, 256, 256);

    for (let y = 0; y < 256; y += 2) {
      ctx.fillStyle = `rgba(220,230,235,${Math.random() * 0.08})`;
      ctx.fillRect(0, y, 256, 1);
    }

    for (let i = 0; i < 40; i++) {
      ctx.strokeStyle = `rgba(25,28,30,${0.15 + Math.random() * 0.25})`;
      ctx.beginPath();
      const x = Math.random() * 256;
      const y = Math.random() * 256;
      ctx.moveTo(x, y);
      ctx.lineTo(x + (Math.random() - 0.5) * 60, y + (Math.random() - 0.5) * 20);
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createWoodDoorTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#332018';
    ctx.fillRect(0, 0, 256, 512);

    for (let x = 0; x < 256; x += 3) {
      ctx.fillStyle = `rgba(20, 10, 6, ${Math.random() * 0.28})`;
      ctx.fillRect(x, 0, 2, 512);
    }

    ctx.strokeStyle = '#1b0f0a';
    ctx.lineWidth = 6;
    ctx.strokeRect(32, 36, 192, 180);
    ctx.strokeRect(32, 256, 192, 210);

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createNoiseBumpTexture(
    size: number,
    intensity: number,
    anisotropy: number,
  ): THREE.DataTexture {
    const data = new Uint8Array(size * size * 4);
    for (let i = 0; i < size * size; i++) {
      const v = 128 + (Math.random() - 0.5) * intensity;
      data[i * 4] = v;
      data[i * 4 + 1] = v;
      data[i * 4 + 2] = v;
      data[i * 4 + 3] = 255;
    }
    const tex = new THREE.DataTexture(data, size, size);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(3, 3);
    tex.anisotropy = anisotropy;
    tex.needsUpdate = true;
    this.textures.push(tex);
    return tex;
  }

  private createBathroomTileTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#3a4547';
    ctx.fillRect(0, 0, 256, 256);

    const step = 32;
    for (let y = 0; y < 256; y += step) {
      for (let x = 0; x < 256; x += step) {
        const v = 56 + ((x + y) % 64 === 0 ? 10 : 0) + (Math.random() * 10 - 5);
        ctx.fillStyle = `rgb(${v}, ${v + 12}, ${v + 14})`;
        ctx.fillRect(x + 2, y + 2, step - 3, step - 3);
      }
    }
    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = `rgba(14, 18, 16, ${Math.random() * 0.24})`;
      ctx.beginPath();
      ctx.arc(Math.random() * 256, Math.random() * 256, 4 + Math.random() * 12, 0, Math.PI * 2);
      ctx.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(2, 2);
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createMonsterSkinTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Ashen bruised pale skin
    ctx.fillStyle = '#5e5650';
    ctx.fillRect(0, 0, 256, 256);

    for (let i = 0; i < 320; i++) {
      const shade = 64 + Math.random() * 34;
      ctx.fillStyle = `rgba(${shade}, ${shade - 8}, ${shade - 12}, 0.28)`;
      ctx.beginPath();
      ctx.arc(Math.random() * 256, Math.random() * 256, 3 + Math.random() * 10, 0, Math.PI * 2);
      ctx.fill();
    }

    // Subtle dark veins & grime
    ctx.strokeStyle = 'rgba(34, 24, 26, 0.35)';
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 24; i++) {
      ctx.beginPath();
      let x = Math.random() * 256;
      let y = Math.random() * 256;
      ctx.moveTo(x, y);
      for (let s = 0; s < 4; s++) {
        x += (Math.random() - 0.5) * 34;
        y += (Math.random() - 0.5) * 34;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createMonsterFaceTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#625852';
    ctx.fillRect(0, 0, 256, 256);

    // Mottled grime across skin
    for (let i = 0; i < 260; i++) {
      ctx.fillStyle = `rgba(32, 26, 24, ${Math.random() * 0.22})`;
      ctx.beginPath();
      ctx.arc(Math.random() * 256, Math.random() * 256, 2 + Math.random() * 9, 0, Math.PI * 2);
      ctx.fill();
    }

    // UV map of front face lies around U = 0.5 (x = 128), V = 0.5 (y = 128)
    // Sunken eye socket shadows
    for (const ex of [104, 152]) {
      const grad = ctx.createRadialGradient(ex, 114, 3, ex, 114, 22);
      grad.addColorStop(0, 'rgba(14, 10, 10, 0.88)');
      grad.addColorStop(1, 'rgba(14, 10, 10, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(ex - 24, 90, 48, 48);
    }

    // Hollowed cheek contours & scarred mouth crease
    ctx.fillStyle = 'rgba(26, 20, 18, 0.55)';
    ctx.beginPath();
    ctx.ellipse(95, 150, 12, 22, 0.3, 0, Math.PI * 2);
    ctx.ellipse(161, 150, 12, 22, -0.3, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = 'rgba(18, 12, 12, 0.8)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(106, 174);
    ctx.quadraticCurveTo(128, 168, 150, 175);
    ctx.stroke();

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  private createMonsterCoatTexture(anisotropy: number): THREE.CanvasTexture {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#15171a';
    ctx.fillRect(0, 0, 256, 256);

    // Coarse weave threads
    for (let y = 0; y < 256; y += 3) {
      ctx.fillStyle = `rgba(38, 42, 46, ${Math.random() * 0.25})`;
      ctx.fillRect(0, y, 256, 1);
    }
    for (let x = 0; x < 256; x += 4) {
      ctx.fillStyle = `rgba(10, 11, 13, ${Math.random() * 0.3})`;
      ctx.fillRect(x, 0, 2, 256);
    }

    // Damp lower hem stains & tattered streaks
    const hemGrad = ctx.createLinearGradient(0, 160, 0, 256);
    hemGrad.addColorStop(0, 'rgba(12, 11, 10, 0)');
    hemGrad.addColorStop(1, 'rgba(6, 5, 5, 0.85)');
    ctx.fillStyle = hemGrad;
    ctx.fillRect(0, 160, 256, 96);

    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.anisotropy = anisotropy;
    this.textures.push(tex);
    return tex;
  }

  public trackMat<T extends THREE.Material>(mat: T): T {
    this.materials.push(mat);
    return mat;
  }

  public dispose(): void {
    this.textures.forEach((t) => t.dispose());
    this.materials.forEach((m) => m.dispose());
  }
}
