import { InventoryItem } from '../types';

export const MAX_INVENTORY_SLOTS = 8;

export const ITEM_CATALOG: Record<string, Omit<InventoryItem, 'quantity'>> = {
  key_basement: {
    id: 'key_basement',
    name: 'Ключ от подвала',
    description: 'Тяжёлый ржавый ключ от железной двери в подвал на 1 этаже.',
    kind: 'key',
    maxStack: 1,
  },
  key_apt7: {
    id: 'key_apt7',
    name: 'Ключ от кв. 7',
    description: 'Латунный ключ с потёртой биркой «7». Подходит к квартире на 3 этаже.',
    kind: 'key',
    maxStack: 1,
  },
  key_apt10: {
    id: 'key_apt10',
    name: 'Ключ от кв. 10',
    description: 'Старый ключ от заброшенной квартиры №10 на 4 этаже.',
    kind: 'key',
    maxStack: 1,
  },
  key_attic: {
    id: 'key_attic',
    name: 'Ключ от чердака',
    description: 'Крупный ключ от навесного замка чердачной двери на 5 этаже.',
    kind: 'key',
    maxStack: 1,
  },
  battery: {
    id: 'battery',
    name: 'Батарейка',
    description: 'Щелочной элемент питания. Восстанавливает +45% заряда фонарика.',
    kind: 'battery',
    maxStack: 3,
  },
  fuse: {
    id: 'fuse',
    name: 'Предохранитель',
    description: 'Высоковольтная вставка для генератора в электрощитовой или щитков.',
    kind: 'fuse',
    maxStack: 4,
  },
  fuel: {
    id: 'fuel',
    name: 'Канистра топлива',
    description: 'Пятилитровая канистра дизеля для запуска подвального генератора.',
    kind: 'fuel',
    maxStack: 1,
  },
  screwdriver: {
    id: 'screwdriver',
    name: 'Отвёртка',
    description: 'Крепкая плоская отвёртка. Открывает вентрешётки и потайные панели.',
    kind: 'screwdriver',
    maxStack: 1,
  },
  medkit: {
    id: 'medkit',
    name: 'Аптечка',
    description: 'Бинты и антисептик. Восстанавливает +50 здоровья.',
    kind: 'medkit',
    maxStack: 2,
  },
  tape_4: {
    id: 'tape_4',
    name: 'Кассета №4',
    description: 'Магнитная лента с кодом глушения из секретной комнаты. Используется на чердаке.',
    kind: 'story',
    maxStack: 1,
  },
};

export class InventorySystem {
  private items: InventoryItem[] = [];

  public setItems(items: InventoryItem[]): void {
    this.items = items.map((i) => ({ ...i }));
  }

  public getItems(): InventoryItem[] {
    return this.items.map((i) => ({ ...i }));
  }

  public hasItem(itemId: string, minQty = 1): boolean {
    const total = this.items
      .filter((i) => i.id === itemId)
      .reduce((acc, i) => acc + i.quantity, 0);
    return total >= minQty;
  }

  public getCount(itemId: string): number {
    return this.items
      .filter((i) => i.id === itemId)
      .reduce((acc, i) => acc + i.quantity, 0);
  }

  public canAdd(itemId: string): boolean {
    const def = ITEM_CATALOG[itemId];
    if (!def) return false;
    const existing = this.items.find(
      (i) => i.id === itemId && i.quantity < def.maxStack,
    );
    if (existing) return true;
    return this.items.length < MAX_INVENTORY_SLOTS;
  }

  public addItem(itemId: string): boolean {
    const def = ITEM_CATALOG[itemId];
    if (!def) return false;

    const existing = this.items.find(
      (i) => i.id === itemId && i.quantity < def.maxStack,
    );
    if (existing) {
      existing.quantity += 1;
      return true;
    }

    if (this.items.length >= MAX_INVENTORY_SLOTS) {
      return false;
    }

    this.items.push({ ...def, quantity: 1 });
    return true;
  }

  public consumeItem(itemId: string, count = 1): boolean {
    if (!this.hasItem(itemId, count)) return false;
    let remaining = count;
    for (let i = this.items.length - 1; i >= 0 && remaining > 0; i--) {
      const slot = this.items[i];
      if (slot.id !== itemId) continue;
      const take = Math.min(slot.quantity, remaining);
      slot.quantity -= take;
      remaining -= take;
      if (slot.quantity <= 0) {
        this.items.splice(i, 1);
      }
    }
    return true;
  }

  public clear(): void {
    this.items = [];
  }
}
