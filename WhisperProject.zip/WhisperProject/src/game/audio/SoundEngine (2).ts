export class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private droneOsc1: OscillatorNode | null = null;
  private droneOsc2: OscillatorNode | null = null;
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  private elevatorHumGain: GainNode | null = null;
  private elevatorHumOsc: OscillatorNode | null = null;
  private generatorHumGain: GainNode | null = null;
  private generatorHumOsc: OscillatorNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private volume = 0.8;
  private unlocked = false;
  private muted = false;

  public unlock(): void {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;

      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : this.volume;
      this.masterGain.connect(this.ctx.destination);

      this.noiseBuffer = this.createNoiseBuffer(3.0);
      this.startAmbientBed();
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    this.unlocked = true;
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        this.muted ? 0 : this.volume,
        this.ctx.currentTime,
        0.04,
      );
    }
  }

  public setPaused(paused: boolean): void {
    this.muted = paused;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        paused ? 0.1 * this.volume : this.volume,
        this.ctx.currentTime,
        0.08,
      );
    }
  }

  public updateAtmosphere(tension: number, floor: number, generatorOn: boolean): void {
    if (!this.ctx || !this.ambientGain || !this.windGain || !this.windFilter) return;
    const t = this.ctx.currentTime;

    // Basement (floor 0) has deeper transformer hum; Attic (floor 6) has higher wind draft
    const floorDroneBonus = floor === 0 ? 0.045 : 0;
    const floorWindBonus = floor === 6 ? 0.055 : 0;
    const windFreq = floor === 6 ? 440 : floor === 0 ? 180 : 280;

    this.ambientGain.gain.setTargetAtTime(0.05 + tension * 0.05 + floorDroneBonus, t, 0.5);
    this.windGain.gain.setTargetAtTime(0.025 + tension * 0.04 + floorWindBonus, t, 0.5);
    this.windFilter.frequency.setTargetAtTime(windFreq, t, 0.6);

    if (this.generatorHumGain) {
      const genLevel = generatorOn ? (floor === 0 ? 0.085 : 0.015) : 0;
      this.generatorHumGain.gain.setTargetAtTime(genLevel, t, 0.3);
    }
  }

  private createNoiseBuffer(seconds: number): AudioBuffer {
    const ctx = this.ctx!;
    const length = Math.floor(ctx.sampleRate * seconds);
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0,
      b1 = 0,
      b2 = 0;
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99765 * b0 + white * 0.099046;
      b1 = 0.963 * b1 + white * 0.2965164;
      b2 = 0.57 * b2 + white * 1.0526913;
      data[i] = (b0 + b1 + b2 + white * 0.1848) * 0.18;
    }
    return buffer;
  }

  private startAmbientBed(): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;

    this.ambientGain = ctx.createGain();
    this.ambientGain.gain.value = 0.05;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 190;

    this.droneOsc1 = ctx.createOscillator();
    this.droneOsc1.type = 'sawtooth';
    this.droneOsc1.frequency.value = 50;

    this.droneOsc2 = ctx.createOscillator();
    this.droneOsc2.type = 'triangle';
    this.droneOsc2.frequency.value = 74.5;

    this.droneOsc1.connect(filter);
    this.droneOsc2.connect(filter);
    filter.connect(this.ambientGain);
    this.ambientGain.connect(this.masterGain);

    this.droneOsc1.start();
    this.droneOsc2.start();

    const windSrc = ctx.createBufferSource();
    windSrc.buffer = this.noiseBuffer;
    windSrc.loop = true;

    this.windFilter = ctx.createBiquadFilter();
    this.windFilter.type = 'bandpass';
    this.windFilter.frequency.value = 280;
    this.windFilter.Q.value = 2.4;

    this.windGain = ctx.createGain();
    this.windGain.gain.value = 0.028;

    windSrc.connect(this.windFilter);
    this.windFilter.connect(this.windGain);
    this.windGain.connect(this.masterGain);
    windSrc.start();

    // Persistent elevator motor
    this.elevatorHumOsc = ctx.createOscillator();
    this.elevatorHumOsc.type = 'sawtooth';
    this.elevatorHumOsc.frequency.value = 62;
    const elFilter = ctx.createBiquadFilter();
    elFilter.type = 'lowpass';
    elFilter.frequency.value = 240;
    this.elevatorHumGain = ctx.createGain();
    this.elevatorHumGain.gain.value = 0;

    this.elevatorHumOsc.connect(elFilter);
    elFilter.connect(this.elevatorHumGain);
    this.elevatorHumGain.connect(this.masterGain);
    this.elevatorHumOsc.start();

    // Persistent diesel generator motor
    this.generatorHumOsc = ctx.createOscillator();
    this.generatorHumOsc.type = 'sawtooth';
    this.generatorHumOsc.frequency.value = 34;
    const genFilter = ctx.createBiquadFilter();
    genFilter.type = 'lowpass';
    genFilter.frequency.value = 150;
    this.generatorHumGain = ctx.createGain();
    this.generatorHumGain.gain.value = 0;

    this.generatorHumOsc.connect(genFilter);
    genFilter.connect(this.generatorHumGain);
    this.generatorHumGain.connect(this.masterGain);
    this.generatorHumOsc.start();
  }

  public setElevatorMotor(active: boolean, pitchScale = 1): void {
    if (!this.ctx || !this.elevatorHumGain || !this.elevatorHumOsc) return;
    const t = this.ctx.currentTime;
    this.elevatorHumGain.gain.setTargetAtTime(active ? 0.09 : 0, t, 0.14);
    this.elevatorHumOsc.frequency.setTargetAtTime(62 * pitchScale, t, 0.2);
  }

  public playFootstep(
    crouching: boolean,
    surface: boolean | 'concrete' | 'metal' | 'wood' = false,
    sprinting = false,
  ): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const kind =
      typeof surface === 'boolean' ? (surface ? 'metal' : 'concrete') : surface;

    const thud = ctx.createOscillator();
    thud.type = kind === 'wood' ? 'triangle' : 'sine';
    const baseFreq =
      kind === 'metal'
        ? 118 + Math.random() * 25
        : kind === 'wood'
          ? 102 + Math.random() * 22
          : 78 + Math.random() * 18;
    thud.frequency.setValueAtTime(baseFreq, t);
    thud.frequency.exponentialRampToValueAtTime(kind === 'wood' ? 42 : 32, t + 0.09);

    const thudGain = ctx.createGain();
    const amp = crouching ? 0.05 : sprinting ? 0.23 : 0.14;
    thudGain.gain.setValueAtTime(amp, t);
    thudGain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);

    thud.connect(thudGain);
    thudGain.connect(this.masterGain);
    thud.start(t);
    thud.stop(t + 0.12);

    const scuff = ctx.createBufferSource();
    scuff.buffer = this.noiseBuffer;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value =
      kind === 'metal'
        ? 1650
        : kind === 'wood'
          ? 520 + Math.random() * 160
          : 950 + Math.random() * 280;
    bp.Q.value = kind === 'metal' ? 4.2 : kind === 'wood' ? 2.8 : 1.5;

    const scuffGain = ctx.createGain();
    scuffGain.gain.setValueAtTime(crouching ? 0.02 : sprinting ? 0.1 : 0.06, t);
    scuffGain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

    scuff.connect(bp);
    bp.connect(scuffGain);
    scuffGain.connect(this.masterGain);
    scuff.start(t, Math.random() * 1.5, 0.09);

    if (kind === 'wood' && !crouching && Math.random() < (sprinting ? 0.36 : 0.16)) {
      this.playFloorCreak(0, sprinting ? 0.45 : 0.24);
    }
  }

  public playFloorCreak(pan = 0, intensity = 0.55): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    const startFreq = 115 + Math.random() * 45;
    osc.frequency.setValueAtTime(startFreq, t);
    osc.frequency.linearRampToValueAtTime(startFreq * 1.32, t + 0.14);
    osc.frequency.linearRampToValueAtTime(startFreq * 0.78, t + 0.36);

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 390;
    bp.Q.value = 6.0;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.065 * intensity, t + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.38);

    osc.connect(bp);
    bp.connect(gain);
    gain.connect(panner);
    osc.start(t);
    osc.stop(t + 0.4);
  }

  public playMonsterFootstep(distance: number, pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const att = Math.max(0, 1 - distance / 19);
    if (att <= 0.02) return;

    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    // Deep heavy heel impact distinct from player steps
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(48 + Math.random() * 10, t);
    osc.frequency.exponentialRampToValueAtTime(19, t + 0.19);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.28 * att, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.21);

    osc.connect(gain);
    gain.connect(panner);
    osc.start(t);
    osc.stop(t + 0.22);

    // Wet coat / boot drag scrape
    const drag = ctx.createBufferSource();
    drag.buffer = this.noiseBuffer;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 420;
    bp.Q.value = 2.5;
    const dGain = ctx.createGain();
    dGain.gain.setValueAtTime(0.065 * att, t + 0.03);
    dGain.gain.exponentialRampToValueAtTime(0.001, t + 0.19);

    drag.connect(bp);
    bp.connect(dGain);
    dGain.connect(panner);
    drag.start(t + 0.03, Math.random() * 1.4, 0.18);
  }

  public playMuffledFootstepsBehindDoor(pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    [0, 0.48, 0.96, 1.44].forEach((offset, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(64 - i * 3, t + offset);
      osc.frequency.exponentialRampToValueAtTime(24, t + offset + 0.13);

      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 180;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.11 * (1 - i * 0.12), t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.14);

      osc.connect(lp);
      lp.connect(gain);
      gain.connect(panner);
      osc.start(t + offset);
      osc.stop(t + offset + 0.16);
    });
  }

  public playDoorPound(distance: number, pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const att = Math.max(0.15, 1 - distance / 20);
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    [0, 0.22].forEach((offset) => {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(105, t + offset);
      osc.frequency.exponentialRampToValueAtTime(32, t + offset + 0.16);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.28 * att, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.18);

      osc.connect(gain);
      gain.connect(panner);
      osc.start(t + offset);
      osc.stop(t + offset + 0.2);
    });
  }

  public playHeartbeat(intensity = 0.6): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    [0, 0.18].forEach((offset, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(i === 0 ? 58 : 48, t + offset);
      osc.frequency.exponentialRampToValueAtTime(26, t + offset + 0.14);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.18 * intensity, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.15);

      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + offset);
      osc.stop(t + offset + 0.16);
    });
  }

  public playMonsterAlert(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(125, t);
    osc.frequency.exponentialRampToValueAtTime(340, t + 0.25);
    osc.frequency.exponentialRampToValueAtTime(92, t + 0.75);

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 680;
    bp.Q.value = 3.2;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.2, t + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

    osc.connect(bp);
    bp.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.85);
  }

  public playGeneratorStart(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(22, t);
    osc.frequency.exponentialRampToValueAtTime(75, t + 1.2);
    osc.frequency.linearRampToValueAtTime(42, t + 1.8);

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 260;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.22, t + 0.5);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 1.9);

    osc.connect(lp);
    lp.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 2.0);
  }

  public playFlashlightToggle(on: boolean): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(on ? 1950 : 1420, t);
    osc.frequency.exponentialRampToValueAtTime(on ? 950 : 620, t + 0.025);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.08, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.035);
  }

  public playItemPickup(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(520, t);
    osc.frequency.exponentialRampToValueAtTime(780, t + 0.08);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.09, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.13);
  }

  public playItemDrop(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(52, t + 0.14);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.18);
  }

  public playElevatorButton(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(880, t);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.07, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.085);
  }

  public playElevatorChime(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    [659.25, 987.77].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.14);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.001, t + idx * 0.14);
      gain.gain.linearRampToValueAtTime(0.11, t + idx * 0.14 + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0008, t + idx * 0.14 + 0.9);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + idx * 0.14);
      osc.stop(t + idx * 0.14 + 0.95);
    });
  }

  public playElevatorDoorSlide(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(220, t);
    filter.frequency.linearRampToValueAtTime(420, t + 0.35);
    filter.frequency.linearRampToValueAtTime(170, t + 0.85);
    filter.Q.value = 3.5;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.12, t + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.9);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    src.start(t, 0, 0.95);
  }

  public playDoorLocked(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    [0, 0.09].forEach((offset) => {
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, t + offset);
      osc.frequency.exponentialRampToValueAtTime(65, t + offset + 0.06);

      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 480;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.11, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.075);

      osc.connect(lp);
      lp.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + offset);
      osc.stop(t + offset + 0.08);
    });
  }

  public playDoorKnock(pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    [0, 0.16, 0.32].forEach((offset) => {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(135, t + offset);
      osc.frequency.exponentialRampToValueAtTime(52, t + offset + 0.07);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.18, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.09);
      osc.connect(gain);
      gain.connect(panner);
      osc.start(t + offset);
      osc.stop(t + offset + 0.1);
    });
  }

  public playDoorCreak(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(165, t);
    osc.frequency.linearRampToValueAtTime(245, t + 0.28);
    osc.frequency.linearRampToValueAtTime(135, t + 0.65);

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 620;
    bp.Q.value = 5.5;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.07, t + 0.08);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.68);

    osc.connect(bp);
    bp.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.72);
  }

  public playBreakerFlip(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(260, t);
    osc.frequency.exponentialRampToValueAtTime(85, t + 0.07);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.09);
  }

  public playPaperPickup(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1800;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.09, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

    src.connect(hp);
    hp.connect(gain);
    gain.connect(this.masterGain);
    src.start(t, 0.2, 0.2);
  }

  public playWhisper(pan = 0, intensity = 0.7): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    const syllables = [
      { delay: 0.0, dur: 0.55, f1: 680, f2: 1950 },
      { delay: 0.62, dur: 0.42, f1: 520, f2: 1480 },
      { delay: 1.15, dur: 0.78, f1: 780, f2: 2350 },
    ];

    syllables.forEach((syl) => {
      const start = t + syl.delay;
      const src = ctx.createBufferSource();
      src.buffer = this.noiseBuffer!;

      const form1 = ctx.createBiquadFilter();
      form1.type = 'bandpass';
      form1.frequency.setValueAtTime(syl.f1, start);
      form1.frequency.linearRampToValueAtTime(syl.f1 * 0.82, start + syl.dur);
      form1.Q.value = 7.5;

      const form2 = ctx.createBiquadFilter();
      form2.type = 'bandpass';
      form2.frequency.setValueAtTime(syl.f2, start);
      form2.frequency.linearRampToValueAtTime(syl.f2 * 1.12, start + syl.dur);
      form2.Q.value = 9.0;

      const gain = ctx.createGain();
      const peak = 0.16 * intensity;
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.linearRampToValueAtTime(peak, start + syl.dur * 0.28);
      gain.gain.exponentialRampToValueAtTime(0.001, start + syl.dur);

      src.connect(form1);
      src.connect(form2);
      form1.connect(gain);
      form2.connect(gain);
      gain.connect(panner);

      src.start(start, Math.random() * 1.2, syl.dur + 0.05);
    });
  }

  public playDistantBang(pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(92, t);
    osc.frequency.exponentialRampToValueAtTime(28, t + 0.45);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.6);

    osc.connect(gain);
    gain.connect(panner);
    osc.start(t);
    osc.stop(t + 0.65);

    const tail = ctx.createBufferSource();
    tail.buffer = this.noiseBuffer;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 340;
    bp.Q.value = 4;
    const tGain = ctx.createGain();
    tGain.gain.setValueAtTime(0.06, t);
    tGain.gain.exponentialRampToValueAtTime(0.001, t + 0.85);
    tail.connect(bp);
    bp.connect(tGain);
    tGain.connect(panner);
    tail.start(t, 0, 0.9);
  }

  public playAttackWindup(pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(95, t);
    osc.frequency.exponentialRampToValueAtTime(215, t + 0.35);

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 540;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.01, t);
    gain.gain.linearRampToValueAtTime(0.16, t + 0.14);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.42);

    osc.connect(lp);
    lp.connect(gain);
    gain.connect(panner);
    osc.start(t);
    osc.stop(t + 0.45);
  }

  public playPhoneBuzz(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    [0, 0.16].forEach((offset, idx) => {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(idx === 0 ? 740 : 980, t + offset);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.075, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.12);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + offset);
      osc.stop(t + offset + 0.13);
    });
  }

  public playCameraSwitch(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(1180, t);
    osc.frequency.exponentialRampToValueAtTime(480, t + 0.04);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.055, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.045);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.05);
  }

  public playAchievementChime(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    [523.25, 659.25, 783.99].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + i * 0.09);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.07, t + i * 0.09);
      gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.09 + 0.28);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + i * 0.09);
      osc.stop(t + i * 0.09 + 0.3);
    });
  }

  public playThunder(intensity = 0.8): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.setValueAtTime(220, t);
    lp.frequency.exponentialRampToValueAtTime(68, t + 1.8);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.24 * intensity, t + 0.14);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 2.1);

    src.connect(lp);
    lp.connect(gain);
    gain.connect(this.masterGain);
    src.start(t, Math.random() * 0.6, 2.2);
  }

  public playBreathing(fearLevel = 0.6): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(640, t);
    bp.frequency.linearRampToValueAtTime(420, t + 0.45);
    bp.Q.value = 2.6;

    const gain = ctx.createGain();
    const peak = 0.055 * Math.min(1, fearLevel);
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(peak, t + 0.14);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.5);

    src.connect(bp);
    bp.connect(gain);
    gain.connect(this.masterGain);
    src.start(t, Math.random() * 1.1, 0.55);
  }

  public playRadioStatic(pan = 0): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-0.9, Math.min(0.9, pan));
    panner.connect(this.masterGain);

    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1450, t);
    bp.frequency.linearRampToValueAtTime(880, t + 0.7);
    bp.Q.value = 3.0;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.linearRampToValueAtTime(0.09, t + 0.06);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.75);

    src.connect(bp);
    bp.connect(gain);
    gain.connect(panner);
    src.start(t, Math.random() * 1.2, 0.8);
  }

  public playKeypadBeep(status?: boolean): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    if (status === true) {
      [780, 1040].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t + idx * 0.09);
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.08, t + idx * 0.09);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.09 + 0.14);
        osc.connect(gain);
        gain.connect(this.masterGain!);
        osc.start(t + idx * 0.09);
        osc.stop(t + idx * 0.09 + 0.15);
      });
      return;
    }

    const osc = ctx.createOscillator();
    osc.type = status === false ? 'sawtooth' : 'square';
    osc.frequency.setValueAtTime(status === false ? 190 : 960, t);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.065, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + (status === false ? 0.22 : 0.05));
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + (status === false ? 0.24 : 0.06));
  }

  public playIncomingCallRing(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const t = ctx.currentTime;

    [0, 0.28, 0.56].forEach((offset) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(offset === 0.28 ? 640 : 880, t + offset);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.085, t + offset);
      gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.2);
      osc.connect(gain);
      gain.connect(this.masterGain!);
      osc.start(t + offset);
      osc.stop(t + offset + 0.22);
    });
  }

  public dispose(): void {
    try {
      this.droneOsc1?.stop();
      this.droneOsc2?.stop();
      this.elevatorHumOsc?.stop();
      this.generatorHumOsc?.stop();
      void this.ctx?.close();
    } catch {
      // Ignore cleanup errors
    }
    this.ctx = null;
  }
}
