import { CreatureEntry, CreatureId } from '../types';

const CREATURES_KEY = 'whisper_floors_creatures_v1';

export const CREATURE_CATALOG: CreatureEntry[] = [
  {
    id: 'stalker',
    name: 'Наблюдатель подъезда',
    subtitle: 'Мокрый высокий силуэт в плаще',
    threat: 'Высокая · Преследует и проверяет укрытия',
    summary:
      'Искажённая фигура, бродящая между этажами в отсыревшем длинном плаще. Отзывается на шум шагов, скрип дверей и луч фонарика.',
    behaviors: [
      'Патрулирует этажи и спускается по лестницам.',
      'Слышит бег и удары дверей с соседнего пролёта.',
      'После потери цели обыскивает ближайшие шкафы и углы.',
    ],
    counterTips: [
      'Используйте рывок бегом на короткой дистанции — вы быстрее на старте погони.',
      'Перед атакой он замахивается на долю секунды: уходите в сторону или за угол.',
      'Заходите в укрытия и обязательно выключайте фонарик (F).',
    ],
  },
  {
    id: 'whisper_phenomenon',
    name: 'Шёпот между этажами',
    subtitle: 'Акустический шлейф и голос в шахте',
    threat: 'Средняя · Вызывает дезориентацию и сбои лифта',
    summary:
      'Низкочастотная звуковая аномалия, распространяющаяся через вентиляцию, мусоропровод и старую проводку дома.',
    behaviors: [
      'Повторяет обрывки голосов пропавших жильцов за закрытыми дверями.',
      'Может самостоятельно вызывать лифт на другие этажи.',
      'Усиливает тревогу, когда вы находитесь в подвале или на чердаке.',
    ],
    counterTips: [
      'Следите за звуком шагов за стеной: не путайте эхо с реальным приближением охотника.',
      'Запуск генератора и глушение антенны на чердаке ослабляют шёпот.',
    ],
  },
  {
    id: 'shadow_phantom',
    name: 'Тень пролёта',
    subtitle: 'Мимолётный силуэт в темноте и на камерах',
    threat: 'Низкая · Психологическое давление и помехи CCTV',
    summary:
      'Нематериальный отпечаток прошлых ночных смен. Мелькает в конце коридора, у лестничных окон и в объективах камер наблюдения.',
    behaviors: [
      'Исчезает, если подойти слишком близко.',
      'Иногда появляется на мониторе охраны в кв. №5 за секунду до потери сигнала.',
    ],
    counterTips: [
      'Сохраняйте спокойствие и не тратьте заряд батареи напрасно, когда видите фантома.',
    ],
  },
  {
    id: 'signal_zero',
    name: 'Контур «Сигнал №0»',
    subtitle: 'Скрытая сеть наблюдения дома',
    threat: 'Сюжетная тайна · Ключ к истинной развязке',
    summary:
      'Подпольная система ретрансляции, соединяющая секретную комнату за 10-й квартирой, архив кв. №11 и передатчик на чердаке.',
    behaviors: [
      'Передаёт неизвестные сообщения на телефон во время ночных перебоев.',
      'Зацикливает магнитные записи жильцов в эфире подъезда.',
    ],
    counterTips: [
      'Найдите потайную панель в кв. №10, заберите кассету №4 и заглушите антенну на чердаке.',
    ],
  },
];

export class CreatureGalleryManager {
  private discovered = new Set<CreatureId>();

  constructor() {
    this.load();
  }

  public load(): void {
    try {
      const raw = localStorage.getItem(CREATURES_KEY);
      if (!raw) return;
      const arr = JSON.parse(raw) as unknown[];
      if (!Array.isArray(arr)) return;
      this.discovered.clear();
      for (const id of arr) {
        if (CREATURE_CATALOG.some((c) => c.id === id)) {
          this.discovered.add(id as CreatureId);
        }
      }
    } catch {
      // Ignore storage restrictions
    }
  }

  private save(): void {
    try {
      localStorage.setItem(
        CREATURES_KEY,
        JSON.stringify(Array.from(this.discovered)),
      );
    } catch {
      // Ignore
    }
  }

  public discover(id: CreatureId): boolean {
    if (this.discovered.has(id)) return false;
    this.discovered.add(id);
    this.save();
    return true;
  }

  public getDiscoveredIds(): CreatureId[] {
    return Array.from(this.discovered);
  }

  public mergeDiscovered(ids: CreatureId[]): void {
    for (const id of ids) {
      if (CREATURE_CATALOG.some((c) => c.id === id)) {
        this.discovered.add(id);
      }
    }
    this.save();
  }
}
