import { AchievementDef, AchievementId } from '../types';

const ACHIEVEMENTS_STORAGE_KEY = 'whisper_floors_achievements_v1';

export const ACHIEVEMENTS_CATALOG: AchievementDef[] = [
  {
    id: 'first_escape',
    title: 'Первый побег',
    description: 'Впервые успешно скрыться от маньяка после преследования.',
  },
  {
    id: 'quiet_one',
    title: 'Тихоня',
    description: 'Исследовать несколько этажей, не поднимая лишнего шума.',
  },
  {
    id: 'explorer',
    title: 'Исследователь',
    description: 'Найти секретную комнату или скрытый архив дома.',
  },
  {
    id: 'survivor',
    title: 'Выживший',
    description: 'Дожить до финала и выбраться из подъезда.',
  },
  {
    id: 'night_guest',
    title: 'Ночной гость',
    description: 'Спуститься в подвал и осмотреть технические помещения.',
  },
];

export class AchievementManager {
  private unlocked = new Set<AchievementId>();

  constructor() {
    this.load();
  }

  public load(): void {
    try {
      const raw = localStorage.getItem(ACHIEVEMENTS_STORAGE_KEY);
      if (!raw) return;
      const arr = JSON.parse(raw) as unknown[];
      if (!Array.isArray(arr)) return;
      this.unlocked.clear();
      for (const id of arr) {
        if (ACHIEVEMENTS_CATALOG.some((a) => a.id === id)) {
          this.unlocked.add(id as AchievementId);
        }
      }
    } catch {
      // Ignore storage restrictions
    }
  }

  private save(): void {
    try {
      localStorage.setItem(
        ACHIEVEMENTS_STORAGE_KEY,
        JSON.stringify(Array.from(this.unlocked)),
      );
    } catch {
      // Ignore
    }
  }

  public unlock(id: AchievementId): AchievementDef | null {
    if (this.unlocked.has(id)) return null;
    this.unlocked.add(id);
    this.save();
    return ACHIEVEMENTS_CATALOG.find((a) => a.id === id) ?? null;
  }

  public isUnlocked(id: AchievementId): boolean {
    return this.unlocked.has(id);
  }

  public getUnlockedIds(): AchievementId[] {
    return Array.from(this.unlocked);
  }

  public mergeUnlocked(ids: AchievementId[]): void {
    for (const id of ids) {
      if (ACHIEVEMENTS_CATALOG.some((a) => a.id === id)) {
        this.unlocked.add(id);
      }
    }
    this.save();
  }
}
