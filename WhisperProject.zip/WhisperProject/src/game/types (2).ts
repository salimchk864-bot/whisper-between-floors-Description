export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED',
  INSPECTING = 'INSPECTING',
  HIDING = 'HIDING',
  PEEPHOLE = 'PEEPHOLE',
  CCTV = 'CCTV',
  PHONE = 'PHONE',
  KEYPAD = 'KEYPAD',
  INVENTORY = 'INVENTORY',
  CUTSCENE = 'CUTSCENE',
  ENDING = 'ENDING',
}

export type QualityPreset = 'low' | 'medium' | 'high';
export type DifficultyLevel = 'easy' | 'normal' | 'hard' | 'nightmare';
export type WeatherType = 'rain' | 'storm' | 'fog';
export type TouchScalePreset = 'compact' | 'standard' | 'large';

export interface GameSettings {
  sensitivity: number;
  volume: number;
  quality: QualityPreset;
  invertY: boolean;
  difficulty: DifficultyLevel;
  touchScale: TouchScalePreset;
  controlsSwapHands: boolean;
}

export interface ReadableNote {
  id: string;
  title: string;
  floorLabel: string;
  body: string[];
  hint?: string;
}

export type ItemKind =
  | 'key'
  | 'battery'
  | 'fuse'
  | 'fuel'
  | 'screwdriver'
  | 'medkit'
  | 'story';

export interface InventoryItem {
  id: string;
  name: string;
  description: string;
  kind: ItemKind;
  quantity: number;
  maxStack: number;
}

export type InteractCategory =
  | 'elevator_call'
  | 'elevator_button'
  | 'door'
  | 'peephole'
  | 'fusebox'
  | 'mailbox'
  | 'note'
  | 'intercom'
  | 'chute'
  | 'hide'
  | 'item'
  | 'generator'
  | 'secret'
  | 'radio'
  | 'cctv'
  | 'keypad';

export interface InteractPrompt {
  id: string;
  title: string;
  actionText: string;
  secondaryActionText?: string;
  category: InteractCategory;
}

export type MonsterState =
  | 'IDLE'
  | 'PATROL'
  | 'SUSPICIOUS'
  | 'SEARCH'
  | 'CHASE'
  | 'LOST_TARGET'
  | 'RETURN_PATROL';

export type EndingId = 'good' | 'bad' | 'secret' | 'true';

export interface EndingInfo {
  id: EndingId;
  title: string;
  subtitle: string;
  description: string;
}

export interface CutsceneInfo {
  id: string;
  title: string;
  caption: string;
}

export type AchievementId =
  | 'first_escape'
  | 'quiet_one'
  | 'explorer'
  | 'survivor'
  | 'night_guest';

export interface AchievementDef {
  id: AchievementId;
  title: string;
  description: string;
}

export type CreatureId =
  | 'stalker'
  | 'whisper_phenomenon'
  | 'shadow_phantom'
  | 'signal_zero';

export interface CreatureEntry {
  id: CreatureId;
  name: string;
  subtitle: string;
  threat: string;
  summary: string;
  behaviors: string[];
  counterTips: string[];
}

export interface PhoneMessage {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
  isCall?: boolean;
  photoTitle?: string;
  photoCaption?: string;
  photoScene?: 'shaft' | 'corridor' | 'basement' | 'attic';
}

export interface KeypadPromptInfo {
  id: string;
  title: string;
  hint: string;
}

export interface NightSeedData {
  nightNumber: number;
  monsterStartFloor: number;
  itemVariant: number; // 0 | 1 | 2
  secretVariant: number; // 0 | 1
  openApt5: boolean;
  openApt11: boolean;
  patrolBias: number;
  weather: WeatherType;
  isNewGamePlus: boolean;
  keypadCode: string;
}

export interface CameraFeedInfo {
  id: string;
  label: string;
  floor: number;
  online: boolean;
  monsterOnFloor: boolean;
  monsterNormX: number;
  monsterNormZ: number;
  monsterState: MonsterState;
  anomaly: 'none' | 'shadow_peek' | 'static_face' | 'light_dip';
}

export interface HUDState {
  gameState: GameState;
  currentFloor: number;
  locationName: string;
  elevatorFloor: number;
  elevatorState: 'idle' | 'closing' | 'moving' | 'opening' | 'stalled';
  elevatorPowered: boolean;
  flashlightOn: boolean;
  battery: number; // 0..100
  health: number; // 0..100
  stamina: number; // 0..100
  exhausted: boolean;
  noiseLevel: number; // 0..100
  crouching: boolean;
  sprinting: boolean;
  hidingSpotName: string | null;
  peepholeActive: boolean;
  peepholeLabel: string | null;
  activePrompt: InteractPrompt | null;
  activeNote: ReadableNote | null;
  activeCutscene: CutsceneInfo | null;
  activeEnding: EndingInfo | null;
  activeKeypad: KeypadPromptInfo | null;
  subtitle: string | null;
  phoneMessage: PhoneMessage | null;
  phoneHistory: PhoneMessage[];
  phoneUnreadCount: number;
  achievementToast: AchievementDef | null;
  inventory: InventoryItem[];
  maxInventorySlots: number;
  notesFound: string[];
  restoredFloors: number[];
  generatorRunning: boolean;
  generatorFuelAdded: boolean;
  generatorFusesInserted: number;
  monsterState: MonsterState;
  monsterDistance: number;
  monsterWindingUp: boolean;
  dangerLevel: number; // 0..1
  fearLevel: number; // 0..1
  tension: number;
  damageFlash: number;
  nightNumber: number;
  difficulty: DifficultyLevel;
  weather: WeatherType;
  isNewGamePlus: boolean;
  isTouchDevice: boolean;
  cctvFeeds: CameraFeedInfo[];
  activeCameraIndex: number;
  discoveredCreatures: CreatureId[];
}

export interface InputState {
  moveX: number;
  moveY: number;
  lookDeltaX: number;
  lookDeltaY: number;
  sprint: boolean;
}

export interface SaveDataV2 {
  version: 2;
  savedAt: number;
  playerPos: { x: number; y: number; z: number };
  playerYaw: number;
  playerPitch: number;
  health: number;
  stamina?: number;
  battery: number;
  flashlightOn: boolean;
  inventory: InventoryItem[];
  notesFound: string[];
  pickedUpWorldItems: string[];
  unlockedDoors: string[];
  unlockedKeypads?: string[];
  restoredFloors: number[];
  generatorFuelAdded: boolean;
  generatorFusesInserted: number;
  generatorRunning: boolean;
  secretPanelOpen: boolean;
  ventGrateOpen: boolean;
  atticTransmitterActive: boolean;
  triggeredCutscenes: string[];
  elevatorFloor: number;
  discoveredEndings: EndingId[];
  nightSeed?: NightSeedData;
  difficulty?: DifficultyLevel;
  phoneHistory?: PhoneMessage[];
}
